#include "Shot.h"



void Shot::draw(sf::RenderWindow & window)
{
	window.draw(shape);
}

void Shot::move(float elapsedTime)
{
	shape.move(dir*speed*elapsedTime);
}

bool Shot::isOnScreen(float w, float h)
{
	sf::FloatRect rect = sf::FloatRect(0, 0, w, h);
	return rect.contains(shape.getPosition());
}

Shot::Shot(Player* shooter, sf::Vector2f targ):target(targ), color(sf::Color(180,0,0))
{
	shape = sf::RectangleShape(sf::Vector2f(6,2));
	shape.setFillColor(sf::Color::Red);
	shape.setOrigin(shape.getLocalBounds().width / 2, shape.getLocalBounds().height / 2);

	sf::Vector2f vec = targ - shooter->getGunPosition();
	float len = sqrt(vec.x*vec.x + vec.y*vec.y);

	float angle = atan(vec.y / vec.x) * 180 / PI;
	if (vec.x < 0) angle += 180;

	vec.x /= len;
	vec.y /= len;
	dir = vec;
	
	shape.setRotation(angle);
	shape.setPosition(shooter->getGunPosition());
	
	target = targ;
}


