#pragma once
#include <SFML\Graphics.hpp>
#include "Player.h"
#include <map>
#include <string>
#include <map>
#include <vector>
using std::map;
using std::multimap;
using std::string;
using std::pair;
using std::vector;
using std::make_pair;
class Rating
{
	sf::RectangleShape background;
	const sf::Color bgColor = sf::Color(0,0,0,128);
	const sf::Color textColor = sf::Color::White;
	const sf::Color deadColor = sf::Color(180, 180, 180, 255);
	const sf::Color thisColor = sf::Color(sf::Color::Cyan);
	const sf::Color thisDeadColor = sf::Color(sf::Color::Red);
	sf::Font font;
public:
	bool enabled;
	Rating(int scrW, int scrH);
	void display(sf::RenderWindow& window, map<unsigned int, Player*>& players, unsigned int thisPlayer);
};

