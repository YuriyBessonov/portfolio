#pragma once
#include <SFML/Graphics.hpp>
#include "Player.h"
#include "Rating.h"
#include "Shot.h"
#include "ClientNetwork.h"
#include "NetworkData.h"
#include "MapManager.h"
#include <map>
#include <list>
#include <string>

class ClientGame
{
	const sf::Time TIME_PER_FRAME = sf::seconds(1.f / 30.f);
	const int WIDTH = 800;
	const int HEIGHT = 480;
	sf::RenderWindow window;

	std::map<unsigned int,Player*> players;
	std::string playerName;
	std::list<Shot*> shots;
	sf::Clock shotsClock;
	sf::Time timeSinceLastShot;
	const sf::Time shotsDelay = sf::seconds(0.8f);

	Rating* ratingTable;

	ClientNetwork *network;
	char networkData[MAX_PACKET_SIZE];
	Packet playerPacket;
	int ID;
	int aliveCount;

	bool mIsMovingUp;
	bool mIsMovingDown;
	bool mIsMovingLeft;
	bool mIsMovingRight;
	float angle;
	float mX, mY;

	bool authorized;

	void update(sf::Time elapsedTime);
	void draw();
	void processEvents();
	void handlePlayerInput(sf::Keyboard::Key key, bool isPressed);
	void handlePlayerInput(int mouseX, int mouseY, bool shot=false);
	void processPackets();
	void sendUpdatedState();

	MapManager* mapMan;
	sf::Text winningText, loosingText;
	sf::Font font;
public:
	void run();
	ClientGame(std::string ip, std::string name="");
	~ClientGame();
};

