#pragma once
#include <SFML\Graphics.hpp>
#include <vector>
#include <map>
#include <string>
#include <utility>
#include <iostream>
using std::map;
using std::pair;
using std::string;
using std::vector;
using std::cout;
class MapManager
{
	const int tileW=128;
	map<string, pair<int, int> > tiles;
	vector<vector<sf::Sprite > > tileMap;
	sf::Texture texture;
public:
	MapManager(vector<vector<string> >& map);
	void drawMap(sf::RenderWindow& window);
};

