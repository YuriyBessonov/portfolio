#include "ClientGame.h"
#include <iostream>

using namespace std;

ClientGame::ClientGame(std::string ip, std::string name ) : window(sf::VideoMode(WIDTH, HEIGHT), "GAME"),
	mIsMovingUp(false), mIsMovingDown(false), mIsMovingLeft(false), mIsMovingRight(false),  authorized(false), 
	timeSinceLastShot(sf::Time::Zero), aliveCount(1)
{
	if (ip != "0")
		network = new ClientNetwork(ip);
	else network = new ClientNetwork();
	vector<vector<string> > map = {
		{ "G","G", "G", "G", "G", "G", "G" },
		{ "G","G", "G", "G", "G", "G", "G" },
		{ "G","G", "G", "G", "G", "G", "G" },
		{ "G","G", "G", "G", "G", "G", "G" },
		{ "G","G", "G", "G", "G", "G", "G" }
	};
	mapMan = new MapManager(map);
	playerName = name;
	ratingTable = new Rating(WIDTH, HEIGHT);
	font.loadFromFile("font.ttf");
	winningText = sf::Text(sf::String(L"�� ��������!"), font, 60);
	winningText.setFillColor(sf::Color::Green);
	loosingText = sf::Text(sf::String(L"�� ������"), font, 60);
	loosingText.setFillColor(sf::Color::Red);
	winningText.setOrigin(winningText.getLocalBounds().width / 2, winningText.getLocalBounds().height / 2);
	winningText.setPosition(sf::Vector2f(WIDTH / 2, HEIGHT / 2));
	loosingText.setOrigin(loosingText.getLocalBounds().width / 2, loosingText.getLocalBounds().height / 2);
	loosingText.setPosition(sf::Vector2f(WIDTH / 2, HEIGHT / 2));
}

void ClientGame::run()
{
	sf::Clock clock;
	sf::Time timeSinceLastUpdate = sf::Time::Zero;
	shotsClock.restart();
	while (window.isOpen())
	{
		processEvents();
		sf::Time elapsedTime = clock.restart();
		timeSinceLastUpdate += elapsedTime; 
		while (timeSinceLastUpdate > TIME_PER_FRAME)
		{
			timeSinceLastUpdate -= TIME_PER_FRAME;

			processEvents();
			update(TIME_PER_FRAME);
		}
		draw();
	}
}

void ClientGame::processEvents()
{
	sf::Event event;
	while (window.pollEvent(event))
	{
		if (event.type == sf::Event::Closed)
			window.close();
		switch (event.type)
		{
		case sf::Event::KeyPressed:
			handlePlayerInput(event.key.code, true);
			break;
		case sf::Event::KeyReleased:
			handlePlayerInput(event.key.code, false);
			break;
		case sf::Event::MouseMoved:
			handlePlayerInput(event.mouseMove.x, event.mouseMove.y);
			break;
		case sf::Event::MouseButtonPressed:
			if (event.mouseButton.button == sf::Mouse::Left)
			{
				timeSinceLastShot += shotsClock.restart();
				if (timeSinceLastShot >= shotsDelay)
				{
					handlePlayerInput(event.mouseButton.x, event.mouseButton.y, true);
					timeSinceLastShot = sf::Time::Zero;
				}
					
			}
				
			break;
		case sf::Event::Closed:
			window.close();
			break;
		}
	}
}

void ClientGame::update(sf::Time elapsedTime)
{
	if (authorized)
	{
		if (!players[ID]->isDead)
		{
			sf::Vector2f movement(0.f, 0.f);
			if (mIsMovingUp)
				movement.y -= players[ID]->getSpeed();
			if (mIsMovingDown)
				movement.y += players[ID]->getSpeed();
			if (mIsMovingLeft)
				movement.x -= players[ID]->getSpeed();
			if (mIsMovingRight)
				movement.x += players[ID]->getSpeed();
			handlePlayerInput(mX, mY);
			players[ID]->setRotation(angle);
			players[ID]->move(movement*elapsedTime.asSeconds());
		}
		for (auto it : shots)
			it->move(elapsedTime.asSeconds());
		while (!shots.empty() && shots.front()->isOnScreen(WIDTH,HEIGHT) == false)
		{
			delete shots.front();
			shots.pop_front();
		}
	}
	processPackets();
}

void ClientGame::draw()
{
	window.clear();
	mapMan->drawMap(window);
	for (auto it = players.begin(); it != players.end(); it++)
	{
		players[it->first]->draw(window);
	}
	for (auto it : shots)
		it->draw(window);
	if (authorized)
	{
		if (players[ID]->isDead)
			window.draw(loosingText);
		else if (players.size() > 1 && aliveCount == 1 && !players[ID]->isDead)
			window.draw(winningText);
	}
	if (ratingTable->enabled)
		ratingTable->display(window, players,ID);
	window.display();
}

void ClientGame::handlePlayerInput(sf::Keyboard::Key key, bool isPressed)
{
	if (key == sf::Keyboard::W)
		mIsMovingUp = isPressed;
	else if (key == sf::Keyboard::S)
		mIsMovingDown = isPressed;
	else if (key == sf::Keyboard::A)
		mIsMovingLeft = isPressed;
	else if (key == sf::Keyboard::D)
		mIsMovingRight = isPressed;
	else if (key == sf::Keyboard::Tab)
		ratingTable->enabled = isPressed;
}
void ClientGame::handlePlayerInput(int x, int y, bool shot)
{
	mX = x, mY = y;
	if (authorized)
	{
		if (shot == false)
		{
			float dx = x - players[ID]->getPosition().x;
			float dy = y - players[ID]->getPosition().y;
			angle = atan(dy / dx) * 180 / PI;
			if (dx < 0) angle += 180;
		}
		else 
		{
			Shot* sh = new Shot(players[ID], sf::Vector2f(x, y));
			shots.push_back(sh);
			playerPacket.type = SHOT;
			playerPacket.position = players[ID]->getGunPosition();
			playerPacket.shotPosition = sf::Vector2f(x, y);
		}
	}
}
void ClientGame::processPackets()
{
	int dataLength = network->receivePackets(networkData);
	if (dataLength <= 0)
		return;
	char* data = networkData;
	Packet packet;
	bool deadCheck;
	for (int i = 0; i < dataLength/sizeof(Packet); i++)
	{
		packet.deserialize(data);
		switch (packet.type)
		{
		case INIT:
			authorized = true;
			ID = packet.id;
			Player* p;
			players.insert(make_pair(ID, p));
			players[ID] = new Player(playerName);
			players[ID]->setPosition(sf::Vector2f(rand() % WIDTH, rand() % HEIGHT));
			players[ID]->highlight();
			playerPacket.id = ID;
			playerPacket.type = PLAYER_STATE;
			playerPacket.health = Player::maxHealth;
			playerPacket.score = 0;
			strcpy_s(playerPacket.name, playerName.c_str());
			break;
		case PLAYER_STATE:
			if (packet.id == ID) 
			{
				players[ID]->setHealth(packet.health);
				playerPacket.health = packet.health;
				players[ID]->setScore(packet.score);
				playerPacket.score = packet.score;
				break;
			}
			if (!players.count(packet.id))
			{
				Player* p;
				players.insert(make_pair(packet.id, p));
				players[packet.id] = new Player(packet.name);
				aliveCount++;
			} 
			players[packet.id]->moveTo(packet.position);
			players[packet.id]->setRotation(packet.rotation);
			deadCheck = players[packet.id]->isDead;
			players[packet.id]->setHealth(packet.health);
			if ( players[packet.id]->isDead && !deadCheck)
				aliveCount--;
			players[packet.id]->setScore(packet.score);
			break;
		case SHOT:
			Shot* sh;
			sh = new Shot(players[packet.id], packet.shotPosition);
			shots.push_back(sh);
			break;
		case UPDATE_REQUEST:
			sendUpdatedState();
			break;
		}
		data += sizeof(Packet);
	}
}
void ClientGame::sendUpdatedState()
{
	playerPacket.position = players[ID]->getPosition();
	playerPacket.rotation = players[ID]->getRotation();
	network->sendPacket(playerPacket);
	if (playerPacket.type == SHOT)
		playerPacket.type = PLAYER_STATE;
}

ClientGame::~ClientGame()
{
}
