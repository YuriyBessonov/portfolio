#pragma once
#include <SFML/Graphics.hpp>
#include <iostream>
#include <string>
#include "HealthIndicator.h"
const double PI = 3.141593;
class Player
{
	sf::Texture texture;
	sf::Sprite sprite;
	int health;
	int score;
	HealthIndicator* indicator;
	const sf::Time bleedingTime = sf::seconds(0.6f);
	const sf::Time disappeartime = sf::seconds(3.0f);
	sf::Clock clock;
	sf::Time duration;
	bool isBleeding;
	bool isDisappeared;
	std::string name;
public:
	void highlight();
	bool isDead;
	static const float speed;
	static const int maxHealth;
	static const int healthPerShot;
	static const float scaleFactor;
	void draw(sf::RenderWindow& window);
	void move(float dx, float dy);
	void move(sf::Vector2f d);
	void moveTo(sf::Vector2f dest);
	void rotate(float da);
	void setRotation(float alpha);
	void startBleeding();
	void stopBleeding();
	static bool isWounded(sf::Vector2f pos, float a, float b, float c);
	sf::Vector2f getGunPosition();
	void setPosition(sf::Vector2f pos)
	{
		sprite.setPosition(pos);
	}
	sf::Vector2f getPosition()
	{
		return sprite.getPosition();
	}
	float getSpeed()
	{
		return speed;
	}
	float getRotation()
	{
		return sprite.getRotation();
	}
	void setHealth(int hp)
	{
		if (!isDead)
		{
			if (hp < health)
				startBleeding();
			health = hp;
		}
		if (health < 0)
			dead();
	}
	int getHealth()
	{
		return health;
	}
	void setScore(int points)
	{
		score = points;
	}
	int getScore()
	{
		return score;
	}
	std::string getName()
	{
		return name;
	}
	void dead();
	Player(std::string nick ="");
	~Player();
};

