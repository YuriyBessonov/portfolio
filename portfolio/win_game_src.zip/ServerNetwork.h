#pragma once
#include <WinSock2.h>
#include <process.h>
#include <iostream>
#include <string>
#include <map>
#include "NetworkData.h"
#include "ServerGame.h"
using std::cout;
using std::endl;
using std::string;
using std::map;

#pragma comment (lib, "Ws2_32.lib")

class ServerNetwork
{
public:
	map<unsigned int, SOCKET> sessions;
	unsigned int clientsN;

	SOCKET listenSocket;
	SOCKET clientSocket;
	ServerNetwork(int port = 2602);
	bool acceptNewClient(int id);
	int receiveFromClient(unsigned int clientID, char *buf);
	static void sendPacket(SOCKET sock, Packet packet);
	static int receivePacket(SOCKET sock, Packet &packet);
	~ServerNetwork()
	{}
};

