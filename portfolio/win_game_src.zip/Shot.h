#pragma once
#include <SFML/Graphics.hpp>
#include <iostream>
#include "Player.h"

class Shot
{
	sf::RectangleShape shape;
	sf::Vector2f dir;
	sf::Vector2f target;
	sf::Color color;
	const float speed = 2400;
public:
	void draw(sf::RenderWindow& window);
	void move(float elapsedTime);
	bool isOnScreen(float w, float h);
	Shot(Player* shooter, sf::Vector2f targ);
	~Shot(){}
};

struct ShotData
{
	sf::Vector2f target;
	unsigned int shooterID;
};