#pragma once
#include <SFML\Graphics.hpp>
#include <iostream>
class HealthIndicator
{
	sf::RectangleShape indicBack, indicFront;
	float maxHP;
	const float width = 50;
	const float height = 9;
	const float offset = 55;
	const sf::Color back = sf::Color::Red;
	const sf::Color front = sf::Color::Green;
public:
	bool highlight;
	HealthIndicator(float maxHealth);
	void display(sf::RenderWindow& window, float hp, sf::Vector2f playerPos);
	~HealthIndicator();
};

