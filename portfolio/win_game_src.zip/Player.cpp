#include "Player.h"
const float Player::scaleFactor = 0.35f;
const int Player::healthPerShot = 15;
const int Player::maxHealth = 100;
const float Player::speed = 120;

void Player::dead()
{
	health = 0;
	isDead = true;
	duration = clock.restart();
}

Player::Player(std::string nick) : duration(sf::Time::Zero), isBleeding(false), score(0), isDead(false), isDisappeared(false), name(nick)
{
	texture.loadFromFile("sprite.png");
	sprite.setTexture(texture);
	sprite.setScale(scaleFactor, scaleFactor);
	sprite.setOrigin(sprite.getLocalBounds().width / 2, sprite.getLocalBounds().height / 2);

	indicator = new HealthIndicator(maxHealth);
	health = maxHealth;
}

void Player::highlight()
{
	indicator->highlight = true;
}

void Player::draw(sf::RenderWindow & window)
{
	if (isBleeding)
	{
		duration += clock.restart();
		if (duration >= bleedingTime)
			stopBleeding();
	}
	if (isDead && !isDisappeared)
	{
		sprite.setColor(sf::Color::Black);
		duration += clock.restart();
		if (duration >= disappeartime)
			isDisappeared = true;
	}
	if (!isDisappeared)
	{
		window.draw(sprite);
		indicator->display(window, health, sprite.getPosition());
	}
}

void Player::move(float dx, float dy)
{
	sprite.move(dx, dy);
}

void Player::move(sf::Vector2f d)
{
	sprite.move(d);
}

void Player::moveTo(sf::Vector2f dest)
{
	sprite.setPosition(dest);
}

void Player::rotate(float da)
{
}
void Player::setRotation(float alpha)
{
	sprite.setRotation(alpha);
}
void Player::startBleeding()
{
	if (!isBleeding)
	{
		isBleeding = true;
		clock.restart();
		sprite.setColor(sf::Color::Red);
	}
}
void Player::stopBleeding()
{
	if (isBleeding)
	{
		isBleeding = false;
		sprite.setColor(sf::Color::White);
		duration = sf::Time::Zero;
	}
}

bool Player::isWounded(sf::Vector2f pos, float a, float b, float c)
{	
	float spriteH = 216;
	c += a*pos.x + b*pos.y;
	float r = spriteH*scaleFactor*0.5;
	return (c*c <= (r*r*(a*a + b*b) + 0.01));
}
sf::Vector2f Player::getGunPosition()
{
	sf::Vector2f vec = sf::Vector2f(114 * scaleFactor, 52 * scaleFactor);
	sf::Vector2f vec2;
	vec2.x = vec.x*cos(sprite.getRotation() / 180 * PI) - vec.y*sin(sprite.getRotation() / 180 * PI);
	vec2.y = vec.x*sin(sprite.getRotation() / 180 * PI) + vec.y*cos(sprite.getRotation() / 180 * PI);
	return sprite.getPosition() + vec2;
}



Player::~Player()
{
}
