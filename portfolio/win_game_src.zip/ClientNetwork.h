#pragma once
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#include <WinSock2.h>
#include<windows.h>
#include <string>
#include <iostream>
#include "NetworkData.h"
using std::string;
using std::cout;
using std::endl;

#pragma comment (lib, "Ws2_32.lib")
#pragma comment (lib, "Mswsock.lib")
#pragma comment (lib, "AdvApi32.lib")
#define BUF_LEN 512

class ClientNetwork
{
public:
	SOCKET theSocket;
	ClientNetwork(string server="127.0.0.1", int port = 2602 );
	int receivePackets(char *);
	void sendPacket(Packet &p);
	~ClientNetwork() {}
};

