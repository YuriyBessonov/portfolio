#include "MapManager.h"



MapManager::MapManager(vector<vector<string> >& map)
{
	tiles["G"] = { 0,4 };//�����
	tiles["TL"] = {0,0};
	tiles["T"] = { 0,1 };
	tiles["TR"] = { 0,2 };
	tiles["ML"] = { 1,0 };
	tiles["M"] = { 1,1 };
	tiles["MR"] = { 1,2 };
	tiles["BL"] = { 2,0 };
	tiles["B"] = { 2,1 };
	tiles["BR"] = { 2,2 };
	tiles["UT"] = { 0,3 };
	tiles["UB"] = { 1,3 };
	tiles["UL"] = { 1,4 };
	tiles["UR"] = { 1,5 };
	tiles["A"] = { 0,5 };

	texture.loadFromFile("tiles.png");
	
	sf::IntRect rect;
	rect.width = tileW, rect.height = tileW;
	rect.left = rect.top = 0;

	tileMap.resize(map.size());
	for (int i = 0; i < map.size(); i++)
	{
		tileMap[i].resize(map[i].size());
		for (int j = 0; j < map[i].size(); j++)
		{
			tileMap[i][j].setTexture(texture);
			tileMap[i][j].setPosition(tileW*j,tileW*i);
			rect.left = tiles[map[i][j]].second*tileW;
			rect.top = tiles[map[i][j]].first*tileW;
			tileMap[i][j].setTextureRect(rect);
		}
			
	}
}

void MapManager::drawMap(sf::RenderWindow& window)
{
	for (int i = 0; i < tileMap.size(); i++)
		for (int j = 0; j < tileMap[i].size(); j++)
			window.draw(tileMap[i][j]);
}

