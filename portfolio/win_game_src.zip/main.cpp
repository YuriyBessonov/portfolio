#include <process.h>
#include "ClientGame.h"
#include "ServerGame.h"
//SRV - CLN - BOTH

#define SRV

#ifdef SRV
ServerGame* server;
int main()
{
	server = new ServerGame();
	server->run();
	return 0;
}

#endif
#ifdef CLN
ClientGame* client;
int main()
{
	std::cout << "Enter ip: ";
	string ip, name;
	std::cin >> ip;
	std::cout << "\nEnter your name: ";
	std::cin >> name;
	client = new ClientGame(ip, name);
	client->run();
	return 0;
}
#endif
#ifdef BOTH
void serverLoop(void *);

ServerGame* server;
ClientGame* client;
int main()
{
	server = new ServerGame();
	_beginthread(serverLoop, 0, (void*)12);
	client = new ClientGame("0");
	client->run();
	return 0;
}
void serverLoop(void * arg)
{
	server->run();
}
#endif

