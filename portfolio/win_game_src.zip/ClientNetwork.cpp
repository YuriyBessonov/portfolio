#include "ClientNetwork.h"
#include "NetworkData.h"

ClientNetwork::ClientNetwork(string serverIP, int port)
{
	WSADATA wsaDATA;
	if (WSAStartup(0x202, &wsaDATA))
	{
		cout<<"[!]ClientNetwork: WSAStart error "<<WSAGetLastError()<<endl;
		system("PAUSE");
		exit(-1);
	}
	theSocket = socket(AF_INET, SOCK_STREAM, 0);
	if (theSocket < 0)
	{
		cout << "[!]ClientNetwork: socket() error " << WSAGetLastError() << endl;
		system("PAUSE");
		exit(-1);
	}
	struct sockaddr_in dest_addr;
	dest_addr.sin_family = AF_INET;
	dest_addr.sin_port = htons(port);
	
	struct hostent* hst;
	if (inet_addr(serverIP.c_str()) != INADDR_NONE)
		dest_addr.sin_addr.s_addr = inet_addr(serverIP.c_str());
	else
		if (hst = (struct hostent*)gethostbyname(serverIP.c_str()))
			((unsigned long *)&dest_addr.sin_addr)[0] =
			((unsigned long **)hst->h_addr_list)[0][0];
		else
		{
			cout << "[!]ClientNetwork: invalid adress " << serverIP << endl;
			closesocket(theSocket);
			WSACleanup();
			system("PAUSE");
			exit(-1);
		}

	if (connect(theSocket, (struct sockaddr *)&dest_addr, sizeof(dest_addr))) 
	{
		cout << "[!]ClientNetwork: connect() error " << WSAGetLastError() << endl;
		system("PAUSE");
		exit(-1);
	}

}

int ClientNetwork::receivePackets(char *buf)
{
	int result = recv(theSocket, buf, MAX_PACKET_SIZE,0);
	if (result == 0)
	{
		printf("Connection closed\n");
		closesocket(theSocket);
		WSACleanup();
		exit(1);
	}

	return result;
}

void ClientNetwork::sendPacket(Packet &p)
{
	Packet packet = p;
	const unsigned int packetSize = sizeof(Packet);
	char packetData[packetSize];

	packet.serialize(packetData);
	send(theSocket, packetData, packetSize, 0);
}
