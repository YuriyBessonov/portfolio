#include "Rating.h"


Rating::Rating(int scrW, int scrH): enabled(false)
{
	background.setSize(sf::Vector2f(scrW, scrH));
	background.setFillColor(bgColor);
	font.loadFromFile("font.ttf");
}
void Rating::display(sf::RenderWindow& window, map<unsigned int, Player*>& players, unsigned int thisPlayer)
{
	multimap<int, sf::Text> rating;
	for (auto it : players)
	{
		char buf[64];
		_itoa_s(it.second->getScore(), buf, size_t(64), 10);
		sf::String s = sf::String(it.second->getName() + " " + string(buf));
		sf::Text text = sf::Text(s, font, 20);
		if (it.second->isDead)
		{
			if (it.first == thisPlayer)
				text.setFillColor(thisDeadColor);
			else text.setFillColor(deadColor);
		}
		else if (it.first == thisPlayer)
			text.setFillColor(thisColor);
		else text.setFillColor(sf::Color::White);
		text.setOrigin(text.getLocalBounds().width / 2, text.getLocalBounds().height / 2);
		rating.insert(make_pair(it.second->getScore(), text));
	}
	sf::Vector2f pos = { background.getSize().x/2, 20 };
	window.draw(background);
	for (auto it = rating.rbegin(); it != rating.rend(); it++)
	{
		it->second.setPosition(pos);
		window.draw(it->second);
		pos.y += it->second.getLocalBounds().height*1.5;
	}
}
