#include "HealthIndicator.h"



HealthIndicator::HealthIndicator(float maxHealth) : maxHP(maxHealth), highlight(false)
{
	indicBack.setSize(sf::Vector2f(width, height));
	indicBack.setFillColor(back);
	indicBack.setOutlineColor(sf::Color::Black);
	indicBack.setOutlineThickness(1);
	indicBack.setOrigin(width / 2, height / 2);

	indicFront.setFillColor(front);
	indicFront.setSize(sf::Vector2f(width, height));
}

void HealthIndicator::display(sf::RenderWindow & window, float hp, sf::Vector2f playerPos)
{
	playerPos.y -= offset;
	indicBack.setPosition(playerPos);
	indicFront.setPosition(indicBack.getPosition() - sf::Vector2f(width / 2, height / 2));
	indicFront.setSize(sf::Vector2f(width*(hp / maxHP), height));
	
	if (highlight)
	{
		indicBack.setOutlineColor(sf::Color::Cyan);
		indicBack.setOutlineThickness(2);
	}
	window.draw(indicBack);
	window.draw(indicFront);
}


HealthIndicator::~HealthIndicator()
{
}
