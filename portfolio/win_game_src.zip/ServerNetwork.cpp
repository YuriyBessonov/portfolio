#include "ServerNetwork.h"

ServerNetwork::ServerNetwork(int port) : clientsN(0)
{
	WSADATA wsaDATA;
	if (WSAStartup(0x202, &wsaDATA))
	{
		cout << "[!]ServerNetwork: WSAStart error " << WSAGetLastError() << endl;
		system("PAUSE");
		exit(-1);
	}
	listenSocket = socket(AF_INET, SOCK_STREAM, 0);
	if (listenSocket < 0)
	{
		cout << "[!]ServerNetwork: socket() error " << WSAGetLastError() << endl;
		system("PAUSE");
		exit(-1);
	}
	
	sockaddr_in listenAddr;
	listenAddr.sin_family = AF_INET;
	listenAddr.sin_port = htons(port);
	listenAddr.sin_addr.s_addr = 0;

	if (bind(listenSocket, (struct sockaddr *) &listenAddr, sizeof(listenAddr))) 
	{
		cout << "[!]ServerNetwork: bind() error " << WSAGetLastError() << endl;
		closesocket(listenSocket);
		WSACleanup();
		system("PAUSE");
		exit(-1);
	}

	if (listen(listenSocket, SOMAXCONN) == SOCKET_ERROR) 
	{
		cout << "[!]ServerNetwork: listen() error " << WSAGetLastError() << endl;
		closesocket(listenSocket);
		WSACleanup();
		system("PAUSE");
		exit(-1);
	}
}

bool ServerNetwork::acceptNewClient(int id)
{
	clientSocket = accept(listenSocket, NULL, NULL);

	if (clientSocket != INVALID_SOCKET)
	{
		char value = 1;
		setsockopt(clientSocket, IPPROTO_TCP, TCP_NODELAY, &value, sizeof(value));

		sessions[id] = clientSocket;
		clientsN++;

		const unsigned int packetSize = sizeof(Packet);
		char packetData[packetSize];
		Packet packet;
		packet.type = INIT;
		packet.id = id;
		packet.serialize(packetData);
		send(clientSocket, packetData, packetSize, 0);

		Client *client = new Client;
		client->id = id;
		client->sock = clientSocket;
		ServerGame::beginClientThread(client);

		std::cout << "New client accepted: " << id << std::endl;

		return true;
	}

	return false;
}

int ServerNetwork::receiveFromClient(unsigned int clientID, char *buf)
{
	if (!sessions.count(clientID))
		return 0;
	int result = recv(sessions[clientID], buf, MAX_PACKET_SIZE, 0);

	if (result == 0)
	{
		cout << "[!]ServerNetwork: connection closed ";
		closesocket(sessions[clientID]);
	}

	return result;
}


void ServerNetwork::sendPacket(SOCKET sock, Packet packet)
{
	char buf[MAX_PACKET_SIZE];
	packet.serialize(buf);
	int result = send(sock, buf, sizeof(Packet), 0);
	if (result == SOCKET_ERROR)
	{
		cout << "[!]ServerNetwork: send failed with error " << WSAGetLastError();
		closesocket(sock);
	}
}

int ServerNetwork::receivePacket(SOCKET sock, Packet &packet)
{
	char buf[MAX_PACKET_SIZE];
	int result = recv(sock, buf, MAX_PACKET_SIZE, 0);
	
	if (result == 0)
	{
		cout << "[!]ServerNetwork: connection closed ";
		closesocket(sock);
	}
	else if (result > 0)
		packet.deserialize(buf);
	return result;
}

