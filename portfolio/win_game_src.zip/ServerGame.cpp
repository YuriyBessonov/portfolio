#include "ServerGame.h"

unsigned int ServerGame::receivedPackets = 0;
const int  ServerGame::pointsForKill = 50;
const int  ServerGame::pointsForHit = 10;
HANDLE ServerGame::hMutex = NULL;
HANDLE ServerGame::shotsMutex = NULL;
HANDLE ServerGame::allPacketsProcessedEvt = NULL;
HANDLE ServerGame::packetsReceived[maxClients];
HANDLE ServerGame::packetsSent[maxClients];
Packet  ServerGame::packets[maxClients];
Properties ServerGame::properties[maxClients];
set<int> ServerGame::received;
list<ShotData*>  ServerGame::shots;
bool ServerGame::readyToProcess;


int operation = 0;
ServerGame::ServerGame()
{
	clientID = 0;
	network = new ServerNetwork();
	if (hMutex == NULL)
		hMutex = CreateMutex(NULL, FALSE, NULL);
	if (shotsMutex == NULL)
		shotsMutex = CreateMutex(NULL, FALSE, NULL);
	if (allPacketsProcessedEvt == NULL)
		allPacketsProcessedEvt = CreateEvent(NULL, FALSE, TRUE, NULL);

	for (int i = 0; i < maxClients; i++)
	{
		packets[i].type = INACTIVE;
		packetsReceived[i] = CreateEvent(NULL, FALSE, TRUE, NULL);
		properties[i].health = Player::maxHealth;
		properties[i].score = 0;
	}
		
}

void ServerGame::run()
{
	while (true)
		update();
}

void ServerGame::update()
{
	if (network->acceptNewClient(clientID))
	{
		std::cout << "Client " << clientID << " has been connected to the server" << endl;
		clientID++;
	}
	if (network->clientsN == 0)
		return;
}


void ServerGame::beginClientThread(Client* client)
{
	_beginthread(clientThreadFunc, 0, (void*)client);
}
void ServerGame::clientThreadFunc(void * arg)
{
	Client* client = (Client*)arg;
	SOCKET sock = client->sock;
	unsigned int id = client->id;
	Packet packet;
	while (1)
	{
		Sleep(20);
		packet.type = UPDATE_REQUEST;
		ServerNetwork::sendPacket(sock, packet);
		while (ServerNetwork::receivePacket(sock, packets[id]) <= 0);
		if (packets[id].type == SHOT)
		{
			sf::Vector2f v1 = packets[id].shotPosition, v2 = packets[id].position;
			float	a = v2.y - v1.y,
				b = v1.x - v2.x,
				c = v1.y*v2.x - v1.x*v2.y;
			float minDist = FLT_MAX;
			unsigned int nearest = id;
			WaitForSingleObject(hMutex, INFINITE);
			for (auto it : packets)
			{
				{
					float distSq = (it.position.x - packets[id].position.x)*(it.position.x - packets[id].position.x) +
						(it.position.y - packets[id].position.y)*(it.position.y - packets[id].position.y);
					if (distSq < minDist)
						minDist = distSq, nearest = it.id;
				}
			}
			ReleaseMutex(hMutex);
			if (nearest != id)
			{
				properties[nearest].health -= Player::healthPerShot;
				properties[id].score += (properties[nearest].health <= 0) ? pointsForKill : pointsForHit;
			}
		}
		packets[id].score = properties[id].score;
		packets[id].health = properties[id].health;
		for (int i = 0; i < ServerGame::maxClients; i++)
		{
			WaitForSingleObject(hMutex, INFINITE);
			if (packets[i].type != INACTIVE)
				ServerNetwork::sendPacket(sock, packets[i]);
			ReleaseMutex(hMutex);
		}

	}
}