package app.ybessonov.calculator.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import app.ybessonov.calculator.R;
import mehdi.sakout.aboutpage.AboutPage;
import mehdi.sakout.aboutpage.Element;

/**
 * Класс активности справки
 */
public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Element appTitle = new Element();
        appTitle.setTitle(getString(R.string.app_author));
        String description = getString(R.string.app_description);
        View about = new AboutPage(this).addItem(appTitle).setDescription(description).create();
        setContentView(about);
    }
}
