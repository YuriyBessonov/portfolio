package app.ybessonov.calculator.editor;


import app.ybessonov.calculator.control.TCtrl;

/**
 * Класс редкатора простых дробей
 */
public class TFEdit extends TAEdit {

    public TFEdit(String number) {
        super(number);
    }

    public TFEdit() {
        super();
    }

    public boolean hasDelim() {
        for (int i = number.length() - 1; i > 0; i--) {
            if (number.charAt(i) == SEPARATOR) {
                return true;
            }
        }
        return false;
    }

    @Override
    public String addDelim() {
        if (!isZero() && !hasDelim()) {
            number.append(SEPARATOR);
        }
        return toString();
    }

    @Override
    public String addZero() {
        if (number.length() > 0 && (isZero() || number.charAt(number.length() - 1) == SEPARATOR)) {
            return toString();
        }
        number.append(ZERO);
        return toString();
    }

    @Override
    public String backspace() {
        if (number.length() > 0) {
            number.deleteCharAt(number.length() - 1);
        }
        if (number.length() == 0) {
            signed = false;
            addZero();
        }
        return toString();
    }

    @Override
    public String edit(int n) {
        switch (n) {
            case TCtrl.CMD_BS:
                return backspace();
            case TCtrl.CMD_CLR:
                return clear();
            case TCtrl.CMD_DELIM:
                return addDelim();
            case TCtrl.CMD_SIGN:
                return sign();
            default:
                return addDigit(n);
        }
    }

    @Override
    public boolean isZero() {
        return number.toString().compareTo(ZERO_STR) == 0;
    }

    private boolean numIsVeryLong() {
        if (!hasDelim()) {
            if (number.length() >= MAX_LEN) {
                return true;
            }
        } else if (number.toString().split("/")[0].length() >= MAX_LEN) {
            return true;
        }
        return false;
    }

    private boolean denomIsVeryLong() {
        return number.toString().split("/").length > 1 &&
                number.toString().split("/")[1].length() >= MAX_LEN;
    }

    @Override
    protected boolean isVeryLong() {
        return numIsVeryLong() || denomIsVeryLong();
    }

}
