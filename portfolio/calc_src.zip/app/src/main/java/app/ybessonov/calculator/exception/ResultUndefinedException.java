package app.ybessonov.calculator.exception;

/**
 * Исключение, связанное с неопределенным результатом операции
 */
public class ResultUndefinedException extends RuntimeException {
    public ResultUndefinedException(String value) {
        super("Значение результата операции для аргумента " + value + " не определено");
    }
}
