package app.ybessonov.calculator.number;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import app.ybessonov.calculator.exception.IncompatibleTypeException;
import app.ybessonov.calculator.exception.ResultUndefinedException;

/**
 * АТД Комплексное число
 */
public class TComplex extends TANumber implements Comparable<TComplex> {
    public static final String RE_IM_DELIM = " + i*";
    //строковые константы ошибок
    private static final String WRONG_FORMAT_ERR = "Неверный формат задания комплексного числа";
    private static final String WRONG_EXP_ERR = "Недопустимое значение степени";
    private static final String WRONG_ROOT_NUM_ERR = "Недопустимое значение номера корня";
    private static final String DIVISION_BY_ZERO_ERR = "Делитель равен 0, деление невозможно";
    private static ViewFormat viewFormat;
    //действительная часть
    private TPNumber re;
    //мнимая часть
    private TPNumber im;


    public TComplex(TPNumber a, TPNumber b) {
        re = a;
        im = b;
    }

    public TComplex() {
        re = new TPNumber();
        im = new TPNumber();
    }

    public TComplex(String compStr, int base) {
        final String REGEXP = "([-]?[0-9]+([.][0-9]+)*)\\s[+]\\si[*]([-]?[0-9]+([.][0-9]+)*)";
        if (compStr.matches(REGEXP)) {
            final String PATTERN = "[-]?[0-9]+([.][0-9]+)*";
            Pattern p = Pattern.compile(PATTERN);
            Matcher m = p.matcher(compStr);
            String aStr = "", bStr = "";
            if (m.find()) {
                aStr = compStr.substring(m.start(), m.end());
            }
            if (m.find()) {
                bStr = compStr.substring(m.start(), m.end());
            }
            TPNumber a, b;

            re = new TPNumber(aStr, base);
            im = new TPNumber(bStr, base);
        } else {
            re = new TPNumber(compStr, base);
            im = new TPNumber(0, base);
        }
    }

    public static ViewFormat getViewFormat() {
        return viewFormat;
    }

    public static void setViewFormat(ViewFormat format) {
        viewFormat = format;
    }

    @Override
    public TComplex copy() {
        return new TComplex(re, im);
    }

    @Override
    public TComplex add(TANumber d) throws IncompatibleTypeException {
        if (!(d instanceof TComplex)) {
            throw new IncompatibleTypeException();
        }
        TComplex dc = (TComplex) d;
        return new TComplex(re.add(dc.re), im.add(dc.im));
    }

    @Override
    public TComplex mult(TANumber dc) {
        if (!(dc instanceof TComplex)) {
            throw new IncompatibleTypeException();
        }
        TComplex d = (TComplex) dc;
        TPNumber a1 = re;
        TPNumber b1 = im;
        TPNumber a2 = d.re;
        TPNumber b2 = d.im;
        return new TComplex((a1.mult(a2)).sub(b1.mult(b2)), (a1.mult(b2)).add(b1.mult(a2)));
    }

    @Override
    public TComplex square() {
        return mult(this);
    }

    @Override
    public TANumber zeroInstance() {
        return new TComplex();
    }

    @Override
    public TComplex reverse() {
        if (isZero()) {
            throw new ArithmeticException(DIVISION_BY_ZERO_ERR);
        }
        TPNumber denom = (re.mult(re)).add(im.mult(im));
        TPNumber a = re.div(denom);
        TPNumber b = (im.div(denom)).minus();
        return new TComplex(a, b);
    }

    @Override
    public TComplex sub(TANumber dc) {
        if (!(dc instanceof TComplex)) {
            throw new IncompatibleTypeException();
        }
        TComplex d = (TComplex) dc;
        return new TComplex(re.sub(d.re), im.sub(d.im));
    }

    @Override
    public TComplex div(TANumber dc) {
        if (!(dc instanceof TComplex)) {
            throw new IncompatibleTypeException();
        }
        TComplex d = (TComplex) dc;
        if (d.isZero()) {
            throw new ArithmeticException(DIVISION_BY_ZERO_ERR);
        }
        TPNumber a1 = re;
        TPNumber b1 = im;
        TPNumber a2 = d.re;
        TPNumber b2 = d.im;
        TPNumber denom = a2.mult(a2).add(b2.mult(b2));
        TPNumber ar = a1.mult(a2).add(b1.mult(b2)).div(denom);
        TPNumber br = a2.mult(b1).sub(a1.mult(b2)).div(denom);
        return new TComplex(ar, br);
    }

    //Получить число, являющееся разностью числа 0 + i*0 и текущего
    public TComplex minus() {
        return new TComplex().sub(this);
    }

    //Получить модуль самого комплексного числа
    public TPNumber abs() {
        return (re.mult(re).add(im.mult(im))).sqrt();
    }

    //Получить угол текужего числа в радианах
    public double angleRad() {
        if (isZero()) {
            throw new ResultUndefinedException(toString());
        }
        TPNumber a = re;
        TPNumber b = im;
        double ret = 0;
        if (a.getNumber() > 0) {
            ret = Math.atan(b.getNumber() / a.getNumber());
        } else if (a.getNumber() < 0) {
            ret = Math.atan(b.getNumber() / a.getNumber()) + Math.PI;
        } else {
            if (b.getNumber() < 0) {
                ret = -Math.PI / 2;
            } else if (b.getNumber() > 0) {
                ret = Math.PI / 2;
            }
        }
        return ret;
    }

    //Получить угол текужего числа в градусах
    public double angleDeg() {
        return angleRad() * (180.0 / Math.PI);
    }

    //Получить данное число в целой положительной степени
    public TComplex pow(int n) {
        if (n < 1) {
            throw new IllegalArgumentException(WRONG_EXP_ERR + " " + n);
        }
        double r = Math.pow(abs().getNumber(), n);
        double ang = angleRad();
        TPNumber a = new TPNumber(r * Math.cos(n * ang), re.getBase());
        TPNumber b = new TPNumber(r * Math.sin(n * ang), re.getBase());
        return new TComplex(a, b);
    }

    //Полцчить i-й корень заданной целой положительной степни текущего числа
    public TComplex root(int n, int i) {
        if (n < 1) {
            throw new IllegalArgumentException(WRONG_EXP_ERR + " " + n);
        }
        if (i < 0 || i >= n) {
            throw new IllegalArgumentException(WRONG_ROOT_NUM_ERR + " " + i);
        }
        double r = Math.pow(abs().getNumber(), 1.0 / (double) n);
        double ang = angleRad();
        double a = r * Math.cos((ang + 2 * Math.PI * (double) i) / (double) n);
        double b = r * Math.sin((ang + 2 * Math.PI * (double) i) / (double) n);
        return new TComplex(new TPNumber(a, re.getBase()), new TPNumber(b, re.getBase()));
    }

    //Равенство текущего и другого чисел
    public boolean equals(TComplex d) {
        return (re == d.re) && (im == d.im);
    }

    //Неравенство текущего и другого чисел
    public boolean notEquals(TComplex d) {
        return !equals(d);
    }

    public TPNumber getReValue() {
        return re;
    }

    public TPNumber getImValue() {
        return im;
    }

    //Получить строковое представление действительной части числа
    public String getReStr() {
        return re.toString();
    }

    //Получить строковое представление мнимой части числа
    public String getImStr() {
        return im.toString();
    }

    @Override
    public String toString() {
        if (im.isZero() && viewFormat == ViewFormat.SHORT) {
            return getReStr();
        }
        return getReStr() + " + i*" + getImStr();
    }

    @Override
    public boolean isZero() {
        return re.isZero() && im.isZero();
    }

    @Override
    public int compareTo(TComplex tc) {
        if (this.equals(tc)) {
            return 0;
        } else if (this.abs().getNumber() > tc.abs().getNumber()) {
            return 1;
        } else {
            return -1;
        }
    }
}
