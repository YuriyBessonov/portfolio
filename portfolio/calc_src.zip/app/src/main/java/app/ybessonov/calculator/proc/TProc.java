package app.ybessonov.calculator.proc;


import java.io.Serializable;

import app.ybessonov.calculator.number.TANumber;

/**
 * АТД "Процессор"
 */
public class TProc implements Serializable {
    //левый операнд/результат
    private TANumber lOpRes;
    //правый операнд
    private TANumber rOp;

    //текущая операция (состояние)
    private TOprtn operation;
    //значение операнда по умолчанию
    private TANumber defaultVal;

    public TProc(TANumber leftOp, TANumber rightOp, TANumber deflt) {
        this.defaultVal = deflt.copy();
        reset();
        lOpRes = leftOp;
        rOp = rightOp;
    }

    public TANumber getDeftVal() {
        return defaultVal;
    }

    //Сброс операции и установка значений операндов по умолчанию
    public void reset() {
        lOpRes = defaultVal.copy();
        rOp = defaultVal.copy();
        resetOperation();
    }

    //Сброс операции
    public void resetOperation() {
        operation = TOprtn.NONE;
    }

    //Выполнение текущей операции, если она задана и сохранение
    //результата в левом операнде
    public void performOperation() {
        switch (operation) {
            case ADD:
                lOpRes = lOpRes.add(rOp);
                break;
            case SUB:
                lOpRes = lOpRes.sub(rOp);
                break;
            case MUL:
                lOpRes = lOpRes.mult(rOp);
                break;
            case DIV:
                lOpRes = lOpRes.div(rOp);
                break;
        }
    }

    //Выполнение функции над левым операндом с сохранением рез-та в него же
    public void performFunction(TFunc func) {
        switch (func) {
            case REV:
                rOp = rOp.reverse();
                break;
            case SQR:
                rOp = rOp.square();
                break;
        }
    }

    public TANumber getLeftOp() {
        return lOpRes;
    }

    public void setLeftOp(TANumber leftOp) {
        lOpRes = leftOp.copy();
    }

    public TANumber getRightOp() {
        return rOp;
    }

    public void setRightOp(TANumber rightOp) {
        rOp = rightOp.copy();
    }

    public TOprtn getOperation() {
        return operation;
    }

    public void setOperation(TOprtn operation) {
        this.operation = operation;
    }


    //тип операции
    public enum TOprtn {
        NONE, ADD, SUB, MUL, DIV
    }

    //функция
    public enum TFunc {
        REV, SQR
    }
}
