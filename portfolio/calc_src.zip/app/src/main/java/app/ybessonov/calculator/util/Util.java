package app.ybessonov.calculator.util;

/**
 * Утилитный класс
 */
public class Util {
    private static final String WRONG_DIGIT_ERR = "Недопустимое значение цифры: ";
    private static final int MAX_P = 16;

    private Util() {
    }

    //Наибольший общий делитель двух заданных целых чисел
    public static long gcd(long a, long b) {
        while (b != 0) {
            a %= b;
            long t = a;
            a = b;
            b = t;
        }
        return a;
    }

    //Получить цифру в виде симвода
    public static char int_to_char(int d) throws IllegalArgumentException {
        if (d < 0 || d > MAX_P - 1) {
            throw new IllegalArgumentException(WRONG_DIGIT_ERR + d);
        }
        return Character.forDigit(d, MAX_P);
    }

    //Получить цифру для символа
    public static double charToNum(char ch) {
        int digit = Character.digit(ch, MAX_P);
        if (digit < 0) {
            throw new IllegalArgumentException(WRONG_DIGIT_ERR + ch);
        }
        return (double) digit;
    }

    //Получить критическую длину числа для заданной системы счисления
    public static int getCriticalLen(int base) {
        if (base > 16 || base < 2) {
            return 0;
        }
        int[] len = new int[]{0, 0, 38, 37, 29, 25, 23, 21, 19, 18, 18, 17, 16, 16, 15, 15, 14};
        return len[base];
    }
}
