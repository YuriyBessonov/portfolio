package app.ybessonov.calculator.number;

import app.ybessonov.calculator.editor.TAEdit;
import app.ybessonov.calculator.exception.IncompatibleTypeException;
import app.ybessonov.calculator.util.Util;

/**
 * АТД Простая дробь
 */
public class TFrac extends TANumber implements Comparable<TFrac> {
    //константы ошибок
    private static final String NULL_DENOMINATOR_ERR = "Знаменатель не может быть равен нулю!";
    private static final String WRONG_FORMAT_ERR = "Неверный формат дроби ";
    private static final String WRONG_NUMERATOR_ERR = "Неверный формат числителя ";
    private static final String WRONG_DENOMINATOR_ERR = "Неверный формат числителя ";
    private static ViewFormat viewFormat;
    //числитель
    private long numerator;
    //знаменатель
    private long denominator;

    public TFrac(long a, long b) throws IllegalArgumentException {
        if (b == 0) {
            throw new IllegalArgumentException(NULL_DENOMINATOR_ERR);
        }
        if (b < 0) {
            a = -a;
            b = -b;
        }
        numerator = a;
        denominator = b;
        reduce();
    }

    public TFrac() {
        numerator = 0;
        denominator = 1;
    }

    public TFrac(String f) throws IllegalArgumentException {
        String[] fracParts;
        if (f.split("/").length == 2) {
            fracParts = f.split("/");
        } else {
            if (f.endsWith("/")) {
                f = f.substring(0, f.length() - 1);
            }
            fracParts = new String[]{f, "1"};
        }
        long a, b;
        try {
            a = Long.parseLong(fracParts[0]);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(WRONG_NUMERATOR_ERR + fracParts[0]);
        }
        try {
            b = Long.parseLong(fracParts[1]);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(WRONG_DENOMINATOR_ERR + fracParts[1]);
        }
        numerator = a;
        denominator = b;
        reduce();
    }

    public static ViewFormat getViewFormat() {
        return viewFormat;
    }

    public static void setViewFormat(ViewFormat format) {
        viewFormat = format;
    }

    @Override
    public boolean isZero() {
        return numerator == 0;
    }

    @Override
    public TFrac copy() {
        return new TFrac(numerator, denominator);
    }

    @Override
    public TFrac add(TANumber df) throws IncompatibleTypeException {
        if (!(df instanceof TFrac)) {
            throw new IncompatibleTypeException();
        }
        TFrac d = (TFrac) df;
        long a = numerator * d.denominator + d.numerator * denominator;
        long b = denominator * d.denominator;
        return new TFrac(a, b);
    }

    @Override
    public TFrac mult(TANumber df) {
        if (!(df instanceof TFrac)) {
            throw new IncompatibleTypeException();
        }
        TFrac d = (TFrac) df;
        TFrac res;
        long a = numerator * d.numerator;
        long b = denominator * d.denominator;
        res = new TFrac(a, b);
        return res;
    }

    @Override
    public TFrac sub(TANumber df) {
        if (!(df instanceof TFrac)) {
            throw new IncompatibleTypeException();
        }
        TFrac d = (TFrac) df;
        long a = numerator * d.denominator - d.numerator * denominator;
        long b = denominator * d.denominator;
        return new TFrac(a, b);
    }

    @Override
    public TFrac div(TANumber df) {
        if (!(df instanceof TFrac)) {
            throw new IncompatibleTypeException();
        }
        return mult(df.reverse());
    }

    @Override
    public TFrac square() {
        return mult(this);
    }

    @Override
    public TANumber zeroInstance() {
        return new TFrac();
    }

    @Override
    public TFrac reverse() {
        long a = denominator;
        long b = numerator;
        return new TFrac(a, b);
    }

    public TFrac minus() {
        return new TFrac(-numerator, denominator);
    }

    //Равенство текущей и другой дробей
    public boolean equals(TFrac d) {
        return (numerator == d.numerator)
                && (denominator == d.denominator);
    }

    //Больше ли другой текущая дробь
    public boolean greater(TFrac d) {
        long a1 = numerator * d.denominator;
        long a2 = d.numerator * denominator;
        return a1 > a2;
    }

    public long getNumeratorValue() {
        return numerator;
    }

    public long getDenominatorValue() {
        return denominator;
    }

    public String getNumeratorString() {
        return Long.toString(numerator);
    }

    public String getDenominatorString() {
        return Long.toString(denominator);
    }

    @Override
    public String toString() {
        if (viewFormat == ViewFormat.SHORT) {
            if (numerator == 0) {
                return TAEdit.ZERO_STR;
            } else if (denominator == 1) {
                return getNumeratorString();
            }
        }
        return getNumeratorString() + "/" + getDenominatorString();
    }

    //Сократить дробь
    private void reduce() {
        long GCD = Util.gcd(Math.abs(numerator), denominator);
        numerator /= GCD;
        denominator /= GCD;
        if (numerator == 0) {
            denominator = 1;
        }
    }

    @Override
    public int compareTo(TFrac tf) {
        if (this.equals(tf)) {
            return 0;
        } else if (this.greater(tf)) {
            return 1;
        } else {
            return -1;
        }
    }
}
