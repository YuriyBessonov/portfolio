package app.ybessonov.calculator.exception;

/**
 * Исключение "Аргумент несовместиммого класса"
 */
public class IncompatibleTypeException extends RuntimeException {
    public IncompatibleTypeException(String message) {
        super(message);
    }

    public IncompatibleTypeException() {
        super("Аргументом является объект несовместимого класса");
    }
}
