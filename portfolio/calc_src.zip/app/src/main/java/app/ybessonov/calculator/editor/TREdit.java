package app.ybessonov.calculator.editor;

import app.ybessonov.calculator.util.Util;

/**
 * Класс редкатора p-ичных чисел
 */
public class TREdit extends TFEdit {

    private int base;

    public TREdit(String number, int base) {
        super(number);
        this.base = base;
    }

    public TREdit(int base) {
        super();
        this.base = base;
    }

    public int getBase() {
        return base;
    }

    public void setBase(int base) {
        this.base = base;
    }

    //Удалить лишние нули
    public String simplify() {
        if (!isZero()) {
            int i;
            boolean hasPoint = false;
            for (i = number.length() - 1; number.charAt(i) == ZERO; i--) ;
            if (number.charAt(i) == POINT) {
                i--;
                hasPoint = true;
            }
            for (int j = i; j >= 0; j--) {
                if (number.charAt(j) == POINT) {
                    hasPoint = true;
                    break;
                }
            }
            if (hasPoint)
                number = new StringBuilder(number.substring(0, i + 1));
        }
        return toString();
    }


    @Override
    public String addDelim() {
        if (!hasDelim()) {
            number.append(POINT);
        }
        return toString();
    }

    @Override
    public boolean hasDelim() {
        for (int i = number.length() - 1; i > 0; i--) {
            if (number.charAt(i) == POINT) {
                return true;
            }
        }
        return false;
    }


    @Override
    public void setNumber(String number) {
        super.setNumber(number);
        simplify();
    }

    @Override
    public String addZero() {
        if (!isZero()) {
            number.append(ZERO);
        }
        return toString();
    }

    //Точность числа
    public int acc() {
        int accuracy = 0;
        if (hasDelim()) {
            int i;
            for (i = number.length() - 1; number.charAt(i) == ZERO; i--) ;
            for (; number.charAt(i) != POINT; i--, accuracy++) ;
        }
        return accuracy;
    }

    //Максимально возможная система счисления для данного числа
    public int getSupposedBase() {
        int maxDigit = 0;
        for (int i = 0; i < number.length(); i++) {
            if (number.charAt(i) != POINT && number.charAt(i) != MINUS) {
                int digit = (int) Util.charToNum(number.charAt(i));
                if (digit > maxDigit) {
                    maxDigit = digit;
                }
            }
        }
        return Math.max(2, maxDigit + 1);
    }

    @Override
    protected boolean isVeryLong() {
        int limit = Util.getCriticalLen(base);
        if (hasDelim()) {
            limit++;
        }
        if (number.length() >= limit) {
            return true;
        }
        return false;
    }
}
