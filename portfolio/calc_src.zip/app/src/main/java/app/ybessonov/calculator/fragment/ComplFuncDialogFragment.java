package app.ybessonov.calculator.fragment;

import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

import app.ybessonov.calculator.R;
import app.ybessonov.calculator.model.TClipBoard;
import app.ybessonov.calculator.number.TComplex;
import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Диалог выполнения комплексной функции возведения в стемень/извлечения корня
 */

public class ComplFuncDialogFragment extends DialogFragment {
    private static final String TAG_FUNC = "FUNC";
    private static final String TAG_ARG = "ARG";
    private static final int MAX_POW = 100;

    @BindView(R.id.btn_copy)
    Button btnCopy;
    @BindView(R.id.btn_calc)
    Button btnCalc;
    @BindView(R.id.btn_back)
    Button btnBack;
    @BindView(R.id.et_number)
    EditText etNumber;
    @BindView(R.id.et_pow)
    EditText etPow;
    @BindView(R.id.layout_number)
    LinearLayout layoutNumber;
    @BindView(R.id.tv_func_res)
    TextView tvResult;
    //Исполняемая функция
    private Func func;
    //Аргумент функции
    private TComplex arg;

    //Обработчик клика на кнопку Вычислить
    private View.OnClickListener onCalcBtnClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (etPow.getText().toString().isEmpty()) {
                Toast.makeText(getActivity(), String.format(
                        getString(R.string.format_field_is_empty),
                        getString(R.string.power)),
                        Toast.LENGTH_SHORT).show();
                return;
            }
            int n = Integer.parseInt(etPow.getText().toString());
            if (n == 0 || n > MAX_POW) {
                Toast.makeText(getActivity(), String.format(Locale.getDefault(),
                        getString(R.string.format_a1_should_not_exceed_a2_and_be_equal_to_zero),
                        getString(R.string.power), MAX_POW),
                        Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                if (func == Func.POW) {
                    tvResult.setText(arg.pow(n).toString());
                    btnCopy.setEnabled(true);
                } else {
                    if (etNumber.getText().toString().isEmpty()) {
                        Toast.makeText(getActivity(), String.format(
                                getString(R.string.format_field_is_empty),
                                getString(R.string.number)),
                                Toast.LENGTH_SHORT).show();
                        return;
                    }
                    int i = Integer.parseInt(etNumber.getText().toString());
                    if (i >= n) {
                        Toast.makeText(getActivity(), String.format(Locale.getDefault(),
                                getString(R.string.format_a1_must_be_in_range_from_zero_to_a2),
                                getString(R.string.power), n),
                                Toast.LENGTH_SHORT).show();
                        return;
                    }
                    tvResult.setText(arg.root(n, i).toString());
                    btnCopy.setEnabled(true);
                }
            } catch (RuntimeException e) {
                Toast.makeText(getActivity(), e.toString(), Toast.LENGTH_SHORT).show();
            }
        }
    };

    //Обработчик клика на кнопку Копировать
    private View.OnClickListener onCopyBtnClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            TClipBoard.set(tvResult.getText().toString());
            Toast.makeText(getActivity(), getString(R.string.copied) + tvResult.getText().toString(),
                    Toast.LENGTH_SHORT).show();
        }
    };

    //Обработчик клика на кнопку ОК
    private View.OnClickListener onBackBtnClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            dismiss();
        }
    };

    public static ComplFuncDialogFragment newInstance(Func f, String arg) {
        ComplFuncDialogFragment dialog = new ComplFuncDialogFragment();

        Bundle args = new Bundle();
        args.putString(TAG_FUNC, f.toString());
        args.putString(TAG_ARG, arg);
        dialog.setArguments(args);

        return dialog;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        func = Func.valueOf(getArguments().getString(TAG_FUNC));
        arg = new TComplex(getArguments().getString(TAG_ARG), 10);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_func_dialog, container, false);
        ButterKnife.bind(this, v);

        if (func == Func.POW) {
            layoutNumber.setVisibility(View.GONE);
        }
        btnCopy.setEnabled(false);

        btnBack.setOnClickListener(onBackBtnClick);
        btnCalc.setOnClickListener(onCalcBtnClick);
        btnCopy.setOnClickListener(onCopyBtnClick);

        return v;
    }

    public enum Func {ROOT, POW}
}