package app.ybessonov.calculator.memory;

import app.ybessonov.calculator.number.TANumber;
import app.ybessonov.calculator.exception.IncompatibleTypeException;

/**
 * Класс памяти
 */
public class TMemory {
    //Число
    private TANumber number;
    private State state;

    public TMemory() {
        this.number = null;
        this.state = State.OFF;
    }

    //Сохранить число
    public void store(TANumber number) {
        this.number = number.copy();
        this.state = State.ON;
    }

    //Читать число
    public TANumber readNum() {
        return (number == null) ? null : number.copy();
    }

    //Получить число
    public TANumber getNum() {
        return number;
    }

    //Получить
    public TANumber get() {
        state = State.ON;
        return (number == null) ? null : number.copy();
    }

    //Добавить к содержимому памяти
    public void add(TANumber other) throws IncompatibleTypeException {
        if (this.number != null) {
            this.number = number.add(other);
        } else {
            store(other);
        }
    }

    //Сбросить память
    public void clear() {
        this.number = null;
        this.state = State.OFF;
    }

    //Получить состояние в виде строки
    public String getStateStr() {
        return (state == State.ON) ? "вкл." : "выкл.";
    }

    //Получить состояние
    public State getState() {
        return state;
    }

    //Получить содержимое памяти как строку
    public String getNumberStr() {
        if (number == null) {
            return null;
        }
        return number.toString();
    }

    //Состояниие памяти
    public enum State {ON, OFF}
}
