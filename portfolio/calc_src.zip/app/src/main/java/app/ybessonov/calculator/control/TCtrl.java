package app.ybessonov.calculator.control;


import android.content.Context;
import android.widget.Toast;

import app.ybessonov.calculator.R;
import app.ybessonov.calculator.editor.TAEdit;
import app.ybessonov.calculator.editor.TCEdit;
import app.ybessonov.calculator.editor.TFEdit;
import app.ybessonov.calculator.editor.TREdit;
import app.ybessonov.calculator.memory.TMemory;
import app.ybessonov.calculator.number.TANumber;
import app.ybessonov.calculator.number.TComplex;
import app.ybessonov.calculator.number.TFrac;
import app.ybessonov.calculator.number.TPNumber;
import app.ybessonov.calculator.proc.TProc;
import app.ybessonov.calculator.model.History;
import app.ybessonov.calculator.model.TClipBoard;

/**
 * Класс управления универсальным калькулятором
 */
public class TCtrl {
    //Команды
    public static final int OP_ADD = 16;
    public static final int OP_SUB = 17;
    public static final int OP_MUL = 18;
    public static final int OP_DIV = 19;
    public static final int FN_SQR = 20;
    public static final int FN_INV = 21;
    public static final int CMD_BS = 22;
    public static final int CMD_CLR = 23;
    public static final int CMD_CE = 24;
    public static final int CMD_SIGN = 25;
    public static final int CMD_DELIM = 26;
    public static final int CMD_IM_DELIM = 27;
    public static final int CMD_EXEC = 28;
    public static final int CMD_COPY = 29;
    public static final int CMD_PASTE = 30;
    public static final int MEM_CLR = 31;
    public static final int MEM_STORE = 32;
    public static final int MEM_READ = 33;
    public static final int MEM_ADD = 34;
    public static final int COMPL_POW = 35;
    public static final int COMPL_ABS = 36;
    public static final int COMPL_ROOT = 37;
    public static final int COMPL_ARAD = 38;
    public static final int COMPL_ADEG = 39;

    //Состояние
    private State state;
    //Редактор
    private TAEdit edit;
    //Процессор
    private TProc proc;
    //Память
    private TMemory mem;
    //Число
    private TANumber num;
    //Основание системы счисления
    private int base;
    //История
    private History history;
    private Context context;


    public TCtrl(TANumber number, Context context) {
        state = State.START;
        this.context = context;
        base = 10;
        if (number instanceof TFrac) {
            edit = new TFEdit();
            proc = new TProc(new TFrac(), new TFrac(), new TFrac());
        } else if (number instanceof TComplex) {
            edit = new TCEdit();
            proc = new TProc(new TComplex(), new TComplex(), new TComplex());
        } else {
            edit = new TREdit(base);
            proc = new TProc(new TPNumber(), new TPNumber(), new TPNumber());
        }
        num = number;
        mem = new TMemory();
        history = new History();
    }

    public TAEdit getEdit() {
        return edit;
    }

    public TMemory getMem() {
        return mem;
    }

    public TANumber getNum() {
        return num;
    }

    public int getBase() {
        return base;
    }

    public String setBase(int base) {
        if (getEditNum() instanceof TPNumber) {
            TPNumber editNum = (TPNumber) getEditNum();
            this.base = base;
            //процессор
            ((TPNumber) proc.getLeftOp()).setBase(base);
            ((TPNumber) proc.getRightOp()).setBase(base);
            //память
            TANumber memNum = mem.getNum();
            if (memNum != null) {
                ((TPNumber) memNum).setBase(base);
            }
            //число
            ((TPNumber) num).setBase(base);

            editNum.setBase(base);
            ((TREdit) edit).setBase(base);
            edit.setNumber(editNum.toString());
        } else {
            this.base = base;
        }
        return edit.toString();
    }

    //Получить тип уоманды
    public CmdType getCmdType(int cmd) {
        if (cmd == OP_ADD || cmd == OP_SUB || cmd == OP_MUL || cmd == OP_DIV) {
            return CmdType.OPERATION;
        } else if (cmd == FN_SQR || cmd == FN_INV) {
            return CmdType.FUNCTION;
        } else if (cmd == MEM_CLR || cmd == MEM_STORE || cmd == MEM_READ || cmd == MEM_ADD) {
            return CmdType.MEMORY;
        } else if (cmd == CMD_EXEC || cmd == CMD_CLR) {
            return CmdType.OTHER;
        } else if (cmd == COMPL_ABS || cmd == COMPL_POW || cmd == COMPL_ROOT || cmd == COMPL_ARAD || cmd == COMPL_ADEG) {
            return CmdType.COMPL_FUNC;
        } else {
            return CmdType.EDITOR;
        }
    }

    //Сбросить калькулятор в исходное состояние
    public String reset() {
        state = State.START;
        edit.clear();
        proc.reset();
        num = num.zeroInstance();
        return num.toString();
    }

    //Выполнить команду
    public String performCalcOp(int cmd) {
        if (state == State.ERROR) {
            reset();
        }
        CmdType cmdType = getCmdType(cmd);
        try {
            switch (cmdType) {
                case EDITOR:
                    return doEditorCmd(cmd);
                case FUNCTION:
                    return doFunction(cmd);
                case MEMORY:
                    return doMemCmd(cmd);
                case OPERATION:
                    return doOperation(cmd);
                case COMPL_FUNC:
                    return edit.toString();
                default:
                    if (cmd == CMD_CLR) {
                        return reset();
                    } else {
                        return calcExpr();
                    }
            }
        } catch (RuntimeException e) {
            state = State.ERROR;
            Toast.makeText(context, e.getMessage(), Toast.LENGTH_LONG).show();
            return context.getString(R.string.error);
        }
    }

    //Выполнить команду редактора
    public String doEditorCmd(int cmd) {
        if (cmd == CMD_COPY) {
            return TClipBoard.set(edit.toString());
        }
        if (cmd == CMD_PASTE) {
            if (!TClipBoard.isEmpty()) {
                edit.setNumber(TClipBoard.get());
                if (state == State.EXP_DONE) {
                    proc.setLeftOp(proc.getDeftVal());
                }
                if (state == State.FUNC_DONE) {
                    proc.setRightOp(proc.getDeftVal());
                }
                setState(State.EDIT);
            }
            return edit.toString();
        } else if (cmd == CMD_CE) {
            edit.clear();
            if (state == State.START) {
                setState(State.START);
            } else {
                if (state == State.EXP_DONE) {
                    proc.setLeftOp(proc.getDeftVal());
                }
                if (state == State.FUNC_DONE) {
                    proc.setRightOp(proc.getDeftVal());
                }
                setState(State.EDIT);
            }
            return edit.edit(CMD_CLR);
        } else if (cmd == CMD_BS) {
            if (state != State.EDIT) {
                return num.toString();
            }
        } else if (cmd == CMD_SIGN) {
            if (state == State.EXP_DONE) {
                proc.setLeftOp(proc.getDeftVal());
            }
            if (state == State.FUNC_DONE) {
                proc.setRightOp(proc.getDeftVal());
            }
            if (state != State.EDIT) {
                state = State.EDIT;
                edit.setNumber(num.toString());
            }
        } else {
            if (state != State.EDIT) {
                edit.clear();
            }
            if (state == State.EXP_DONE) {
                proc.setLeftOp(proc.getDeftVal());
            }
            if (state == State.FUNC_DONE) {
                proc.setRightOp(proc.getDeftVal());
            }
            setState(State.EDIT);
        }
        return edit.edit(cmd);
    }

    //Выполнить арифметическую операцию
    public String doOperation(int op) {
        String res;
        if (state == State.EDIT) {
            TANumber operand = getEditNum();
            if (proc.getOperation() != TProc.TOprtn.NONE) {
                proc.setRightOp(operand);
                proc.performOperation();
            } else {
                proc.setLeftOp(operand);
            }
        } else if (state == State.FUNC_DONE) {
            if (proc.getOperation() != TProc.TOprtn.NONE) {
                proc.performOperation();
            }
        }
        res = proc.getLeftOp().toString();
        edit.setNumber(res);
        state = State.OP_DONE;
        switch (op) {
            case OP_ADD:
                proc.setOperation(TProc.TOprtn.ADD);
                break;
            case OP_SUB:
                proc.setOperation(TProc.TOprtn.SUB);
                break;
            case OP_MUL:
                proc.setOperation(TProc.TOprtn.MUL);
                break;
            case OP_DIV:
                proc.setOperation(TProc.TOprtn.DIV);
                break;
        }
        num = proc.getLeftOp();
        return res;
    }

    //Выполнить функцию
    public String doFunction(int func) {
        TANumber tmp = proc.getRightOp();
        if (state == State.EDIT) {
            proc.setRightOp(getEditNum());
        } else if (state != State.FUNC_DONE || proc.getOperation() == TProc.TOprtn.NONE) {
            proc.setRightOp(proc.getLeftOp());
        }

        TANumber lOp = proc.getRightOp();
        TProc.TFunc function;
        if (func == FN_INV) {
            proc.performFunction(TProc.TFunc.REV);
            function = TProc.TFunc.REV;

        } else { //FN_SQR
            proc.performFunction(TProc.TFunc.SQR);
            function = TProc.TFunc.SQR;
        }
        history.add(lOp, proc.getRightOp(), function);
        String res = proc.getRightOp().toString();
        edit.setNumber(res);
        boolean swap = false;
        if (!num.toString().equals(proc.getLeftOp().toString())) {
            swap = true;
        }
        num = proc.getRightOp();


        if (state == State.START || state == State.EXP_DONE) {
            proc.setLeftOp(proc.getRightOp());
            proc.setRightOp(tmp);
        } else if (state == State.EDIT) {
            if (proc.getOperation() == TProc.TOprtn.NONE || swap) {
                proc.setLeftOp(proc.getRightOp());
                proc.setRightOp(tmp);
            }
        } else if (state == State.FUNC_DONE) {
            if (proc.getOperation() == TProc.TOprtn.NONE) {
                proc.setLeftOp(proc.getRightOp());
                proc.setRightOp(tmp);
            }
        }
        if (state == State.START || state == State.EXP_DONE || swap) {
            state = State.EXP_DONE;
        } else {
            state = State.FUNC_DONE;
        }
        return res;
    }

    //Выполнить команду вычисления выражения
    public String calcExpr() {
        if (state == State.START) {
            return edit.toString();
        } else if (state == State.OP_DONE) {
            proc.setRightOp(proc.getLeftOp());
        } else if (state == State.EDIT) {
            if (getEditNum() instanceof TFrac) {
                TFrac frac = (TFrac) getEditNum();
                edit.setNumber(frac.toString());
            }
            if (proc.getOperation() == TProc.TOprtn.NONE) {
                return edit.toString();
            } else {
                if (!num.toString().equals(proc.getLeftOp().toString()) && !proc.getRightOp().isZero()) {
                    proc.setLeftOp(getEditNum());
                } else {
                    proc.setRightOp(getEditNum());
                }
            }
        } else if (state == State.FUNC_DONE) {
            if (proc.getOperation() == TProc.TOprtn.NONE) {
                state = State.EXP_DONE;
                return edit.toString();
            }
        }
        state = State.EXP_DONE;
        TANumber lOp = proc.getLeftOp();
        proc.performOperation();
        num = proc.getLeftOp();
        history.add(lOp, proc.getRightOp(), num, proc.getOperation());
        edit.setNumber(num.toString());
        return proc.getLeftOp().toString();
    }

    //Выполнить команду памяти
    public String doMemCmd(int cmd) {
        switch (cmd) {
            case MEM_ADD:
                mem.add(getEditNum());
                break;
            case MEM_CLR:
                mem.clear();
                break;
            case MEM_READ:
                if (mem.getState() == TMemory.State.ON) {
                    String tmp = TClipBoard.get();
                    TClipBoard.set(mem.getNumberStr());
                    doEditorCmd(CMD_PASTE);
                    TClipBoard.set(tmp);
                }
                break;
            case MEM_STORE:
                mem.store(getEditNum());
                break;
        }
        return edit.toString();
    }

    //Выполнить функцию над комплексным числом
    public String doComplFunc(int func, int arg1, int arg2) {
        TComplex c = (TComplex) getEditNum();
        try {
            switch (func) {
                case COMPL_ABS:
                    return c.abs().toString();
                case COMPL_ARAD:
                    return String.valueOf(c.angleRad());
                case COMPL_ADEG:
                    return String.valueOf(c.angleDeg());
                case COMPL_POW:
                    return c.pow(arg1).toString();
                case COMPL_ROOT:
                    return c.root(arg1, arg2).toString();
                default:
                    return "0";
            }
        } catch (RuntimeException e) {
            Toast.makeText(context, e.getMessage(), Toast.LENGTH_LONG).show();
            return context.getString(R.string.error);
        }
    }

    //Получить редкатируемое число
    private TANumber getEditNum() {
        if (num instanceof TPNumber) {
            return new TPNumber(edit.toString(), base);
        } else if (num instanceof TFrac) {
            return new TFrac(edit.toString());
        } else {
            return new TComplex(edit.toString(), base);
        }
    }

    public State getState() {
        return state;
    }

    private void setState(State state) {
        this.state = state;
    }


    public History getHist() {
        return history;
    }

    public enum CmdType {
        EDITOR, OPERATION, FUNCTION, MEMORY, COMPL_FUNC, OTHER
    }

    public enum State {START, EDIT, FUNC_DONE, OP_DONE, EXP_DONE, ERROR}
}
