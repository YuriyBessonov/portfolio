package app.ybessonov.calculator.model;

/**
 * Класс буффера обмена
 */
public class TClipBoard {
    //содержимое буфера обмена
    private static String clipboard;

    private TClipBoard() {}

    public static String get() {
        return clipboard;
    }

    public static String set(String str) {
        clipboard = str;
        return clipboard;
    }

    public static void clear() {
        clipboard = "";
    }

    public static boolean isEmpty() {
        return clipboard == null || clipboard.length() == 0;
    }
}
