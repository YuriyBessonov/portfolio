package app.ybessonov.calculator.number;


import java.io.Serializable;

import app.ybessonov.calculator.exception.IncompatibleTypeException;

/**
 * Абстрактный класс числа
 */
public abstract class TANumber implements Serializable {
    public static final char POINT = '.';

    //Является ли число нулем
    public abstract boolean isZero();
    //Получить копию числа
    public abstract TANumber copy();
    //Получить число, являющееся суммой текущего и аргумента
    public abstract TANumber add(TANumber other) throws IncompatibleTypeException;
    //Получить число, являющееся разностью текущего и аргумента
    public abstract TANumber sub(TANumber other) throws IncompatibleTypeException;
    //Получить число, являющееся частным текущего и аргумента
    public abstract TANumber div(TANumber other) throws IncompatibleTypeException;
    //Получить число, являющееся произведением текущего и аргумента
    public abstract TANumber mult(TANumber other) throws IncompatibleTypeException;
    //Получить число, полученное делением единицы на текущее
    public abstract TANumber reverse();
    //Получить число, являющееся квадратом текущего
    public abstract TANumber square();
    //Получить число со значением нуля
    public abstract TANumber zeroInstance();
    //Формат строкового представления (полный или укороченный)
    public enum ViewFormat {FULL, SHORT}
}
