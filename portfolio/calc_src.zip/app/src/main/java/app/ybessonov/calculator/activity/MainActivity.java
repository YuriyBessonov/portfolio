package app.ybessonov.calculator.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayout;
import android.text.method.ScrollingMovementMethod;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import app.ybessonov.calculator.R;
import app.ybessonov.calculator.control.TCtrl;
import app.ybessonov.calculator.fragment.ComplFuncDialogFragment;
import app.ybessonov.calculator.memory.TMemory;
import app.ybessonov.calculator.model.TClipBoard;
import app.ybessonov.calculator.number.TANumber;
import app.ybessonov.calculator.number.TComplex;
import app.ybessonov.calculator.number.TFrac;
import app.ybessonov.calculator.number.TPNumber;
import butterknife.BindView;
import butterknife.ButterKnife;
import eltos.simpledialogfragment.SimpleDialog;
import eltos.simpledialogfragment.list.CustomListDialog;
import eltos.simpledialogfragment.list.SimpleListDialog;


public class MainActivity extends AppCompatActivity implements SimpleDialog.OnDialogResultListener {
    public static final String ARG_HISTENT = "HISTENT";
    public static final String ARG_HISTORY = "HISTORY";
    public static final String TAG_POW_DIALOG = "POW";
    public static final String TAG_ROOT_DIALOG = "ROOT";
    public static final int REQ_HISTENT_CODE = 43;
    private static final String TAG_MODE = "MODE";
    private static final String TAG_EDIT = "EDIT";
    private static final String TAG_SETTINGS = "SETTINGS";
    private static final String KEY_RESULT = "RESULT";
    private static final String TAG_FUNC_DIALOG = "FUNC_DIALOG";
    private static final String APP_PREFERENCES = "APP_PREF";
    private static final String APP_PREFERENCES_FRAC = "APP_PREF_FRAC";
    private static final String APP_PREFERENCES_COMPL = "APP_PREF_COMPL";

    @BindView(R.id.lay_controls)
    GridLayout layoutControls;
    @BindView(R.id.layout_extra_func)
    LinearLayout layoutExtraFunc;
    @BindView(R.id.tv_base)
    TextView textBase;
    @BindView(R.id.sb_base)
    SeekBar seekBase;
    @BindView(R.id.btn_base_dec)
    Button baseDec;
    @BindView(R.id.btn_base_inc)
    Button baseInc;
    @BindView(R.id.btn_bs)
    Button btnBackspace;
    @BindView(R.id.btn_ce)
    Button btnCE;
    @BindView(R.id.btn_clr)
    Button btnCLR;
    @BindView(R.id.tv_value)
    TextView value;
    @BindView(R.id.btn_exec)
    Button btnExec;
    @BindView(R.id.tv_mode)
    TextView textMode;
    @BindView(R.id.btn_mc)
    Button btnMC;
    @BindView(R.id.btn_mr)
    Button btnMR;
    @BindView(R.id.tv_memstate)
    TextView tvMemState;

    //Форматы отображения простых дробей и комплексных чисел
    private TANumber.ViewFormat fracViewFormat;
    private TANumber.ViewFormat complexViewFormat;
    //Объект класса Управление
    private TCtrl control;
    //Текущий режим калькулятора
    private Mode mode;
    //Готовность компонентов
    private boolean ready = false;

    //Обработчик изменения ползунков
    private SeekBar.OnSeekBarChangeListener onSbChanged = new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            if (fromUser) {
                int newVal = progress + 2;
                updateBase(newVal);
            }
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
        }
    };
    //Обработчик нажатия кнопок, изменяющих систему счисления
    private View.OnClickListener onIncDecBtnClicked = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            int id = v.getId();
            int val = Integer.parseInt(textBase.getText().toString());

            if (id == R.id.btn_base_dec) {
                val--;
            } else {
                val++;
            }
            updateBase(val);
        }
    };
    //Обработчик долгого нажатия на число
    private View.OnLongClickListener onValueLongClick = new View.OnLongClickListener() {
        @Override
        public boolean onLongClick(View v) {
            int[] options = new int[]{R.string.copy, R.string.paste};

            SimpleListDialog.build()
                    .choiceMode(SimpleListDialog.SINGLE_CHOICE_DIRECT)
                    .items(getBaseContext(), options)
                    .show(MainActivity.this, TAG_EDIT);
            return true;
        }
    };
    //Обработчик клика на название режима
    private View.OnClickListener onModeTextClicked = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            int[] modes = new int[]{R.string.mode_pnum, R.string.mode_frac, R.string.mode_complex};

            SimpleListDialog.build()
                    .title(R.string.dialog_mode)
                    .choiceMode(SimpleListDialog.SINGLE_CHOICE_DIRECT)
                    .items(getBaseContext(), modes)
                    .show(MainActivity.this, TAG_MODE);
        }
    };
    //Обработчик нажатия кнопки команды
    private View.OnClickListener onCmdBtnClicked = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            int cmdN = (int) v.getTag();
            String str = control.performCalcOp(cmdN);
            value.setText(str);
            if (control.getCmdType(cmdN) == TCtrl.CmdType.MEMORY) {
                updateMemState();
            }
        }
    };
    //Обработчик клика на кнопку выполнения функции над комплексным числом
    private View.OnClickListener onComplFuncBtnClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.btn_abs:
                    showSimpleFuncDialog(R.string.absolute, TCtrl.COMPL_ABS);
                    break;
                case R.id.btn_adeg:
                    showSimpleFuncDialog(R.string.angle_deg, TCtrl.COMPL_ADEG);
                    break;
                case R.id.btn_arad:
                    showSimpleFuncDialog(R.string.angle_rad, TCtrl.COMPL_ARAD);
                    break;
                case R.id.btn_pwr:
                    showComplFuncDialog(ComplFuncDialogFragment.Func.POW);
                    break;
                case R.id.btn_root:
                    showComplFuncDialog(ComplFuncDialogFragment.Func.ROOT);
                    break;
            }
        }
    };

    //Обработка результатов диалогов
    @Override
    public boolean onResult(@NonNull String dialogTag, int which, @NonNull Bundle extras) {
        Object selectedId = extras.get(CustomListDialog.SELECTED_SINGLE_ID);
        long id;
        if (selectedId == null && (dialogTag.equals(TAG_MODE) || dialogTag.equals(TAG_EDIT))) {
            return false;
        }
        switch (dialogTag) {
            case TAG_MODE:
                id = (long) selectedId;
                Mode newMode;
                if (id == R.string.mode_pnum) {
                    newMode = Mode.PNUM;
                } else if (id == R.string.mode_frac) {
                    newMode = Mode.FRAC;
                } else {
                    newMode = Mode.COMPLEX;
                }
                if (newMode != mode) {
                    initMode(newMode);
                    return true;
                }
                break;
            case TAG_EDIT:
                id = (long) selectedId;
                if (id == R.string.copy) {
                    control.performCalcOp(TCtrl.CMD_COPY);
                } else {
                    value.setText(control.performCalcOp(TCtrl.CMD_PASTE));
                }
                break;
            case TAG_SETTINGS:
                int selectedPos = (int) extras.get(CustomListDialog.SELECTED_SINGLE_POSITION);
                if (mode == Mode.FRAC) {
                    fracViewFormat = TANumber.ViewFormat.values()[selectedPos];
                } else {
                    complexViewFormat = TANumber.ViewFormat.values()[selectedPos];
                }
                updateViewFormat();
                break;
            default:
                if (which == BUTTON_NEUTRAL) {
                    TClipBoard.set(extras.getString(KEY_RESULT, "0"));
                    Toast.makeText(this, getString(R.string.copied) + extras.getString(KEY_RESULT), Toast.LENGTH_SHORT).show();
                }
                break;
        }
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        initMode(Mode.PNUM);
        initControls();
        initListeners();
        loadPreferences();
        updateViewFormat();
        ready = true;
    }

    //Инициализировать режим работы калькулятора
    private void initMode(Mode mode) {
        this.mode = mode;
        int[] extDigits = {R.id.dig10, R.id.dig11, R.id.dig12, R.id.dig13, R.id.dig14, R.id.dig15};
        switch (mode) {
            case PNUM:
                control = new TCtrl(new TPNumber(0, 10), this);
                textMode.setText(R.string.mode_pnum);
                findViewById(R.id.btn_compl_sep).setVisibility(View.INVISIBLE);
                ((Button) findViewById(R.id.btn_sep)).setText(R.string.point);
                findViewById(R.id.btn_compl_sep).setVisibility(View.INVISIBLE);
                for (int extDigit : extDigits) {
                    findViewById(extDigit).setVisibility(View.VISIBLE);
                }
                findViewById(R.id.layout_base).setVisibility(View.VISIBLE);
                findViewById(R.id.layout_extra_func).setVisibility(View.GONE);
                break;
            case FRAC:
                control = new TCtrl(new TFrac(), this);
                textMode.setText(R.string.mode_frac);
                findViewById(R.id.btn_compl_sep).setVisibility(View.INVISIBLE);
                ((Button) findViewById(R.id.btn_sep)).setText(R.string.label_frac_sep);
                for (int extDigit : extDigits) {
                    findViewById(extDigit).setVisibility(View.INVISIBLE);
                }
                findViewById(R.id.layout_base).setVisibility(View.INVISIBLE);
                findViewById(R.id.layout_extra_func).setVisibility(View.GONE);
                break;
            case COMPLEX:
                control = new TCtrl(new TComplex(), this);
                textMode.setText(R.string.mode_complex);
                findViewById(R.id.btn_compl_sep).setVisibility(View.VISIBLE);
                ((Button) findViewById(R.id.btn_sep)).setText(R.string.point);
                for (int extDigit : extDigits) {
                    findViewById(extDigit).setVisibility(View.INVISIBLE);
                }
                findViewById(R.id.layout_base).setVisibility(View.INVISIBLE);
                findViewById(R.id.layout_extra_func).setVisibility(View.VISIBLE);
                break;
        }
        if (ready) {
            updateBase(control.getBase());
        }
        TClipBoard.clear();
        value.setText(control.doEditorCmd(TCtrl.CMD_CLR));
        updateMemState();
    }

    //Обновить состояние памяти
    private void updateMemState() {
        if (control.getMem().getState() == TMemory.State.OFF) {
            btnMC.setEnabled(false);
            btnMR.setEnabled(false);
            tvMemState.setText(R.string.mem_off);
        } else {
            btnMC.setEnabled(true);
            btnMR.setEnabled(true);
            tvMemState.setText(control.getMem().getNumberStr());
        }
    }

    //Задание начальной конфигурации визуальных элементов
    private void initControls() {
        int btnBgColPr = ContextCompat.getColor(this, R.color.colorPrimary);
        int btnBgColAcc = ContextCompat.getColor(this, R.color.colorAccent);
        for (int i = 0; i < layoutControls.getChildCount(); i++) {
            Button btn = (Button) layoutControls.getChildAt(i);
            int val;
            int btnId = btn.getId();
            if (btnId == R.id.btn_madd || btnId == R.id.btn_mc || btnId == R.id.btn_ms || btnId == R.id.btn_mr ||
                    btnId == R.id.btn_add || btnId == R.id.btn_sub || btnId == R.id.btn_mul || btnId == R.id.btn_div) {
                btn.getBackground().setColorFilter(btnBgColPr, PorterDuff.Mode.MULTIPLY);
            }
            try {
                val = Integer.valueOf(btn.getText().toString());
                btn.setTag(val);
                btn.setText(String.valueOf(Character.forDigit(val, 16)));
            } catch (NumberFormatException e) {
            }
        }

        int[][] tagsMap = {{R.id.btn_mc, TCtrl.MEM_CLR}, {R.id.btn_mr, TCtrl.MEM_READ}, {R.id.btn_ms, TCtrl.MEM_STORE}, {R.id.btn_madd, TCtrl.MEM_ADD},
                {R.id.btn_add, TCtrl.OP_ADD}, {R.id.btn_sub, TCtrl.OP_SUB}, {R.id.btn_mul, TCtrl.OP_MUL}, {R.id.btn_div, TCtrl.OP_DIV},
                {R.id.btn_sqr, TCtrl.FN_SQR}, {R.id.btn_rev, TCtrl.FN_INV}, {R.id.btn_exec, TCtrl.CMD_EXEC}, {R.id.btn_sep, TCtrl.CMD_DELIM},
                {R.id.btn_sign, TCtrl.CMD_SIGN}, {R.id.btn_compl_sep, TCtrl.CMD_IM_DELIM}, {R.id.btn_compl_sep, TCtrl.CMD_IM_DELIM}
        };
        for (int i = 0; i < tagsMap.length; i++) {
            findViewById(tagsMap[i][0]).setTag(tagsMap[i][1]);
        }

        btnBackspace.setTag(TCtrl.CMD_BS);
        btnCE.setTag(TCtrl.CMD_CE);
        btnCLR.setTag(TCtrl.CMD_CLR);
        value.setText(control.getNum().toString());
        textBase.setText(String.valueOf(control.getBase()));
        limitDigits(control.getBase());
        value.setMovementMethod(new ScrollingMovementMethod());

        baseDec.getBackground().setColorFilter(btnBgColPr, PorterDuff.Mode.MULTIPLY);
        baseInc.getBackground().setColorFilter(btnBgColPr, PorterDuff.Mode.MULTIPLY);

        btnExec.getBackground().setColorFilter(btnBgColAcc, PorterDuff.Mode.MULTIPLY);
        btnCE.getBackground().setColorFilter(btnBgColAcc, PorterDuff.Mode.MULTIPLY);
        btnBackspace.getBackground().setColorFilter(btnBgColAcc, PorterDuff.Mode.MULTIPLY);
        btnCLR.getBackground().setColorFilter(btnBgColAcc, PorterDuff.Mode.MULTIPLY);
    }

    //Назначение обработчиков
    private void initListeners() {
        seekBase.setOnSeekBarChangeListener(onSbChanged);
        baseInc.setOnClickListener(onIncDecBtnClicked);
        baseDec.setOnClickListener(onIncDecBtnClicked);
        for (int i = 0; i < layoutControls.getChildCount(); i++) {
            Button btn = (Button) layoutControls.getChildAt(i);
            btn.setOnClickListener(onCmdBtnClicked);
        }
        for (int i = 0; i < layoutExtraFunc.getChildCount(); i++) {
            Button btn = (Button) layoutExtraFunc.getChildAt(i);
            btn.setOnClickListener(onComplFuncBtnClick);
        }
        btnBackspace.setOnClickListener(onCmdBtnClicked);
        btnCE.setOnClickListener(onCmdBtnClicked);
        btnCLR.setOnClickListener(onCmdBtnClicked);
        textMode.setOnClickListener(onModeTextClicked);
        value.setOnLongClickListener(onValueLongClick);
    }

    //Обновить основание системы счисления
    private void updateBase(int newBase) {
        if (newBase >= 2 && newBase <= 16) {
            seekBase.setProgress(newBase - 2);
            textBase.setText(String.valueOf(newBase));
            limitDigits(newBase);
            value.setText(control.setBase(newBase));
            updateMemState();
        }
    }

    //Сделать неактивными неиспользуемые цифры
    private void limitDigits(int n) {
        for (int i = 0; i < layoutControls.getChildCount(); i++) {
            View v = layoutControls.getChildAt(i);
            int tag = (int) v.getTag();
            if (tag < n) {
                v.setEnabled(true);
            } else if (tag < 16) {
                v.setEnabled(false);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.act_history:
                showHistory();
                return true;
            case R.id.act_about:
                showAbout();
                return true;
            case R.id.act_settings:
                showSettings();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //Отобразить историю
    private void showHistory() {
        Intent intent = new Intent(this, HistoryActivity.class);
        intent.putExtra(ARG_HISTORY, control.getHist());
        startActivityForResult(intent, REQ_HISTENT_CODE);
    }

    //Отобразить справку
    private void showAbout() {
        Intent intent = new Intent(this, AboutActivity.class);
        startActivity(intent);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (data == null) {
            return;
        }
        int entIndex = data.getIntExtra(ARG_HISTENT, -1);
        if (entIndex >= 0) {
            String res = control.getHist().get(entIndex).getResult();
            TClipBoard.set(res);
            Toast.makeText(this, getString(R.string.copied) + res, Toast.LENGTH_LONG).show();
        }
    }

    //Показать диалог простой комплексной функции
    void showSimpleFuncDialog(int titleResId, int funcNo) {
        String res = control.doComplFunc(funcNo, 0, 0);
        if (res.equals(getString(R.string.error))) {
            return;
        }
        Bundle rBundle = new Bundle();
        rBundle.putString(KEY_RESULT, res);
        SimpleDialog.build()
                .title(titleResId)
                .pos(R.string.okay)
                .neut(R.string.copy)
                .msg(res).extra(rBundle)
                .show(this, TAG_FUNC_DIALOG);
    }

    //Показать диалог корня или возведения в степень комплексного числа
    private void showComplFuncDialog(ComplFuncDialogFragment.Func func) {
        String tag;
        if (func == ComplFuncDialogFragment.Func.POW) {
            tag = TAG_POW_DIALOG;
        } else {
            tag = TAG_ROOT_DIALOG;
        }

        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        Fragment prev = getSupportFragmentManager().findFragmentByTag(tag);
        if (prev != null) {
            ft.remove(prev);
        }
        ft.addToBackStack(null);

        DialogFragment newFragment = ComplFuncDialogFragment.newInstance(func, control.getEdit().toString());
        newFragment.show(ft, tag);
    }

    //Показать диалог настроек
    private void showSettings() {
        int[] options;
        int defaultInd;
        if (mode == Mode.COMPLEX) {
            options = new int[]{R.string.format_complex, R.string.format_real};
            defaultInd = complexViewFormat.ordinal();
        } else if (mode == Mode.FRAC) {
            options = new int[]{R.string.format_frac, R.string.format_num};
            defaultInd = fracViewFormat.ordinal();
        } else {
            Toast.makeText(this, R.string.no_settings, Toast.LENGTH_SHORT).show();
            return;
        }

        SimpleListDialog.build()
                .choiceMode(SimpleListDialog.SINGLE_CHOICE)
                .items(getBaseContext(), options)
                .title(R.string.title_format)
                .pos(R.string.okay)
                .choicePreset(defaultInd)
                .show(this, TAG_SETTINGS);
    }

    //Загрузка настроек приложения
    private void loadPreferences() {
        SharedPreferences mSettings = getSharedPreferences(APP_PREFERENCES, Context.MODE_PRIVATE);

        if (mSettings.contains(APP_PREFERENCES_COMPL)) {
            complexViewFormat = TANumber.ViewFormat.valueOf(mSettings.getString(APP_PREFERENCES_COMPL, ""));
        } else {
            SharedPreferences.Editor editor = mSettings.edit();
            editor.putString(APP_PREFERENCES_COMPL, TANumber.ViewFormat.SHORT.toString());
            editor.apply();
        }

        if (mSettings.contains(APP_PREFERENCES_FRAC)) {
            fracViewFormat = TANumber.ViewFormat.valueOf(mSettings.getString(APP_PREFERENCES_FRAC, ""));
        } else {
            SharedPreferences.Editor editor = mSettings.edit();
            editor.putString(APP_PREFERENCES_FRAC, TANumber.ViewFormat.SHORT.toString());
            editor.apply();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        savePreferences();
    }

    //Сохранение настроек приложения
    private void savePreferences() {
        SharedPreferences mSettings = getSharedPreferences(APP_PREFERENCES, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = mSettings.edit();
        editor.putString(APP_PREFERENCES_COMPL, complexViewFormat.toString());
        editor.putString(APP_PREFERENCES_FRAC, fracViewFormat.toString());
        editor.apply();
    }

    //применение настройки вида отображения чисел
    private void updateViewFormat() {
        TComplex.setViewFormat(complexViewFormat);
        TFrac.setViewFormat(fracViewFormat);
        value.setText(control.getEdit().toString());
    }

    //Режим калькулятора
    private enum Mode {
        PNUM, FRAC, COMPLEX
    }
}
