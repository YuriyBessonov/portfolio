package app.ybessonov.calculator.number;

import app.ybessonov.calculator.exception.IncompatibleTypeException;

/**
 * Класс АДТ "P-ичное число", представленное с заданной точностью в указанной системе счисления
 */
public class TPNumber extends TANumber implements Comparable<TPNumber> {
    //строковые константы ошибок
    private static final String WRONG_NUMBER_ERR = "Недопустимое значение числа ";
    private static final String WRONG_BASE_ERR = "Недопустимое значение основания системы счисления ";
    private static final String WRONG_PRECISION_ERR = "Недопустимое значение точности ";
    private static final String INCOMPATIBLE_ERR = "Основания чисел несовместимы  ";
    private static final String DIVISION_BY_ZERO_ERR = "Делитель равен 0, деление невозможно";
    private static final int DEFAULT_PRECISION = 0;
    private static final int MAX_PRECISION = 16;
    //значение числа
    private double number;
    //основание
    private int base;
    //точность
    private int precision;

    public TPNumber(double number, int base, int precision) {
        this.number = number;
        setBase(base);
        setPrecision(precision);
    }

    public TPNumber(double number, int base) {
        this.number = number;
        setBase(base);
        setPrecision(10);
        precision = estimatedPrecision(toString());
    }

    public TPNumber(String numberStr, String baseStr, String precisionStr) {
        setBaseStr(baseStr);
        setPrecisionStr(precisionStr);
        this.number = strToDec(numberStr, base);
    }

    public TPNumber(String numberStr, int base) {
        setBase(base);
        this.number = strToDec(numberStr, base);
        precision = estimatedPrecision(numberStr);
    }

    public TPNumber() {
        this.number = 0;
        setBase(10);
        setPrecision(0);
    }

    //Получить точность числа
    public static int estimatedPrecision(String pNum) {
        int cnt = 0;
        int i;
        for (i = pNum.length() - 1; i >= 0 && pNum.charAt(i) == '0'; i--) ;
        boolean hasPoint = false;
        for (; i >= 0; i--, cnt++) {
            if (pNum.charAt(i) == POINT) {
                hasPoint = true;
                break;
            }
        }
        if (hasPoint) {
            return cnt;
        } else {
            return 0;
        }
    }

    @Override
    public boolean isZero() {
        return number == 0;
    }

    @Override
    public TPNumber copy() {
        return new TPNumber(number, base, precision);
    }

    @Override
    public TPNumber add(TANumber otherNum) throws IncompatibleTypeException, IllegalArgumentException {
        if (!(otherNum instanceof TPNumber)) {
            throw new IncompatibleTypeException();
        }
        TPNumber other = (TPNumber) otherNum;
        if (this.base != other.base) {
            throw new IllegalArgumentException(INCOMPATIBLE_ERR);
        }

        int prec = Math.max(getActualPrecision(), other.getActualPrecision());
        TPNumber res = new TPNumber(this.number + other.number, base, prec);
        res.setPrecision(res.getActualPrecision());
        return res;
    }

    @Override
    public TPNumber mult(TANumber otherNum) {
        if (!(otherNum instanceof TPNumber)) {
            throw new IncompatibleTypeException();
        }
        TPNumber other = (TPNumber) otherNum;
        if (this.base != other.base) {
            throw new IllegalArgumentException(INCOMPATIBLE_ERR);
        }

        int prec = getActualPrecision() + other.getActualPrecision();
        TPNumber res = new TPNumber(this.number * other.number, base, prec);
        res.setPrecision(res.getActualPrecision());
        return res;
    }

    @Override
    public TPNumber sub(TANumber otherNum) {
        if (!(otherNum instanceof TPNumber)) {
            throw new IncompatibleTypeException();
        }
        TPNumber other = (TPNumber) otherNum;
        if (this.base != other.base) {
            throw new IllegalArgumentException(INCOMPATIBLE_ERR);
        }

        int prec = Math.max(getActualPrecision(), other.getActualPrecision());
        TPNumber res = new TPNumber(this.number - other.number, base, prec);
        res.setPrecision(res.getActualPrecision());
        return res;
    }

    @Override
    public TPNumber div(TANumber otherNum) {
        if (!(otherNum instanceof TPNumber)) {
            throw new IncompatibleTypeException();
        }
        TPNumber other = (TPNumber) otherNum;
        if (this.base != other.base) {
            throw new IllegalArgumentException(INCOMPATIBLE_ERR);
        }
        if (other.number == 0.0) {
            throw new IllegalArgumentException(DIVISION_BY_ZERO_ERR);
        }
        TPNumber res = new TPNumber(this.number / other.number, base, MAX_PRECISION);
        res.setPrecision(res.getActualPrecision());
        return res;
    }

    @Override
    public TPNumber reverse() {
        if (number == 0.0) {
            throw new IllegalArgumentException(DIVISION_BY_ZERO_ERR);
        }
        TPNumber res = new TPNumber(1.0 / number, base, MAX_PRECISION);
        res.setPrecision(res.getActualPrecision());
        return res;
    }

    @Override
    public TPNumber square() {
        int prec = getActualPrecision() * 2;
        TPNumber res = new TPNumber(number * number, base, prec);
        res.setPrecision(res.getActualPrecision());
        return res;
    }

    @Override
    public TANumber zeroInstance() {
        return new TPNumber(0, 10, 0);
    }

    public double getNumber() {
        return number;
    }

    @Override
    public String toString() {
        StringBuilder fracPart = new StringBuilder("");
        double t = Math.abs(number);
        t = t % 1;
        int i;
        for (i = 0; i < precision; i++) {
            if (t == 0.0) {
                break;
            }
            t *= base;
            int digit = (int) t;
            t -= digit;
            fracPart.append(Character.forDigit(digit, base));
        }
        for (; i < precision; i++) {
            fracPart.append('0');
        }
        if (t != 0.0) {
            t *= base;
            int digit = (int) t;
            if (digit >= base / 2) {
                boolean left = true;
                for (int j = fracPart.length() - 1; j >= 0; j--) {
                    int d = Character.digit(fracPart.charAt(j), base);
                    d++;
                    if (d < base) {
                        left = false;
                        fracPart.setCharAt(j, Character.forDigit(d, base));
                        break;
                    } else {
                        fracPart.setCharAt(j, '0');
                    }
                }
                if (left) {
                    number += Math.signum(number);
                }
            }
        }
        String intPart = Long.toString((long) number, base);
        if (((long) number) == 0 && number < 0) {
            intPart = "-" + intPart;
        }
        return (precision > 0) ? intPart + "." + fracPart : intPart;
    }

    //Получить текущее число, к которому применен унарный минус
    public TPNumber minus() {
        return new TPNumber(-number, base, precision);
    }

    public int getBase() {
        return base;
    }

    public void setBase(int base) {
        if (base < 2 || base > 16) {
            throw new IllegalArgumentException(WRONG_BASE_ERR + String.valueOf(base));
        }
        this.base = base;
        setPrecision(Math.max(precision, MAX_PRECISION));
        setPrecision(estimatedPrecision(toString()));
    }

    public String getBaseStr() {
        return String.valueOf(base);
    }

    public void setBaseStr(String baseStr) {
        int base = Integer.parseInt(baseStr);
        setBase(base);
    }

    //Получить квадратный корень текущего числа
    public TPNumber sqrt() {
        return new TPNumber(Math.sqrt(number), base, precision);
    }

    public int getPrecision() {
        return precision;
    }

    public void setPrecision(int precision) {
        if (precision < 0) {
            throw new IllegalArgumentException(WRONG_PRECISION_ERR + String.valueOf(precision));
        }
        this.precision = precision;
    }

    public String getPrecisionStr() {
        return String.valueOf(precision);
    }

    public void setPrecisionStr(String precisionStr) {
        int precision = Integer.parseInt(precisionStr);
        setPrecision(precision);
    }

    //Преобразовать строку в double
    private double strToDec(String number, int base) {
        int pt = number.indexOf('.');

        double value = 0.0;
        if (pt > 0) {
            int ex = pt - number.length() + 1;
            for (int i = number.length() - 1; i > pt; i--, ex++) {
                char digit = number.charAt(i);
                int digitDec;
                digitDec = Character.digit(digit, base);
                if (digitDec < 0) {
                    throw new IllegalArgumentException(WRONG_NUMBER_ERR + number);
                }
                value += digitDec * Math.pow(base, ex);
            }
        } else pt = number.length();
        long intPart = Long.parseLong(number.substring(0, pt), base);
        if (number.charAt(0) == '-') {
            value = -value;
        }
        value += (double) intPart;
        return value;
    }

    @Override
    public int compareTo(TPNumber tp) {
        if (number == tp.number) {
            return 0;
        } else if (number > tp.number) {
            return 1;
        } else {
            return -1;
        }
    }

    //Уменьшить точность, если возможно
    private int getActualPrecision() {
        String str = toString();
        return Math.min(precision, estimatedPrecision(str));
    }
}
