package app.ybessonov.calculator.editor;

import app.ybessonov.calculator.control.TCtrl;
import app.ybessonov.calculator.number.TComplex;

/**
 * Класс редкатора комплексных чисел
 */
public class TCEdit extends TAEdit {
    //Мнимая часть не равна 0
    private boolean hasIm = false;
    //Редактор действительной части
    private TREdit reEdit;
    //Редактор мнимой части
    private TREdit imEdit;
    //Текущий редактор
    private TREdit currEdit;

    public TCEdit(String number) {
        super(number);
        setNumber(number);
    }

    public TCEdit() {
        super();
        reEdit = new TREdit(10);
        imEdit = new TREdit(10);
        currEdit = reEdit;
    }

    //Добавить разделитель действительной и мнимой части
    public String addReImDelim() {
        if (!hasIm) {
            hasIm = true;
            currEdit.simplify();
            currEdit = imEdit;
        }
        return toString();
    }

    @Override
    public void setNumber(String number) {
        TComplex complex = new TComplex(number, 10);
        reEdit = new TREdit(complex.getReStr(), 10);
        imEdit = new TREdit(complex.getImStr(), 10);
        if (imEdit.isZero()) {
            currEdit = reEdit;
        } else {
            currEdit = imEdit;
            hasIm = true;
        }
    }

    @Override
    public String clear() {
        reEdit.clear();
        imEdit.clear();
        hasIm = false;
        currEdit = reEdit;
        return toString();
    }

    @Override
    public String addDelim() {
        currEdit.addDelim();
        return toString();
    }

    @Override
    public String addDigit(int digit) {
        currEdit.addDigit(digit);
        return toString();
    }

    @Override
    public boolean hasDelim() {
        return hasIm;
    }


    @Override
    public String addZero() {
        currEdit.addZero();
        return toString();
    }

    @Override
    public String sign() {
        currEdit.sign();
        return toString();
    }

    @Override
    public String backspace() {
        if (hasIm) {
            if (imEdit.number.length() <= 1) {
                hasIm = false;
                currEdit = reEdit;
            }
            imEdit.backspace();
        } else {
            reEdit.backspace();
        }
        return toString();
    }

    @Override
    public String edit(int n) {
        switch (n) {
            case TCtrl.CMD_BS:
                return backspace();
            case TCtrl.CMD_CLR:
                return clear();
            case TCtrl.CMD_DELIM:
                return addDelim();
            case TCtrl.CMD_IM_DELIM:
                return addReImDelim();
            case TCtrl.CMD_SIGN:
                return sign();
            default:
                return addDigit(n);
        }
    }

    @Override
    public boolean isZero() {
        return reEdit.isZero() && imEdit.isZero();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(reEdit.toString());
        if (hasIm) {
            sb.append(COMPL_DELIM);
            sb.append(imEdit.toString());
        }
        return sb.toString();
    }

    @Override
    protected boolean isVeryLong() {
        return reEdit.isVeryLong() || imEdit.isVeryLong();
    }
}
