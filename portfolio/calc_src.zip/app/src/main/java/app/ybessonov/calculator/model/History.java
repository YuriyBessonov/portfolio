package app.ybessonov.calculator.model;

import java.io.Serializable;
import java.util.ArrayList;

import app.ybessonov.calculator.number.TANumber;
import app.ybessonov.calculator.proc.TProc;

/**
 * История операций
 */
public class History implements Serializable {

    //контейнер операций
    private ArrayList<HistEntry> entries;

    public History() {
        entries = new ArrayList<>();
    }

    //Добавить элемент
    public void add(TANumber lOp, TANumber rOp, TANumber res, TProc.TOprtn operation) {
        entries.add(0, new HistEntry(lOp, rOp, res, operation));
    }

    public void add(TANumber lOp, TANumber res, TProc.TFunc function) {
        entries.add(0, new HistEntry(lOp, res, function));
    }

    //Получить элемент
    public HistEntry get(int ind) {
        return entries.get(ind);
    }

    //Количество элементов
    public int count() {
        return entries.size();
    }

    //Очистить историю
    public void clear() {
        entries.clear();
    }

    //Элемент  истории
    public static class HistEntry implements Serializable {
        private TANumber lOp;
        private TANumber rOp;
        private TANumber res;
        private TProc.TOprtn operation;
        private TProc.TFunc function;

        public HistEntry(TANumber lOp, TANumber rOp, TANumber res, TProc.TOprtn operation) {
            this.lOp = lOp;
            this.rOp = rOp;
            this.res = res;
            this.operation = operation;
        }

        public HistEntry(TANumber lOp, TANumber res, TProc.TFunc function) {
            this.lOp = lOp;
            this.res = res;
            this.function = function;
        }

        @Override
        public String toString() {
            StringBuilder str = new StringBuilder();
            if (function != null) {
                if (function == TProc.TFunc.SQR) {
                    str.append("SQR(");
                    str.append(lOp);
                    str.append(")");
                } else {
                    str.append("1/");
                    str.append(lOp);
                }
                str.append(" = ");
                str.append(res);
            } else {
                str.append(lOp);
                switch (operation) {
                    case ADD:
                        str.append(" + ");
                        break;
                    case SUB:
                        str.append(" - ");
                        break;
                    case MUL:
                        str.append(" * ");
                        break;
                    case DIV:
                        str.append(" / ");
                        break;
                }
                str.append(rOp);
                str.append(" = ");
                str.append(res);
            }
            return str.toString();
        }

        public String getResult() {
            return res.toString();
        }
    }
}
