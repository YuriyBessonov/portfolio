package app.ybessonov.calculator.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import app.ybessonov.calculator.R;
import app.ybessonov.calculator.model.History;
import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Класс активности истории
 */
public class HistoryActivity extends AppCompatActivity {
    @BindView(R.id.lv_history)
    ListView historyListView;

    private History history;

    //Обработчик клика на элемент списка
    private AdapterView.OnItemClickListener onHistEntryClick = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            Intent intent = new Intent();
            intent.putExtra(MainActivity.ARG_HISTENT, position);
            setResult(RESULT_OK, intent);
            finish();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        history = (History) getIntent().getSerializableExtra(MainActivity.ARG_HISTORY);
        if (history.count() > 0) {
            setContentView(R.layout.activity_history);
            ButterKnife.bind(this);
            historyListView.setOnItemClickListener(onHistEntryClick);
            fillList();
        } else {
            setContentView(R.layout.activity_history_empty);
        }
    }

    //Заполнить ListView записями из истории
    private void fillList() {
        String[] entStrings = new String[history.count()];
        for (int i = 0; i < history.count(); i++) {
            History.HistEntry ent = history.get(i);
            entStrings[i] = ent.toString();
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, entStrings);

        historyListView.setAdapter(adapter);
    }

}
