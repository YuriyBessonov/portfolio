package app.ybessonov.calculator.editor;


import app.ybessonov.calculator.util.Util;

/**
 * Абстрактный класс редактора
 */
public abstract class TAEdit {
    public static final String ZERO_STR = "0";
    public static final char POINT = '.';
    public static final char SEPARATOR = '/';
    public static final char MINUS = '-';
    public static final String COMPL_DELIM = " + i*";
    public static final int MAX_LEN = 18;
    protected static final char ZERO = '0';
    protected boolean signed = false;
    //p-ичное число
    protected StringBuilder number;

    public TAEdit(String number) {
        setNumber(number);
    }

    public TAEdit() {
        number = new StringBuilder(ZERO_STR);
    }

    //Задать число
    public void setNumber(String number) {
        this.number = new StringBuilder(number);
        if (number.charAt(0) == MINUS) {
            signed = true;
            this.number.deleteCharAt(0);
        }
    }

    //Изменить знак числа на противоположный
    public String sign() {
        signed = !signed;
        return toString();
    }

    //Добавить разделитель
    public abstract String addDelim();

    //Проверить наличие разделителя
    public abstract boolean hasDelim();

    //Добавить цифру в системе счисления с осн. p
    public String addDigit(int digit) {
        if (!isVeryLong()) {
            char d = Util.int_to_char(digit);
            if (isZero()) {
                number.setCharAt(number.length() - 1, d);
            } else {
                if (d == ZERO) {
                    return addZero();
                }
                number.append(d);
            }
        }
        return toString();
    }

    //Добавить ноль
    public abstract String addZero();

    //Забой символа
    public abstract String backspace();

    //Сброс значения числа
    public String clear() {
        setNumber(ZERO_STR);
        signed = false;
        return toString();
    }

    //Редактирование числа
    public abstract String edit(int n);

    //Является ли число нулем
    public abstract boolean isZero();

    //Имеется ли знак у числа
    protected final boolean hasSign() {
        return signed;
    }

    @Override
    public String toString() {
        if (signed && !isZero()) {
            return String.valueOf(MINUS) + number.toString();
        }
        return number.toString();
    }

    //Имеет ли число длину большую или равную критической
    protected abstract boolean isVeryLong();

}
