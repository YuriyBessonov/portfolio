#include "mainwindow.h"
#include <QApplication>
#include "databasehelper.h"
#include <QFile>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    DataBaseHelper dbHelper;
    if (!dbHelper.openDatabase(DataBaseHelper::DEFAULT_DATABASE))
        return -1;
    MainWindow w(dbHelper);
    w.show();

    return a.exec();
}
