#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "entrydelegate.h"
#include "projectdialog.h"
#include "taskdialog.h"
#include "summarywindow.h"
#include "teamdialog.h"
#include "helpdialog.h"

#include <algorithm>

#include <KDGanttConstraintModel>
#include <KDGanttDateTimeGrid>
#include <KDGanttGraphicsView>
#include <KDGanttLegend>
#include <QAbstractItemView>
#include <QDebug>
#include <QHeaderView>
#include <QStandardItemModel>
#include <QTreeView>
#include <QCloseEvent>
#include <QPointer>
#include <QScrollBar>
#include <QListView>
#include "legend.h"
#include "standarditem.h"
#include "standardtreemodel.h"
#include "util/util.h"
#include "taskssortfilterproxymodel.h"
#include <QAbstractItemView>
#include <QDebug>
#include <QFileDialog>
#include "ganntitemdelegate.h"
#include "customdatetimegrid.h"
#include <QApplication>
#include "stylizer.h"

namespace Ui {
class Legend;
}
class MyStandardItem : public QStandardItem {
public:
  MyStandardItem( const QVariant& v ) : QStandardItem()
  {
    setData( v, Qt::DisplayRole );
  }
  MyStandardItem( const QString& v ) : QStandardItem()
  {
    setData( v, Qt::DisplayRole );
  }
};

MainWindow::MainWindow(DataBaseHelper dbHelper, QWidget *parent, Qt::WindowFlags flags) :
    QMainWindow(parent, flags),
    ui(new Ui::MainWindow), colorSettings("w_soft","taskPlanner")
{  
    ui->setupUi(this);
    this->dbHelper = &dbHelper;
    ganttTreeView = qobject_cast<QTreeView*>( ui->ganttView->leftView() );
    tasksTableView = ui->tasksTableLeft;
    proxyModel = new TasksSortFilterProxyModel(&dbHelper,this);
    proxyModel->setDynamicSortFilter(true);
    selectedProjectId = 0;

    initModel();
    initActions();
    initItemDelegate();
    initGrid();

    on_graphViewRb_toggled(true);
    ui->currentDate->setText(QDate::currentDate().toString(QString("dd.MM.yyyy, ddd")));

    ui->ganttView->graphicsView()->setReadOnly(true);
    initTreeView();
    initTableView();

    connect( ui->ganttView->leftView(), SIGNAL( customContextMenuRequested( const QPoint& ) ),
             this, SLOT( showTreeContextMenu( const QPoint& ) ) );
    connect( ui->ganttView->selectionModel(), SIGNAL( selectionChanged( const QItemSelection&, const QItemSelection& ) ),
             this, SLOT( enableActions( const QItemSelection& ) ) );

    connect( tasksTableView, SIGNAL( customContextMenuRequested( const QPoint& ) ),
             this, SLOT( showTableContextMenu( const QPoint& ) ) );
    connect( tasksTableView->selectionModel(), SIGNAL( selectionChanged( const QItemSelection&, const QItemSelection& ) ),
             this, SLOT( enableActions( const QItemSelection& ) ) );
    applyStyle(colorSettings.value("color",QVariant(0)).toInt(),false);
}

MainWindow::~MainWindow()
{
    if (color1->isChecked())
        colorSettings.setValue("color",QVariant(1));
    else if (color2->isChecked())
        colorSettings.setValue("color",QVariant(2));
    else if (color3->isChecked())
        colorSettings.setValue("color",QVariant(3));
    else if (color4->isChecked())
        colorSettings.setValue("color",QVariant(4));
    delete ui;
}

void MainWindow::on_addProjectPb_clicked()
{
    ProjectDialog* dialog = new ProjectDialog(dbHelper);
    if ( dialog->exec() == QDialog::Rejected || !dialog ) {
        delete dialog;
        return;
    }
    updateModel();
}

void MainWindow::on_addTaskPb_clicked()
{
    TaskDialog* dialog = new TaskDialog(dbHelper);
    if ( dialog->exec() == QDialog::Rejected || !dialog ) {
        delete dialog;
        return;
    }
    if (!dialog->getToNew()){
        int id = dialog->getId();
        int projectId = dbHelper->getTaskData(id,Task_ProId).toInt();
        offerAutoSchedule(projectId,Change_Added);
    }

    updateModel();
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    event->accept();
}

void MainWindow::initModel()
{
    dbHelper->initModels(this);

    treeModel =  new StandardTreeModel();
    treeModel->setColumnCount(7);
    treeModel->makeTree(dbHelper->getProjectsModel(),dbHelper->getTasksModel(),dbHelper);
    ui->ganttView->setModel( treeModel );

    tableModel = new StandardTableModel();
    tableModel->makeTableModel(dbHelper->getProjectsModel(),dbHelper->getTasksModel(),dbHelper );

    proxyModel->setSourceModel(tableModel);
    tasksTableView->setModel(proxyModel);
    ui->tasksTable->setModel(proxyModel);
}

void MainWindow::updateModel()
{
    dbHelper->selectModels();
    if (ui->graphViewRb->isChecked()){
        treeModel->clear();
        treeModel->makeTree(dbHelper->getProjectsModel(),dbHelper->getTasksModel(),dbHelper);
        initTreeView();
    }
    else {
        tableModel->makeTableModel(dbHelper->getProjectsModel(),dbHelper->getTasksModel(), dbHelper);
        initTableView();
        proxyModel->doSort();
        proxyModel->doFilter();
    }
}

void MainWindow::initActions()
{
   initSortActions();

   addProjectAction = new QAction( tr( "Добавить проект" ), this );
   addProjectAction->setShortcut( QKeySequence(tr("Ctrl+Shift+N")));
   connect( addProjectAction, SIGNAL( triggered() ), this, SLOT( on_addProjectPb_clicked() ) );

   addTaskAction = new QAction( tr( "Добавить задачу" ), this );
   addTaskAction->setShortcut(QKeySequence(tr("Ctrl+Alt+N")));
   connect( addTaskAction, SIGNAL( triggered() ), this, SLOT( on_addTaskPb_clicked() ) );

   removeAction = new QAction( tr( "Удалить" ), this );
   removeAction->setShortcut( QKeySequence::Delete );
   connect( removeAction, SIGNAL( triggered() ), this, SLOT( on_removePb_clicked() ) );

   zoomInAction = new QAction( tr( "Увеличить" ), this );
   zoomInAction->setShortcut( QKeySequence::ZoomIn );
   connect( zoomInAction, SIGNAL( triggered() ), this, SLOT( zoomIn() ) );

   zoomOutAction = new QAction( tr( "Уменьшить" ), this );
   zoomOutAction->setShortcut( QKeySequence::ZoomOut );
   connect( zoomOutAction, SIGNAL( triggered() ), this, SLOT( zoomOut() ) );

    ui->ganttView->leftView()->setContextMenuPolicy( Qt::CustomContextMenu );
    ui->ganttView->leftView()->addAction( addProjectAction );
    ui->ganttView->leftView()->addAction( addTaskAction );
    ui->ganttView->leftView()->addAction( removeAction );
    tasksTableView->setContextMenuPolicy(Qt::CustomContextMenu);
    tasksTableView->addAction( addProjectAction );
    tasksTableView->addAction( addTaskAction );
    tasksTableView->addAction( removeAction );


    QMenu* settings = menuBar()->addMenu( tr( "Настройки" ) );
    QMenu* colorScheme = settings->addMenu(tr("Цветовая схема"));
    QActionGroup*  actGrp = new QActionGroup(this);
    actGrp->setExclusive(true);

    color1 = new QAction(tr("Красно-синяя"), this);
    color1->setIcon(QIcon(":icons/res/colors1.png"));
    color1->setCheckable(true);
    actGrp->addAction(color1);
    connect( color1, SIGNAL( toggled(bool)), this, SLOT( changeStyle() ));
    connect( color1, SIGNAL( hovered()), this, SLOT( col1Hovered() ));
    colorScheme->addAction(color1);

    color2 = new QAction(tr("Сине-коричневая"), this);
    color2->setIcon(QIcon(":icons/res/colors2.png"));
    color2->setCheckable(true);
    actGrp->addAction(color2);
    connect( color2, SIGNAL( toggled(bool)), this, SLOT( changeStyle() ));
    connect( color2, SIGNAL( hovered()), this, SLOT( col2Hovered() ));
    colorScheme->addAction(color2);

    color3 = new QAction(tr("Оранжево-розовая"), this);
    color3->setIcon(QIcon(":icons/res/colors3.png"));
    color3->setCheckable(true);
    actGrp->addAction(color3);
    connect( color3, SIGNAL( toggled(bool)), this, SLOT( changeStyle() ));
    connect( color3, SIGNAL( hovered()), this, SLOT( col3Hovered() ));
    colorScheme->addAction(color3);

    color4 = new QAction(tr("Зеленая"), this);
    color4->setIcon(QIcon(":icons/res/colors4.png"));
    color4->setCheckable(true);
    connect( color4, SIGNAL( toggled(bool)), this, SLOT( changeStyle() ));
    connect( color4, SIGNAL( hovered()), this, SLOT( col4Hovered() ));
    actGrp->addAction(color4);
    colorScheme->addAction(color4);

    QMenu* zoomMenu = menuBar()->addMenu( tr( "Масштаб" ) );
    zoomMenu->addAction( zoomInAction );
    zoomMenu->addAction( zoomOutAction );

    enableActions( QItemSelection() );
}

void MainWindow::initSortActions()
{
    QMenu *pmenu = new QMenu( ui->sortByTb );
    ui->sortByTb->setMenu(pmenu);
    ui->sortByTb->setPopupMode( QToolButton::MenuButtonPopup );
    ui->sortByTb->setIcon(QIcon(":icons/res/Sort By-48.png"));
    QActionGroup*  actGrp = new QActionGroup(this);
    actGrp->setExclusive(true);

    QAction*  action = new QAction( tr( "Без сортировки" ), this );
    connect( action, SIGNAL( toggled(bool) ), this, SLOT( sortNone(bool) ));
    action->setIcon(QIcon(":icons/res/No Sorting-48.png"));
    action->setCheckable(true);
    action->setChecked(true);
    actGrp->addAction(action);
    pmenu->addAction(action);

    action = new QAction( tr( "Сортировать по прогрессу" ), this );
    connect( action, SIGNAL( toggled(bool) ), this, SLOT( sortProgress(bool) ));
    action->setIcon(QIcon(":icons/res/Progress-48.png"));
    action->setCheckable(true);
    actGrp->addAction(action);
    pmenu->addAction(action);

    action = new QAction( tr( "Сортировать по приоритету" ), this );
    connect( action, SIGNAL( toggled(bool) ), this, SLOT( sortPrio(bool) ));
    action->setIcon(QIcon(":icons/res/Priority-48.png"));
    action->setCheckable(true);
    actGrp->addAction(action);
    pmenu->addAction(action);

    action = new QAction( tr( "Сортировать по времени начала" ), this );
    connect( action, SIGNAL( toggled(bool) ), this, SLOT( sortBegin(bool) ));
    action->setIcon(QIcon(":icons/res/Time Begin-48.png"));
    action->setCheckable(true);
    actGrp->addAction(action);
    pmenu->addAction(action);

    action = new QAction( tr( "Сортировать по времени завершения" ), this );
    connect( action, SIGNAL( toggled(bool) ), this, SLOT( sortEnd(bool) ));
    action->setIcon(QIcon(":icons/res/Time End-48.png"));
    action->setCheckable(true);
    actGrp->addAction(action);
    pmenu->addAction(action);

    pmenu = new QMenu( ui->sortType );
    ui->sortType->setMenu(pmenu);
    ui->sortType->setPopupMode( QToolButton::MenuButtonPopup );
    ui->sortType->setIcon(QIcon(":icons/res/Sorting-48.png"));
    actGrp = new QActionGroup(this);
    actGrp->setExclusive(true);

    action = new QAction( tr( "По возрастанию" ), this );
    connect( action, SIGNAL( toggled(bool) ), this, SLOT( sortAsc(bool) ));
    action->setIcon(QIcon(":icons/res/Ascending Sorting-48.png"));
    action->setCheckable(true);
    action->setChecked(true);
    actGrp->addAction(action);
    pmenu->addAction(action);

    action = new QAction( tr( "По убыванию" ), this );
    connect( action, SIGNAL( toggled(bool) ), this, SLOT( sortDesc(bool) ));
    action->setIcon(QIcon(":icons/res/Descending Sorting-48.png"));
    action->setCheckable(true);
    actGrp->addAction(action);
    pmenu->addAction(action);


    pmenu = new QMenu( ui->filterByTb);
    ui->filterByTb->setMenu(pmenu);
    ui->filterByTb->setPopupMode( QToolButton::MenuButtonPopup );
    ui->filterByTb->setIcon(QIcon(":icons/res/Filled Filter-48.png"));

    action = new QAction( tr( "Показать/скрыть все" ), this );
    connect( action, SIGNAL( triggered(bool) ), this, SLOT( filterAll(bool) ));
    action->setCheckable(false);
    pmenu->addAction(action);

    filterComplAction = new QAction( tr( "Завершенные" ), this );
    connect( filterComplAction, SIGNAL( toggled(bool) ), this, SLOT( filterCompl(bool) ));
    filterComplAction->setCheckable(true);
    filterComplAction->setChecked(true);
    filterComplAction->setIcon(QIcon(":icons/res/status_done.png"));
    pmenu->addAction(filterComplAction);

    filterActualAction = new QAction( tr( "Следующие графику" ), this );
    connect( filterActualAction, SIGNAL( toggled(bool) ), this, SLOT( filterActual(bool) ));
    filterActualAction->setCheckable(true);
    filterActualAction->setChecked(true);
    filterActualAction->setIcon(QIcon(":icons/res/status_actual.png"));
    pmenu->addAction(filterActualAction);

    filterLateAction = new QAction( tr( "Отстающие от графика" ), this );
    connect( filterLateAction, SIGNAL( toggled(bool) ), this, SLOT( filterLate(bool) ));
    filterLateAction->setCheckable(true);
    filterLateAction->setChecked(true);
    filterLateAction->setIcon(QIcon(":icons/res/status_late.png"));
    pmenu->addAction(filterLateAction);

    filterPlannedAction = new QAction( tr( "Запланированные" ), this );
    connect( filterPlannedAction, SIGNAL( toggled(bool) ), this, SLOT( filterPlanned(bool) ));
    filterPlannedAction->setCheckable(true);
    filterPlannedAction->setChecked(true);
    filterPlannedAction->setIcon(QIcon(":icons/res/status_planned.png"));
    pmenu->addAction(filterPlannedAction);

    QAction* helpAction = ui->menuBar->addAction(tr("Справка"));
    connect( helpAction, SIGNAL( triggered(bool) ), this, SLOT( showHelp()));

    connect( ui->action_file_create, SIGNAL( triggered(bool) ), this, SLOT( create()));
    connect( ui->action_file_open, SIGNAL( triggered(bool) ), this, SLOT( open()));
    connect( ui->action_file_save, SIGNAL( triggered(bool) ), this, SLOT( save()));
}

void MainWindow::initItemDelegate()
{
    EntryDelegate* treeDelegate = new EntryDelegate( true, dbHelper,this );
    EntryDelegate* tableDelegate = new EntryDelegate( false, dbHelper,this );
    ui->ganttView->leftView()->setItemDelegate( treeDelegate );
    tasksTableView->setItemDelegate(tableDelegate);
    GanntItemDelegate* itemDelegate = new GanntItemDelegate(dbHelper, this);
    ui->ganttView->graphicsView()->setItemDelegate(itemDelegate);
}

void MainWindow::initGrid()
{
    grid = new CustomDateTimeGrid();
    ui->ganttView->setGrid( grid );
}

void MainWindow::initTableView()
{
    tasksTableView->setFixedWidth(270);
    tasksTableView->setColumnHidden(0,true);
    tasksTableView->setColumnHidden(2,true);
    tasksTableView->setColumnHidden(3,true);
    tasksTableView->setColumnHidden(4,true);
    tasksTableView->setColumnHidden(5,true);
    tasksTableView->setColumnHidden(6,true);
    tasksTableView->setColumnHidden(7,true);
    tasksTableView->setAlternatingRowColors(true);
    tasksTableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    tasksTableView->setColumnWidth(1,270);
    tasksTableView->horizontalHeader()->setFixedHeight(30);
    for (int i=0; i<8; i++){
        tableModel->horizontalHeaderItem(i)->setTextAlignment(Qt::AlignHCenter);
        if (i >=2 && i <=4)
            ui->tasksTable->resizeColumnToContents(i);
        else ui->tasksTable->horizontalHeader()->setSectionResizeMode(i,QHeaderView::Stretch);
    }

    ui->tasksTable->setColumnHidden(0, true);
    ui->tasksTable->setColumnHidden(1, true);
    ui->tasksTable->setAlternatingRowColors(true);
    ui->tasksTable->horizontalHeader()->setFixedHeight(30);
    ui->tasksTable->verticalHeader()->hide();
    ui->tasksTable->setEditTriggers(QAbstractItemView::NoEditTriggers);

    ui->tasksTable->setSelectionModel(tasksTableView->selectionModel());
    ui->tasksTable->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tasksTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    tasksTableView->setSelectionMode(QAbstractItemView::SingleSelection);
    tasksTableView->setSelectionBehavior(QAbstractItemView::SelectRows);
}


void MainWindow::initTreeView()
{
    ganttTreeView->setFixedWidth(270);
    ganttTreeView->setColumnHidden( 1, true );
    ganttTreeView->setColumnHidden( 2, true );
    ganttTreeView->setColumnHidden( 3, true );
    ganttTreeView->setColumnHidden( 4, true );
    ganttTreeView->setColumnHidden( 5, true );
    ganttTreeView->setColumnHidden( 6, true );
    ganttTreeView->setColumnHidden( 7, true );
    ganttTreeView->header()->setStretchLastSection(true);

    treeModel->setColumnCount(7);
    treeModel->setHeaderData( 0, Qt::Horizontal, tr( "Навигатор" ) );
    treeModel->horizontalHeaderItem(0)->setTextAlignment(Qt::AlignHCenter);

    ganttTreeView->setAnimated(true);
    ganttTreeView->setItemsExpandable(true);
    ganttTreeView->expandAll();
}

void MainWindow::showTreeContextMenu( const QPoint& pos )
{
    if ( !ui->ganttView->leftView()->indexAt( pos ).isValid() )
        ui->ganttView->selectionModel()->clearSelection();

    QMenu menu( ui->ganttView->leftView() );
    menu.addAction( addProjectAction );
    menu.addAction( addTaskAction );
    menu.addAction( removeAction );
    menu.exec( ui->ganttView->leftView()->viewport()->mapToGlobal( pos ) );
}

void MainWindow::showTableContextMenu(const QPoint &pos)
{
    if ( !tasksTableView->indexAt( pos ).isValid() )
        tasksTableView->selectionModel()->clearSelection();

    QMenu menu( tasksTableView );
    menu.addAction( addProjectAction );
    menu.addAction( addTaskAction );
    menu.addAction( removeAction );
    menu.exec( tasksTableView->viewport()->mapToGlobal( pos ) );
}

void MainWindow::enableActions(const QItemSelection & selected)
{
    selectedProjectId = 0;
    if ( selected.indexes().isEmpty() ) {
        addProjectAction->setEnabled( ui->graphViewRb->isChecked() );
        addTaskAction->setEnabled( true );
        removeAction->setEnabled( false );
        ui->addProjectPb->setEnabled(ui->graphViewRb->isChecked());
        ui->removePb->setEnabled(false);
        ui->editPb->setEnabled(false);
        ui->projectSummary->setEnabled(false);
        return;
    }

    QModelIndex selectedIndex = selected.indexes()[0];

    if (!ui->graphViewRb->isChecked()){
        addProjectAction->setEnabled( false );
        addTaskAction->setEnabled( false );
        removeAction->setEnabled( true );
        ui->addProjectPb->setEnabled(false);
        ui->removePb->setEnabled(true);
        ui->editPb->setEnabled(true);
        QModelIndex sel = getSelectedIndex();
        if (dbHelper->getTasksModel()->data(
                    dbHelper->getTasksModel()->index(sel.row(),2)).toString() != tr("Вне проектов")){
            selectedProjectId = dbHelper->getRegularTasksModel()->data(
                        dbHelper->getRegularTasksModel()->index(sel.row(),2)).toInt();
            ui->projectSummary->setEnabled(true);
        }
        else ui->projectSummary->setEnabled(false);
        return;
    }
    int kind = treeModel->data( treeModel->index( selectedIndex.row(), 1,
                                                  selectedIndex.parent() ) ).toInt();
    if (kind  == KDGantt::TypeSummary || kind == KDGantt::TypeTask ) {
        addProjectAction->setEnabled( false );
        addTaskAction->setEnabled( false );
        removeAction->setEnabled( true );
        ui->addProjectPb->setEnabled(true);
        ui->removePb->setEnabled(true);
        ui->editPb->setEnabled(true);
        ui->projectSummary->setEnabled(true);
        if (kind == KDGantt::TypeSummary){
            selectedProjectId = treeModel->data( treeModel->index( selectedIndex.row(), 5,
                                                                   selectedIndex.parent() ) ).toInt();
        }
        else {
            int taskId = treeModel->data( treeModel->index( selectedIndex.row(), 5,
                                                            selectedIndex.parent() ) ).toInt();
            QSqlTableModel* tasks = dbHelper->getRegularTasksModel();
            for (int i=0; i<tasks->rowCount(); i++){
                int itsId = tasks->data(tasks->index(i,0)).toInt();
                if (itsId == taskId){
                    if (dbHelper->getTasksModel()->data(dbHelper->getTasksModel()->index(i,2)).toString()
                            == tr("Вне проектов"))
                        selectedProjectId = 0, ui->projectSummary->setEnabled(false);
                    else selectedProjectId = tasks->data(tasks->index(i,2)).toInt();
                    break;
                }
            }
        }
        return;
    }
    else if ( kind == KDGantt::TypeNone ){
        addProjectAction->setEnabled( true );
        addTaskAction->setEnabled( true );
        removeAction->setEnabled( false );
        ui->addProjectPb->setEnabled(true);
        ui->removePb->setEnabled(false);
        ui->editPb->setEnabled(false);
        ui->projectSummary->setEnabled(false);
        return;
    }
    addProjectAction->setEnabled( true );
    addTaskAction->setEnabled( true );
    removeAction->setEnabled( true );
    ui->addProjectPb->setEnabled(true);
    ui->removePb->setEnabled(true);
    ui->editPb->setEnabled(true);
    ui->projectSummary->setEnabled(false);
}


void MainWindow::offerAutoSchedule(int projectId, Change change, int oldProjectId)
{
    if (projectId == dbHelper->getDefaultProjectId())
        return;
    QString str;
    if (change == Change_Added)
        str = tr(" добавлением ");
    else if (change == Change_Deleted)
        str = tr(" удалением ");
    else if (change == Change_PrioEdited) str = tr(" изменением приоритета ");
    QString msg = tr("Произвести авто-планирование проекта в связи с") + str + tr("задачи?");
    if (change == Change_ProjectEdited)
        msg = tr("Произвести авто-планирование проектов в связи с переходом задачи в другой проект?");
    if (!Util::accept(msg,this))
        return;
    dbHelper->reorderProjectTasks(projectId);
    if (oldProjectId != 0 && oldProjectId != dbHelper->getDefaultProjectId())
        dbHelper->reorderProjectTasks(oldProjectId);
}

void MainWindow::applyStyle(int styleNo, bool hover)
{ 
    if (styleNo == 0)
        styleNo++;
    if (!hover){
        if (styleNo == 1 && !color1->isChecked())
            color1->setChecked(true);
        else if (styleNo == 2 && !color2->isChecked())
            color2->setChecked(true);
        else if (styleNo == 3 && !color3->isChecked())
            color3->setChecked(true);
        else if (styleNo == 4 && !color4->isChecked())
            color4->setChecked(true);
    }
    Stylizer stylizer(QString("colors%1.txt").arg(styleNo));
}

void MainWindow::changeStyle()
{
    if (color1->isChecked())
        applyStyle(1,false);
    else if (color2->isChecked())
        applyStyle(2,false);
    else if (color3->isChecked())
        applyStyle(3,false);
    else if (color4->isChecked())
        applyStyle(4,false);
}

void MainWindow::col1Hovered()
{
    applyStyle(1);
}

void MainWindow::col2Hovered()
{
    applyStyle(2);
}

void MainWindow::col3Hovered()
{
    applyStyle(3);
}

void MainWindow::col4Hovered()
{
    applyStyle(4);
}

QModelIndex MainWindow::getSelectedIndex()
{
    QModelIndexList selectedIndexes;
    QModelIndex index;
    if (ui->graphViewRb->isChecked()){
        selectedIndexes = ganttTreeView->selectionModel()->selectedIndexes();
        index = selectedIndexes.value( 0 );
    }
    else{
        index = proxyModel->mapToSource(tasksTableView->selectionModel()->selectedIndexes().value(0));
    }
    return index;
}

void MainWindow::zoomIn()
{
    if (!grid->zoomIn())
        zoomInAction->setEnabled(false);
    else zoomOutAction->setEnabled(true);
    ui->ganttView->graphicsView()->updateScene();
}

void MainWindow::zoomOut()
{
    if (!grid->zoomOut())
        zoomOutAction->setEnabled(false);
    else zoomInAction->setEnabled(true);
    ui->ganttView->graphicsView()->updateScene();
}

void MainWindow::on_projectSummary_clicked()
{
    SummaryWindow *w = new SummaryWindow(selectedProjectId,dbHelper, this);
    w->show();
}

void MainWindow::on_manageTeamsPb_clicked()
{
    TeamDialog *d = new TeamDialog(dbHelper, this);
    d->show();
}


void MainWindow::on_graphViewRb_toggled(bool checked)
{
    if (checked){
        ui->stackedWidget->setCurrentIndex(0);
        ui->toggleEditCb->setEnabled(true);

        ui->sortByTb->setVisible(false);
        ui->sortType->setVisible(false);
        ui->filterByTb->setVisible(false);
        ui->groupByProjectsCb->setVisible(false);

        zoomInAction->setEnabled(true);
        zoomOutAction->setEnabled(true);
    }
    else {
        ui->stackedWidget->setCurrentIndex(1);
        ui->toggleEditCb->setEnabled(false);

        ui->sortByTb->setVisible(true);
        ui->sortType->setVisible(true);
        ui->sortType->setEnabled(!ui->sortByTb->menu()->actions().value(0)->isChecked());
        ui->filterByTb->setVisible(true);
        ui->groupByProjectsCb->setVisible(true);

        zoomInAction->setEnabled(false);
        zoomOutAction->setEnabled(false);
    }
    updateModel();
}


void MainWindow::on_pushButton_clicked()
{
    Q::Legend *l = new Q::Legend(this);
    l->show();
}

void MainWindow::editItem()
{
    QModelIndex index = getSelectedIndex();
    if (!index.isValid())
        return;

   if (ui->graphViewRb->isChecked()){
       StandardItem* item = (StandardItem*)(treeModel->itemFromIndex(index));
       int id = item->idItem->data(Qt::DisplayRole).toInt();
       if (item->ganttType->data(Qt::DisplayRole).toInt() == KDGantt::TypeSummary){
           ProjectDialog* dialog = new ProjectDialog(dbHelper,id);
           if ( dialog->exec() == QDialog::Rejected || !dialog ) {
               delete dialog;
               return;
           }
       }
       else if (item->ganttType->data(Qt::DisplayRole).toInt() == KDGantt::TypeTask){
           TaskDialog* dialog = new TaskDialog(dbHelper,id);
           if ( dialog->exec() == QDialog::Rejected || !dialog ) {
               delete dialog;
               return;
           }
           int id = dialog->getId();
           int projectId = dbHelper->getTaskData(id,Task_ProId).toInt();
           if (dialog->isProjectChanged()){
               offerAutoSchedule(projectId,Change_ProjectEdited, dialog->getOldProjectId());
           }
           else if (dialog->priorityIsChanged()){
               offerAutoSchedule(projectId, Change_PrioEdited);
           }
       }
   }
   else {
       QStandardItem* item = tableModel->itemFromIndex(index);
       int id = item->data(Qt::DisplayRole).toInt();
       TaskDialog* dialog = new TaskDialog(dbHelper,id);
       if ( dialog->exec() == QDialog::Rejected || !dialog ) {
           delete dialog;
           return;
       }
   }

   updateModel();
}

void MainWindow::removeItem()
{
    QModelIndex index = getSelectedIndex();
    if (!index.isValid())
        return;
   if (ui->graphViewRb->isChecked()){
       StandardItem* item = (StandardItem*)(treeModel->itemFromIndex(index));
       int id = item->idItem->data(Qt::DisplayRole).toInt();
       if (item->ganttType->data(Qt::DisplayRole).toInt() == KDGantt::TypeSummary){
           if (!Util::accept(tr("Удаление проекта приведет к удалению ВСЕХ задач, относящихся к нему. "
                                "Вы уверены, что хотите это сделать?"),this))
               return;
           dbHelper->removeProject(id);
       }
       else if (item->ganttType->data(Qt::DisplayRole).toInt() == KDGantt::TypeTask){
           if (!Util::accept(tr("Вы уверены, что хотите удалить задачу?"),this))
               return;
           int projectId = dbHelper->getTaskData(id,Task_ProId).toInt();
           dbHelper->removeTask(id);
           offerAutoSchedule(projectId, Change_Deleted);
       }
   }
   else {
       QStandardItem* item = tableModel->itemFromIndex(index);
       int id = item->data(Qt::DisplayRole).toInt();
       dbHelper->removeTask(id);
   }

   updateModel();
}

void MainWindow::on_editPb_clicked()
{
    editItem();
}

void MainWindow::on_removePb_clicked()
{
    removeItem();
}

void MainWindow::showHelp()
{
    HelpDialog* help = new HelpDialog();
    help->show();
}

void MainWindow::open()
{
    switch (Util::choice(tr("Сохранить текущий файл?"),this)){
        case QMessageBox::Cancel:
        return;
        case QMessageBox::Yes:
        dbHelper->saveDatabase();
        break;
    }
    QString filename = QFileDialog::
            getOpenFileName(0,QString(tr("Открыть файл")),"C:/Users/",tr("База данных sqlite (*.db *.sqlite)"));
    dbHelper->closeDatabase();
    dbHelper->openDatabase(filename);
}

void MainWindow::save()
{
    dbHelper->saveDatabase();
}

void MainWindow::create()
{
    switch (Util::choice(tr("Сохранить текущий файл?"),this)){
        case QMessageBox::Cancel:
        return;
        case QMessageBox::Yes:
        dbHelper->saveDatabase();
        break;
    }
    dbHelper->closeDatabase();
    dbHelper->createDatabase();
}


//sorting & filtering
void MainWindow::sortNone(bool st){
    if (st)
        proxyModel->setSortBy(None);
    ui->sortType->setEnabled(!st);
}
void MainWindow::sortProgress(bool st){
if (st)
    proxyModel->setSortBy(Progress);
}
void MainWindow::sortPrio(bool st){
    if (st)
        proxyModel->setSortBy(Priority);
}
void MainWindow::sortBegin(bool st){
    if (st)
        proxyModel->setSortBy(BeginTime);
}
void MainWindow::sortEnd(bool st){
    if (st)
        proxyModel->setSortBy(EndTime);
}
void MainWindow::sortAsc(bool st){
    if (st)
        proxyModel->setSortOrder(Ascending);
}
void MainWindow::sortDesc(bool st){
    if (st)
        proxyModel->setSortOrder(Descending);
}
void MainWindow::filterCompl(bool st){
    proxyModel->setFilter(Completed,st);
}
void MainWindow::filterActual(bool st){
    proxyModel->setFilter(Actual,st);
}
void MainWindow::filterLate(bool st){
    proxyModel->setFilter(Late,st);
}
void MainWindow::filterPlanned(bool st){
    proxyModel->setFilter(Planned,st);
}

void MainWindow::filterAll(bool st)
{
    if (filterActualAction->isChecked() &&
            filterComplAction->isChecked() &&
            filterLateAction->isCheckable() &&
            filterPlannedAction->isChecked()){
        filterActualAction->setChecked(false);
        filterComplAction->setChecked(false);
        filterLateAction->setChecked(false);
        filterPlannedAction->setChecked(false);
    }
    else {
        filterActualAction->setChecked(true);
        filterComplAction->setChecked(true);
        filterLateAction->setChecked(true);
        filterPlannedAction->setChecked(true);
    }
}
void MainWindow::on_groupByProjectsCb_toggled(bool checked){
    proxyModel->setGroupByProject(checked);
    proxyModel->doSort();
}

void MainWindow::on_toggleEditCb_toggled(bool checked)
{
    ui->ganttView->graphicsView()->setReadOnly(!checked);
}

