#ifndef GANNTITEMDELEGATE_H
#define GANNTITEMDELEGATE_H

#include <KDGanttItemDelegate>
#include <QColor>
#include "databasehelper.h"
using namespace KDGantt;

class GanntItemDelegate : public ItemDelegate
{
    static const QColor colorSelected1;
    static const QColor colorSelected2;
    static const QColor colorPrio[5][2];
    static const QColor colorPen;
    static const QColor progressColor;
    static const int penWidth;
    static const int penOpacity;
    static const int progressOpacity;
    DataBaseHelper* dbHelper;
public:
    GanntItemDelegate(DataBaseHelper* dbHelper, QObject *parent=0);
    void paintGanttItem( QPainter* painter, const StyleOptionGanttItem& opt, const QModelIndex& idx );
};

#endif // GANNTITEMDELEGATE_H
