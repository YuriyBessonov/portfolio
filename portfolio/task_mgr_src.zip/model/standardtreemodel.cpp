#include "standardtreemodel.h"
#include "databasehelper.h"
#include <QMap>

StandardTreeModel::StandardTreeModel( QObject *parent) : QStandardItemModel(parent)
{

}

void StandardTreeModel::makeTree(QSqlTableModel *projectsModel,
                                 QSqlRelationalTableModel *tasksModel, DataBaseHelper* dbHelper)
{
    QStandardItem *parent = invisibleRootItem();
    int projects = projectsModel->rowCount();
    //хранит пары "имя проекта - project item"
    QMap<QString,StandardItem*> projectsMap;
    for (int i=0; i<projects; i++){
        int id = projectsModel->data(projectsModel->index(i,0)).toInt();
        QString name = projectsModel->data(projectsModel->index(i,1)).toString();
        StandardItem* pr = new StandardItem(
                    name,
                    StandardItem::ItemProject,
                    projectsModel->data(projectsModel->index(i,3)),
                    projectsModel->data(projectsModel->index(i,4)),
                    QVariant(id),
                    QVariant()
                    );
        parent->appendRow(pr->getRow());
        projectsMap.insert(name, pr);
    }

    int tasks = tasksModel->rowCount();
    //хранит пары "имя группы - group item"
    QMap<QString,StandardItem*> groupsMap;
    QMap<StandardItem*,int> groupsMapRow;
    for (int i=0; i<tasks; i++)
    {
        QString groupName = tasksModel->data(tasksModel->index(i,3)).toString();
        QString project = tasksModel->data(tasksModel->index(i,2)).toString();
        QDate begin = tasksModel->data(tasksModel->index(i,5)).toDate();
        QDate end = begin.addDays(tasksModel->data(tasksModel->index(i,6)).toInt());
        StandardItem* group;
        if (groupName.length() == 0){
            group = projectsMap[project];
        }
        else if (!groupsMap.contains(project+groupName)){
            QStandardItem* parent = projectsMap[project];
            group = new StandardItem(
                        groupName,
                        StandardItem::ItemGroup,
                        begin,
                        end,
                        QVariant(),
                        QVariant()
                        );
            parent->appendRow(group->getRow());
            groupsMap.insert(project+groupName,group);
            //groupsMapRow.insert(group, parent->rowCount()-1,);
        }
        else{
            group = groupsMap[project+groupName];
            QDate grBegin = group->getBeginDate();
            //if ()
        }


        int duration = tasksModel->data(tasksModel->index(i,6)).toInt();
        StandardItem* task = new StandardItem(
                    tasksModel->data(tasksModel->index(i,1)),
                    StandardItem::ItemTask,
                    tasksModel->data(tasksModel->index(i,5)),
                    tasksModel->data(tasksModel->index(i,5)).toDate().addDays(duration),
                    tasksModel->data(tasksModel->index(i,0)),
                    tasksModel->data(tasksModel->index(i,7))
                    );
        task->setData(tasksModel->data(tasksModel->index(i,0)), Qt::UserRole +1);
        QIcon icon;
        int status = dbHelper->getTaskStatusByRow(i);
        switch (status){
            case Planned:
                icon = QIcon(":icons/res/status_planned.png");
                break;
        case Late:
            icon = QIcon(":icons/res/status_late.png");
            break;
        case Actual:
            icon = QIcon(":icons/res/status_actual.png");
            break;
        case Completed:
            icon = QIcon(":icons/res/status_done.png");
            break;
        }
        task->setIcon(icon);
        group->appendRow(task->getRow());
    }
}

