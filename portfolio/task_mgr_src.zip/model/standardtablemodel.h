#ifndef STANDARDTABLEMODEL_H
#define STANDARDTABLEMODEL_H

#include <QStandardItemModel>
#include <QSqlRelationalTableModel>
#include <QSqlTableModel>
#include <databasehelper.h>

class StandardTableModel : public QStandardItemModel
{
    Q_OBJECT

public:
    explicit StandardTableModel(QObject *parent=0);
    void makeTableModel(QSqlTableModel *projectsModel,
                        QSqlRelationalTableModel *tasksModel, DataBaseHelper *dbHelper);
};

#endif // STANDARDTABLEMODEL_H
