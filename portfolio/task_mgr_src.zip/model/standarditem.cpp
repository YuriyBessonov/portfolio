#include "standarditem.h"
#include <QObject>
StandardItem::StandardItem(QVariant text, ItemType itemType, QVariant beginDate,
                           QVariant endDate, QVariant id, QVariant priority) :
                           QStandardItem(text.toString())
{
    ganttType = new QStandardItem();
    switch (itemType){
    case ItemProject:
        if (text.toString() == QObject::tr("Вне проектов"))
            ganttType->setData(KDGantt::TypeNone, Qt::DisplayRole);
        else ganttType->setData(KDGantt::TypeSummary, Qt::DisplayRole);
        break;
    case ItemGroup:
        ganttType->setData(KDGantt::TypeNone, Qt::DisplayRole);
        break;
    case ItemTask:
        ganttType->setData(KDGantt::TypeTask, Qt::DisplayRole);
        break;
    }

    beginDateItem = new QStandardItem();
    beginDateItem->setData(beginDate, KDGantt::StartTimeRole);

    endDateItem = new QStandardItem();
    endDateItem->setData(endDate, KDGantt::EndTimeRole);

    priorityItem = new QStandardItem();
    priorityItem->setData(priority, Qt::DisplayRole);

    idItem = new QStandardItem();
    idItem->setData(id, Qt::DisplayRole);
}

QList<QStandardItem *> StandardItem::getRow()
{
    return QList<QStandardItem*>() << this << ganttType << beginDateItem
                                   << endDateItem << priorityItem<<idItem;
}

QStandardItem *StandardItem::getIdItem() const
{
    return idItem;
}

QDate StandardItem::getBeginDate()
{
    return beginDateItem->data(KDGantt::StartTimeRole).toDate();
}

QDate StandardItem::getEndDate()
{
    return endDateItem->data(KDGantt::EndTimeRole).toDate();
}

QStandardItem *StandardItem::getGanttType() const
{
    return ganttType;
}
