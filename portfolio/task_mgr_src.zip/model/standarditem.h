#ifndef STANDARDITEM_H
#define STANDARDITEM_H
#include <QStandardItem>
#include <KDGantt>
#include <QDate>
#include <Qlist>

class StandardItem : public QStandardItem
{
public:
    enum ItemType {ItemProject, ItemGroup, ItemTask};
    explicit StandardItem(QVariant text, ItemType itemType, QVariant beginDate,
                          QVariant endDate,QVariant id, QVariant priority);
public:
    QList<QStandardItem*> getRow();
    QStandardItem* ganttType;
    QStandardItem* beginDateItem;
    QStandardItem* endDateItem;
    QStandardItem* priorityItem;
    QStandardItem* idItem;
    QStandardItem *getGanttType() const;
    QStandardItem *getIdItem() const;
    QDate getBeginDate();
    QDate getEndDate();
};

#endif // STANDARDITEM_H
