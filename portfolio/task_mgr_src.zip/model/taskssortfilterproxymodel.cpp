#include "taskssortfilterproxymodel.h"
#include <QDate>
#include <QDebug>

TasksSortFilterProxyModel::TasksSortFilterProxyModel(DataBaseHelper *dbHelper, QObject *parent)
    : QSortFilterProxyModel(parent)
{
    sortOrder = Ascending;
    sortBy = None;
    groupByProject = false;
    filter[0] = filter[1] = filter[2] = filter[3] = true;
    this->dbHelper = dbHelper;
}

void TasksSortFilterProxyModel::setSortOrder(const SortOrder &value)
{
    sortOrder = value;
    doSort();
}

void TasksSortFilterProxyModel::setSortBy(const SortBy &value)
{
    sortBy = value;
    doSort();
}


void TasksSortFilterProxyModel::setFilter(TaskStatus f, bool allow)
{
    filter[f]=allow;
    setFilterWildcard("");
}

void TasksSortFilterProxyModel::setGroupByProject(bool enabled)
{
    groupByProject = enabled;
    doSort();
}

void TasksSortFilterProxyModel::doSort()
{
    Qt::SortOrder order = (sortOrder == Ascending) ? Qt::AscendingOrder : Qt::DescendingOrder;
    switch (sortBy){
    case None:
        sort(0,Qt::AscendingOrder);
        break;
    case Progress:
        sort(5,order);
        break;
    case Priority:
        sort(4,order);
        break;
    case BeginTime:
        sort(6,order);
        break;
    case EndTime:
        sort(7,order);
        break;
    }
}

void TasksSortFilterProxyModel::doFilter()
{
    setFilterWildcard("");
}

bool TasksSortFilterProxyModel::filterAcceptsRow(int sourceRow, const QModelIndex &sourceParent) const
{
    int status = dbHelper->getTaskStatusByRow(sourceRow);
    return filter[status];
}

bool TasksSortFilterProxyModel::lessThan(const QModelIndex &left, const QModelIndex &right) const
{
    QVariant leftData = sourceModel()->data(left);
    QVariant rightData = sourceModel()->data(right);

    if (groupByProject == true){
        QString leftProject = sourceModel()->data
                    (sourceModel()->index(left.row(),2)).toString();
        QString rightProject = sourceModel()->data
                (sourceModel()->index(right.row(),2)).toString();
        if (leftProject != rightProject)
                return leftProject < rightProject;
    }

    if (sortBy == Progress){
        int leftProgress = sourceModel()->data(left,Qt::UserRole+1).toInt();
        int rightProgress = sourceModel()->data(right,Qt::UserRole+1).toInt();
        return (leftProgress < rightProgress);
    }
    if (sortBy == Priority){
        int leftPrio = sourceModel()->data(left,Qt::UserRole+1).toInt();
        int rightPrio = sourceModel()->data(right,Qt::UserRole+1).toInt();
        return (leftPrio < rightPrio);
    }
    if (sortBy == BeginTime){
        QDate leftBegin = sourceModel()->data(left).toDate();
        QDate rightBegin  = sourceModel()->data(right).toDate();
        return (leftBegin < rightBegin);
    }
    if (sortBy == EndTime){
        QDate leftEnd = sourceModel()->data(left).toDate();
        QDate rightEnd  = sourceModel()->data(right).toDate();
        return (leftEnd < rightEnd);
    }

    return leftData.toString() < rightData.toString();
}
