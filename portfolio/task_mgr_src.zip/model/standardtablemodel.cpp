#include "standardtablemodel.h"
#include <QList>
#include <QStandardItem>
#include <QVariant>
#include <QDate>
#include "databasehelper.h"

StandardTableModel::StandardTableModel(QObject *parent)
    : QStandardItemModel(parent)
{

}

void StandardTableModel::makeTableModel(QSqlTableModel *projectsModel, QSqlRelationalTableModel *tasksModel,DataBaseHelper* dbHelper)
{
    clear();
    setColumnCount(8);
    setHorizontalHeaderLabels(QStringList() << tr("id") << tr("Название")
                              << tr("Проект") << tr("Группа") << tr("Приоритет")
                              <<tr("Прогресс")<<tr("Дата начала")<<tr("Дата завершения"));
    int tasks = tasksModel->rowCount();
    for (int i=0; i<tasks; i++){
        QList<QStandardItem*> items;
        QStandardItem* id = new QStandardItem();
        id->setData(tasksModel->data(tasksModel->index(i,0)),Qt::DisplayRole);
        QStandardItem* name = new QStandardItem();
        QIcon icon;
        int status = dbHelper->getTaskStatusByRow(i);
        switch (status){
            case Planned:
                icon = QIcon(":icons/res/status_planned.png");
                break;
            case Late:
                icon = QIcon(":icons/res/status_late.png");
                break;
            case Actual:
                icon = QIcon(":icons/res/status_actual.png");
                break;
            case Completed:
                icon = QIcon(":icons/res/status_done.png");
                break;
        }
        name->setIcon(icon);
        name->setData(tasksModel->data(tasksModel->index(i,1)),Qt::DisplayRole);
        name->setData(tasksModel->data(tasksModel->index(i,1)),Qt::ToolTipRole);
        QStandardItem* project = new QStandardItem();
        project->setData(tasksModel->data(tasksModel->index(i,2)),Qt::DisplayRole);
        project->setData(tasksModel->data(tasksModel->index(i,2)),Qt::ToolTipRole);
        QStandardItem* group = new QStandardItem();
        QString groupStr = tasksModel->data(tasksModel->index(i,3)).toString();
        groupStr = (groupStr == "") ? tr("-") : groupStr;
        group->setData(groupStr,Qt::DisplayRole);
        group->setData(groupStr,Qt::ToolTipRole);
        QStandardItem* priority = new QStandardItem();
        int prio = tasksModel->data(tasksModel->index(i,4)).toInt();
        QString prioStr[] = {tr("Незначительный"), tr("Низкий"),tr("Обычный"),
                           tr("Высокий"), tr("Критически высокий")};
        priority->setData(prio);
        priority->setData("",Qt::DisplayRole);
        priority->setTextAlignment(Qt::AlignHCenter);
        QImage image = QImage(QString(":icons/res/prio_%1.png").arg(prio)).scaled(QSize(56, 28));
        priority->setData(QVariant(QPixmap::fromImage(image)),Qt::DecorationRole);
        priority->setData(prioStr[prio],Qt::ToolTipRole);
        QStandardItem* progress = new QStandardItem();
        progress->setData(tasksModel->data(tasksModel->index(i,7)).toString()+" %",Qt::DisplayRole);
        progress->setData(tasksModel->data(tasksModel->index(i,7)).toInt());
        QStandardItem* beginDate = new QStandardItem();
        beginDate->setData(tasksModel->data(tasksModel->index(i,5)).toDate(),Qt::DisplayRole);
        int duration = tasksModel->data(tasksModel->index(i,6)).toInt();
        QStandardItem* endDate = new QStandardItem();
        endDate->setData(tasksModel->data(tasksModel->index(i,5)).toDate().addDays(duration),
                         Qt::DisplayRole);
        items<<id<<name<<project<<group<<priority<<progress<<beginDate<<endDate;
        for (int i=2; i<8; i++)
            items.at(i)->setTextAlignment(Qt::AlignHCenter);

        appendRow(items);
    }
}
