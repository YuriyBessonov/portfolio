#ifndef TASKSSORTFILTERPROXYMODEL_H
#define TASKSSORTFILTERPROXYMODEL_H

#include <QSortFilterProxyModel>
#include "databasehelper.h"

enum SortBy {None,Progress, Priority, BeginTime, EndTime};
enum SortOrder {Ascending, Descending};

class TasksSortFilterProxyModel : public QSortFilterProxyModel
{
    Q_OBJECT

public:

    TasksSortFilterProxyModel( DataBaseHelper* dbHelper, QObject *parent = 0);
    void setSortOrder(const SortOrder &value);
    void setSortBy(const SortBy &value);
    void setFilter(TaskStatus f, bool allow);
    void setGroupByProject(bool enabled);
    void doSort();
    void doFilter();
private:
    SortOrder sortOrder;
    SortBy sortBy;
    bool groupByProject;
    bool filter[4];
    DataBaseHelper* dbHelper;
protected:
    bool filterAcceptsRow(int sourceRow, const QModelIndex &sourceParent) const;
    bool lessThan(const QModelIndex &left, const QModelIndex &right) const;

};

#endif // TASKSSORTFILTERPROXYMODEL_H
