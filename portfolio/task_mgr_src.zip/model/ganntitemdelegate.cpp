#include "ganntitemdelegate.h"
#include <QPainter>
#include <QRectF>
#include <QStyle>
#include <QApplication>
#include <KDGanttStyleOptionGanttItem>
#include "standarditem.h"
const QColor GanntItemDelegate::colorSelected1 = QColor(86,196,243);
const QColor GanntItemDelegate::colorSelected2 = QColor(54,123,153);

const QColor GanntItemDelegate::colorPrio[5][2] = { {QColor(178,242,58), QColor(112,153,37)},
                                                    {QColor(204,217,63), QColor(132,140,41)},
                                                    {QColor(217,171,54), QColor(140,112,39)},
                                                    {QColor(217,107,56), QColor(140,69,36)},
                                                    {QColor(224,54,54), QColor(128,31,31)} };

const QColor GanntItemDelegate::colorPen = QColor(40,40,40);
const QColor GanntItemDelegate::progressColor = QColor(0,0,0);
const int GanntItemDelegate::penWidth = 1;
const int GanntItemDelegate::penOpacity = 150;
const int GanntItemDelegate::progressOpacity = 130;

GanntItemDelegate::GanntItemDelegate(DataBaseHelper *dbHelper, QObject *parent) : ItemDelegate(parent)
{
    this->dbHelper = dbHelper;
}

void GanntItemDelegate::paintGanttItem( QPainter* painter, const KDGantt::StyleOptionGanttItem& opt, const QModelIndex& idx )
{

    painter->setRenderHints( QPainter::Antialiasing );
    if ( !idx.isValid() ) return;
    ItemType type = static_cast<ItemType>(
    idx.model()->data( idx, ItemTypeRole ).toInt() );
    QString txt = idx.model()->data( idx, Qt::DisplayRole ).toString();
    QRectF itemRect = opt.itemRect;
    QRectF boundingRect = opt.boundingRect;
    boundingRect.setY( itemRect.y() );
    boundingRect.setHeight( itemRect.height() );
    QBrush brush = defaultBrush( type );

    QPen pen = defaultPen(type);
    pen.setWidth(penWidth);
    QColor penColor = colorPen;

    if ( opt.state & QStyle::State_Selected ) {
        QLinearGradient selectedGrad( 0., 0., 0.,
        QApplication::fontMetrics().height() );
        selectedGrad.setColorAt( 0., colorSelected1);
        selectedGrad.setColorAt( 1., colorSelected2 );
        selectedGrad.setInterpolationMode(QGradient::ColorInterpolation);
        brush = QBrush( selectedGrad );
        penColor.setAlpha(penOpacity);
    }
    else penColor.setAlpha(255);
    pen.setBrush(QBrush(penColor));

    painter->setPen( pen );
    painter->setBrush( brush );
    painter->setBrushOrigin( itemRect.topLeft() );

    switch( type ) {
        case TypeTask:
           if ( itemRect.isValid() ) {
               int taskId = idx.model()->data(idx,Qt::UserRole +1).toInt();
               int prio = dbHelper->getTaskData(taskId, Task_Prio).toInt();

               if (!(opt.state & QStyle::State_Selected) ){
                   QLinearGradient taskGrad( 0., 0., 0.,
                   QApplication::fontMetrics().height() );
                   taskGrad.setColorAt( 0., colorPrio[prio][0]);
                   taskGrad.setColorAt( 1., colorPrio[prio][1]);
                   brush = QBrush( taskGrad );
                   painter->setBrush( brush );
               }

               qreal pw = painter->pen().width()/2.;
               pw-=1;
               QRectF r = itemRect;
               r.translate( 0., r.height()/6. );
               r.setHeight( 2.*r.height()/3. );
               painter->setBrushOrigin( itemRect.topLeft() );
               painter->save();
               painter->translate( 0.5, 0.5 );
               painter->drawRect( r );

               Qt::Alignment ta;
               switch( opt.displayPosition ) {
                   case StyleOptionGanttItem::Left: ta = Qt::AlignLeft; break;
                   case StyleOptionGanttItem::Right: ta = Qt::AlignRight; break;
                   case StyleOptionGanttItem::Center: ta = Qt::AlignCenter; break;
               }
               painter->drawText( boundingRect, ta, txt );

               bool ok;
               qreal completion = idx.model()->data( idx, KDGantt::TaskCompletionRole ).toReal( &ok );
               if ( ok ) {
                   qreal h = r.height();
                   QRectF cr( r.x(), r.y()+h/4.,
                              r.width()*completion/100., h/2.+1 /*??*/ );
                   //QColor compcolor( painter->pen().color() );
                   QColor compcolor( progressColor );
                   compcolor.setAlpha( progressOpacity );
                   painter->fillRect( cr, compcolor );
               }
               painter->restore();
           }
           break;

       case TypeSummary:
           if ( opt.itemRect.isValid() ) {
               qreal pw = painter->pen().width()/2.;
               pw -=1;
               const QRectF r = QRectF( opt.itemRect ).adjusted( -pw, -pw, pw, pw );
               QPainterPath path;
               const qreal deltaY = r.height()/2.;
               const qreal deltaXBezierControl = .25*qMin( r.width(), r.height() );
               const qreal deltaX = qMin( r.width()/2., r.height() );
               path.moveTo( r.topLeft() );
               path.lineTo( r.topRight() );
               path.lineTo( QPointF( r.right(), r.top() + 2.*deltaY ) );
               path.quadTo( QPointF( r.right()-deltaXBezierControl, r.top() + deltaY ), QPointF( r.right()-deltaX, r.top() + deltaY ) );
               path.lineTo( QPointF( r.left() + deltaX, r.top() + deltaY ) );
               path.quadTo( QPointF( r.left()+deltaXBezierControl, r.top() + deltaY ), QPointF( r.left(), r.top() + 2.*deltaY ) );

               path.closeSubpath();
               painter->setBrushOrigin( itemRect.topLeft() );
               painter->save();
               painter->translate( 0.5, 0.5 );
               painter->drawPath( path );
               painter->restore();
           }
           break;

        default:
            KDGantt::ItemDelegate::paintGanttItem( painter, opt, idx );
            break;
    }

}
