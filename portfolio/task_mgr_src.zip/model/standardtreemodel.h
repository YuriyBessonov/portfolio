#ifndef STANDARDTREEMODEL_H
#define STANDARDTREEMODEL_H
#include <QStandardItem>
#include <QStandardItemModel>
#include "standarditem.h"
#include <QSqlDatabase>
#include <QSqlRelationalTableModel>
#include <QSqlTableModel>
#include "databasehelper.h"

class StandardTreeModel : public QStandardItemModel
{
    Q_OBJECT

public:
    explicit StandardTreeModel(QObject *parent=0);
    void makeTree(QSqlTableModel* projectsModel,
                  QSqlRelationalTableModel* tasksModel, DataBaseHelper *dbHelper);
};
#endif // STANDARDTREEMODEL_H
