#ifndef ANIMATEDLINEEDIT_H
#define ANIMATEDLINEEDIT_H
#include <QColor>
#include <QLineEdit>
#include <QPropertyAnimation>
#include <QSequentialAnimationGroup>

class AnimatedLineEdit : public QLineEdit
{

  Q_OBJECT
  Q_PROPERTY(QColor color READ color WRITE setColor)

public:
  AnimatedLineEdit(QWidget *parent = 0) : QLineEdit(parent)
  {

  }
  void setColor (QColor color){
    setStyleSheet(QString("QLineEdit {background-color: rgb(%1, %2, %3); }").arg(color.red()).arg(color.green()).arg(color.blue()));
  }
  QColor color(){
    return Qt::black;
  }
  void animateErrorHighlight(){
      QPropertyAnimation *animation1 = new QPropertyAnimation(this, "color");
      animation1->setDuration(500);
      animation1->setStartValue(QColor(255, 255, 255));
      animation1->setEndValue(QColor(255, 80, 80));
      animation1->setEasingCurve(QEasingCurve::InQuad);

      QPropertyAnimation *animation2 = new QPropertyAnimation(this, "color");
      animation2->setDuration(500);
      animation2->setStartValue(QColor(255, 80, 80));
      animation2->setEndValue(QColor(255, 255, 255));
      animation2->setEasingCurve(QEasingCurve::OutQuad);

      QSequentialAnimationGroup* group = new QSequentialAnimationGroup(this);
      group->addAnimation(animation1);
      group->addAnimation(animation2);
      group->start();
  }
};

#endif // ANIMATEDLINEEDIT_H
