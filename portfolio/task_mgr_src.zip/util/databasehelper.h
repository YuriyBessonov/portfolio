#ifndef DATABASEHELPER_H
#define DATABASEHELPER_H
#include <QSqlDatabase>
#include <QSqlRelationalTableModel>
#include <QSqlTableModel>
#include <QStandardItemModel>
enum TaskStatus {Completed, Actual, Late, Planned };
enum TaskData {Task_Id, Task_Name, Task_ProId, Task_Grp, Task_Prio, Task_Begin, Task_Time, Task_Progress};
enum ProjectData {Project_Id, Project_Name, Project_Result, Project_Begin, Project_End };
enum Change {Change_Deleted, Change_PrioEdited, Change_ProjectEdited, Change_Added};
class DataBaseHelper
{
    QSqlDatabase db;
    QSqlTableModel* projectsModel;
    QSqlRelationalTableModel* tasksModel;
    QSqlTableModel* teamsModel;
    QSqlTableModel* teamsTasksModel;
    QString databaseName;
    QString tempDbName;
public:
    QObject *parent;
    static const QString DEFAULT_DATABASE;
    static const QString PROJECTS_TABLE;
    static const QString TASKS_TABLE;
    static const QString TEAMS_TABLE;
    static const QString TASK_TEAM_TABLE;
    static const QString PROJECT_ID;
    static const QString PROJECT_NAME;
    static const QString TASK_ID;
    static const QString TASK_NAME;
    static const QString TEAM_ID;
    static const QString TEAM_NAME;
    static const QString NEW_DATABASE;

    DataBaseHelper();
    void createDatabase();
    bool openDatabase(QString dbName);
    void saveDatabase();
    void closeDatabase();

    QSqlDatabase* getDB();
    void initModels(QObject* parent);
    void selectModels();
    QSqlTableModel *getProjectsModel();
    QSqlRelationalTableModel *getTasksModel() ;
    QSqlTableModel *getRegularTasksModel() ;
    QSqlTableModel *getTeamsModel();
    QSqlTableModel *getTeamsTasksModel();
    QSqlRelationalTableModel *getRelTeamsTasksModel() ;
    void updateModel();
    void removeTask(int id);
    void removeProject(int id);
    void removeTeamTask(int taskId);
    void reorderTasks(QList<int>& tasksRows, QDate beginTime, QDate endTime);
    void reorderProjectTasks(int id);
    int getDefaultProjectId();
    QVariant getTaskData(int id, TaskData field);
    QVariant getProjectData(int id, ProjectData field);
    TaskStatus getTaskStatus(int id);
    TaskStatus getTaskStatusByRow(int row);
    QStandardItemModel* getTeamsCheckList(int taskId =-1);
    QStandardItemModel* getTasksCheckList(int projectId =-1);
    QStandardItemModel* getTaskTeamsForProject(int projectId);
    QString getDatabaseName() const;
};

#endif // DATABASEHELPER_H
