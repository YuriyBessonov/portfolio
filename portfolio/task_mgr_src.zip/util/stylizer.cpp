#include "stylizer.h"
#include <QFile>
#include <QLatin1String>
#include <QApplication>
#include <QDebug>

Stylizer::Stylizer(QString filename)
{
    setColorScheme(filename);
    prepareStyle();
    qApp->setStyleSheet(styleSheet);
}

void Stylizer::setColorScheme(QString filename)
{
    QFile file(filename);
    file.open(QFile::ReadOnly);
    colorPrimary = QLatin1String(file.readLine());
    colorPrimary.chop(2);
    colorPrimaryLight = QLatin1String(file.readLine());
    colorPrimaryLight.chop(2);
    colorSecondary = QLatin1String(file.readLine());
    colorSecondary.chop(2);
    colorSecondaryLight = QLatin1String(file.readLine());
    colorSecondaryLight.chop(2);
    colorBorder = QLatin1String(file.readLine());
    colorBorder.chop(2);
    colorText = QLatin1String(file.readLine());
    colorText.chop(2);
    colorExtra = QLatin1String(file.readLine());
    file.close();
}

void Stylizer::prepareStyle()
{
    //заголовки
    styleSheet =
            QString("QLabel#todayLbl,#viewLbl,#grElemLbl,#taskStatLbl"
                    " {background-color: %1; font: bold %2;}").arg(colorPrimary).arg(colorText)+

            QString("QLabel#prinfoLbl,#progressLbl,#infogrLbl"
                    " {background-color: %1; font: bold 11pt %2;}").arg(colorPrimary).arg(colorText);
    //фоны
    styleSheet +=
            QString("QFrame#toolbar {background-color: %1; }").arg(colorPrimaryLight) +
            QString("QFrame#ProgressFrame {background: %1;  border: 1px solid %2;}").arg(colorSecondaryLight).arg(colorBorder)+
            QString("SummaryWindow QFrame {background-color: %1; }").arg(colorPrimaryLight) +
            QString("QTreeView, QListView, QTableView, QLineEdit, QDateEdit, QSpinBox, #teamsTv"
                    "{background-color: %1; alternate-background-color: %2; "
                    " selection-background-color: %3;}").arg(colorSecondaryLight).arg(colorExtra).arg(colorPrimary) +
            QString("QDialog {background-color: %1; }").arg(colorPrimaryLight) +
            QString("QGraphicsView {background-color: %1; }").arg(colorSecondaryLight)+
            QString("QHeaderView::section {background-color: %1; }").arg(colorSecondary) +
            QString("QLabel#taskListLbl, #teamsListLbl {background-color: %1; font: bold; }").arg(colorSecondary) +
            QString("QListView::item:selected:active, QTreeView::item:selected:active {background: %1; }").arg(colorPrimary);


    styleSheet +=
            QString("QFrame#chartsFrame, #frameAbout, #tprogressFrame {border: 1px solid %1; }").arg(colorBorder) +
            QString("QLabel {font: %1;}").arg(colorText);
}

