#include "databasehelper.h"
#include <QSqlDatabase>
#include <QMessageBox>
#include <QSqlError>
#include "mainwindow.h"
#include <QList>
#include <QObject>
#include "util.h"
#include <QMap>
#include <QSet>
#include <QDebug>
#include <QFile>
#include <QFileDialog>

const QString DataBaseHelper::PROJECTS_TABLE = "Project";
const QString DataBaseHelper::TASKS_TABLE = "Task";
const QString DataBaseHelper::TEAMS_TABLE = "Team";
const QString DataBaseHelper::TASK_TEAM_TABLE = "TaskTeam";
const QString DataBaseHelper::PROJECT_ID = "id";
const QString DataBaseHelper::PROJECT_NAME = "Name";
const QString DataBaseHelper::TASK_ID = "id";
const QString DataBaseHelper::TASK_NAME = "Name";
const QString DataBaseHelper::TEAM_ID = "id";
const QString DataBaseHelper::TEAM_NAME = "Name";
const QString DataBaseHelper::DEFAULT_DATABASE = "taskSchedulerDb.sqlite";
const QString DataBaseHelper::NEW_DATABASE = "db.sqlite_new";


QString DataBaseHelper::getDatabaseName() const
{
    return databaseName;
}

DataBaseHelper::DataBaseHelper()
{
    databaseName = tempDbName = "";
}

void DataBaseHelper::createDatabase()
{
    QFile::copy(DEFAULT_DATABASE,NEW_DATABASE);
    openDatabase(NEW_DATABASE);
}

bool DataBaseHelper::openDatabase(QString dbName)
{
    tempDbName = dbName + "_tmp";
    QFile::copy(dbName,tempDbName);

    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(tempDbName);
    db.setHostName("localhost");

    if (!db.open()){
        QMessageBox::warning( 0 ,QObject::tr("Ошибка!"), QObject::tr("Не удалось открыть базу данных!"));
        qDebug()<<db.lastError().databaseText();
        return false;
    }

    databaseName = dbName;
    return true;
}

void DataBaseHelper::saveDatabase()
{
    if (databaseName == NEW_DATABASE){
        QString filename = QFileDialog::
                    getSaveFileName(0,QString(QObject::tr("Сохранить файл")),"C:/Users/",QObject::tr("База данных sqlite (*.db *.sqlite)"));
        databaseName = filename;
    }
    QFile::copy(tempDbName, databaseName);
}

void DataBaseHelper::closeDatabase()
{
    db.close();
}

QSqlDatabase* DataBaseHelper::getDB()
{
    return &db;
}

void DataBaseHelper::initModels(QObject *parent)
{
    this->parent = parent;
    projectsModel = new QSqlTableModel(parent,db);
    projectsModel->setTable(PROJECTS_TABLE) ;
    projectsModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
    projectsModel->select();
    if (projectsModel->rowCount() == 0){
        projectsModel->insertRows(0,1);
        projectsModel->submitAll();
        projectsModel->setData(projectsModel->index(0,1),QObject::tr("Вне проектов"));
        projectsModel->submitAll();
        projectsModel->select();
    }

    tasksModel = new QSqlRelationalTableModel(parent,db);
    tasksModel->setTable(TASKS_TABLE);
    tasksModel->setRelation(2, QSqlRelation(PROJECTS_TABLE, PROJECT_ID, PROJECT_NAME));
    tasksModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
    tasksModel->select();

    teamsModel = new QSqlTableModel(parent,db);
    teamsModel->setTable(TEAMS_TABLE);
    teamsModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
    teamsModel->select();

    teamsTasksModel = new QSqlTableModel(parent,db);
    teamsTasksModel->setTable(TASK_TEAM_TABLE);
    teamsTasksModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
    teamsTasksModel->select();
}

void DataBaseHelper::selectModels()
{
    projectsModel->select();
    tasksModel->select();
    teamsModel->select();
    teamsTasksModel->select();
}

QSqlTableModel *DataBaseHelper::getProjectsModel()
{
    return projectsModel;
}

QSqlRelationalTableModel *DataBaseHelper::getTasksModel()
{
    return tasksModel;
}

QSqlTableModel *DataBaseHelper::getRegularTasksModel()
{
    QSqlTableModel *model = new QSqlTableModel(parent,db);
    model->setTable(TASKS_TABLE);
    model->setEditStrategy(QSqlTableModel::OnManualSubmit);
    model->select();
    return model;
}

QSqlTableModel *DataBaseHelper::getTeamsModel()
{
    return teamsModel;
}

QSqlTableModel *DataBaseHelper::getTeamsTasksModel()
{
    return teamsTasksModel;
}

QSqlRelationalTableModel *DataBaseHelper::getRelTeamsTasksModel()
{
    QSqlRelationalTableModel *model = new QSqlRelationalTableModel(parent,db);
    model->setTable(TASK_TEAM_TABLE);
    model->setRelation(1, QSqlRelation(TASKS_TABLE, TASK_ID, TASK_NAME));
    model->setRelation(2, QSqlRelation(TEAMS_TABLE, TEAM_ID, TEAM_NAME));
    model->setEditStrategy(QSqlTableModel::OnManualSubmit);
    model->select();
    return model;
}

void DataBaseHelper::updateModel()
{
    MainWindow* w =(MainWindow*)parent;
    w->updateModel();
}

void DataBaseHelper::removeTask(int id)
{
    removeTeamTask(id);
    QSqlTableModel* tasks = getRegularTasksModel();
    int rows = tasks->rowCount();
    for (int i=0; i<rows; i++){
        int thisId = tasks->data(tasks->index(i,0)).toInt();
        if (thisId == id){
            tasks->removeRow(i);
            tasks->submitAll();
            break;
        }
    }
}

void DataBaseHelper::removeProject(int id)
{
    QSqlTableModel* tasks = getRegularTasksModel();
    int rows = tasks->rowCount();
    for (int i=0; i<rows; i++){
        int projectId = tasks->data(tasks->index(i,2)).toInt();
        if (projectId == id){
            tasks->removeRow(i);
        }
    }
    tasks->submitAll();

    QSqlTableModel* projects = getProjectsModel();
    rows = projects->rowCount();
    for (int i=0; i<rows; i++){
        int thisId = projects->data(projects->index(i,0)).toInt();
        if (thisId == id){
            projects->removeRow(i);
            projects->submitAll();
            break;
        }
    }
}

void DataBaseHelper::removeTeamTask(int taskId)
{
    QSqlTableModel* tt = getTeamsTasksModel();
    int rows = tt->rowCount();
    for (int i=0; i<rows; i++){
        int id = tt->data(tt->index(i,1)).toInt();
        if (id == taskId){
            tt->removeRow(i);
        }
    }
    tt->submitAll();
}

struct Task {
    int row;
    QDate beginDate;
    int duration;
    QSet<int> teams;
};
void DataBaseHelper::reorderTasks(QList<int> &tasksRows, QDate beginTime, QDate endTime)
{

    QMap<int, Task*> tasks;//задания, упорядоченные по приоритету
    QMap<int, int> teamAvailableTime;//времена доступности
    QList<Task*> reordered;//упорядоченные бригады
    for (int i=0; i<tasksRows.size(); i++){
        Task* task = new Task();
        task->row = tasksRows.at(i);
        task->duration = tasksModel->data(tasksModel->index(task->row,6)).toInt();
        int taskId = tasksModel->data(tasksModel->index(task->row,0)).toInt();
        for (int i=0; i<teamsTasksModel->rowCount(); i++){
            if (teamsTasksModel->data(teamsTasksModel->index(i,1)).toInt() == taskId){
                int teamId = teamsTasksModel->data(teamsTasksModel->index(i,2)).toInt();
                teamAvailableTime.insert(teamId, 0);
                task->teams.insert(teamId);
            }
        }
        int prio = 4 - tasksModel->data(tasksModel->index(task->row,4)).toInt();
        tasks.insertMulti(prio, task);
    }

    int prio;
    int workTime = 0;
    QMap<int, Task*>::iterator it;
    while (1){
        it = tasks.begin();
        prio = it.key();
        //ищем задачу с наименьшим числом бригад среди задач с наивысшим приоритетом
        Task* t = it.value();
        int minBrigades = t->teams.size();
        QMap<int, Task*>::iterator minIt = it;
        for (++it; it != tasks.end(); ++it){
            if (it.key() != prio)
                break;
            t = it.value();
            if (t->teams.size() < minBrigades){
                minBrigades = t->teams.size();
                minIt = it;
            }
        }
        //извлекаем задачу из списка
        t = minIt.value();
        tasks.erase(minIt);
        //определяем время начала выполнения задачи
        int timeBegin = 0;
        for (QSet<int>::iterator j = t->teams.begin(); j!=t->teams.end(); ++j)
            if (teamAvailableTime[*j] > timeBegin)
                timeBegin = teamAvailableTime[*j];
        //устанавливаем это время для задачи
        t->beginDate = beginTime.addDays(timeBegin);
        //устанавливаем время доступности участвующих бригад
        int availableTime = timeBegin + t->duration;
        if (availableTime > workTime)
            workTime = availableTime;
        for (QSet<int>::iterator j = t->teams.begin(); j!=t->teams.end(); ++j)
            teamAvailableTime[*j] = availableTime;
        //добавляем задачу в список обработанных
        reordered<<t;
        if (tasks.empty())
            break;
    }
    int deltaTime = beginTime.daysTo(endTime);
    if (workTime > deltaTime){
        if (!Util::accept(QObject::tr("Время выполнения проекта, полученное при авто-планировании "
                             " задач превышает указанное вами время.\nПрименить авто-планирование "
                             "в любом случае?\n (Вы можете нажать 'Да' и отредактировать график"
                             " позднее, или нажать 'Нет', скорректировать график и попробовать "
                             "авто-планирование снова.)")))
            return;
    }
    for (int i=0; i <reordered.size(); i++ ){
        Task* t = reordered.at(i);
        tasksModel->setData(tasksModel->index(t->row,5),t->beginDate);
    }
    tasksModel->submitAll();
}

void DataBaseHelper::reorderProjectTasks(int id)
{
    QList<int> projectRows;
    QSqlTableModel* tasks = getRegularTasksModel();
    for (int i=0; i<tasks->rowCount(); i++)
        if (tasks->data(tasks->index(i,2)).toInt() == id)
            projectRows<<i;
    reorderTasks(projectRows,getProjectData(id,Project_Begin).toDate(), getProjectData(id,Project_End).toDate());
}

int DataBaseHelper::getDefaultProjectId()
{
    for (int i=0; i<projectsModel->rowCount(); i++)
        if (projectsModel->data(projectsModel->index(i,1)).toString() == QObject::tr("Вне проектов"))
            return projectsModel->data(projectsModel->index(i,0)).toInt();
    return 0;
}

QVariant DataBaseHelper::getTaskData(int id, TaskData field)
{
    QSqlTableModel* model = getRegularTasksModel();
    for (int i=0; i<model->rowCount(); i++)
    {
        if (model->data(model->index(i,0)).toInt() == id)
            return model->data(model->index(i,field));
    }
    return QVariant();
}

QVariant DataBaseHelper::getProjectData(int id, ProjectData field)
{
    for (int i=0; i<projectsModel->rowCount(); i++)
    {
        if (projectsModel->data(projectsModel->index(i,0)).toInt() == id)
            return projectsModel->data(projectsModel->index(i,field));
    }
    return QVariant();
}

TaskStatus DataBaseHelper::getTaskStatus(int id)
{
    int row=-1;
    for (int i=0; i<tasksModel->rowCount(); i++){
        if (tasksModel->data(tasksModel->index(i,0)).toInt() == id){
            row = i;
            break;
        }
    }
    return getTaskStatusByRow(row);
}

TaskStatus DataBaseHelper::getTaskStatusByRow(int row)
{
    QDate begin = tasksModel->data(tasksModel->index(row,5)).toDate();
    if (begin > QDate::currentDate())
        return Planned;
    int progress = tasksModel->data(tasksModel->index(row,7)).toInt();
    if (progress >= 100)
        return Completed;
    float deltaTime = begin.daysTo(QDate::currentDate());
    int expectedProgress = deltaTime / (float)(tasksModel->data(tasksModel->index(row,6)).toInt()) * 100;
    if (progress - expectedProgress >= 0)
        return Actual;
    return Late;
}

QStandardItemModel *DataBaseHelper::getTeamsCheckList(int taskId)
{
    int teams =  teamsModel->rowCount();
    QStandardItemModel* model = new QStandardItemModel(teams,1);
    int tt = teamsTasksModel->rowCount();
    for (int i=0; i<teams; i++){
        QStandardItem* item = new QStandardItem();
        item->setData(teamsModel->data(teamsModel->index(i,1)),
                      Qt::DisplayRole);
        int teamId = teamsModel->data(teamsModel->index(i,0)).toInt();
        item->setData(teamId);
        item->setCheckable(true);
        item->setCheckState(Qt::Unchecked);
        if (taskId != -1){
            for (int j=0; j<tt; j++){
                int idTask = teamsTasksModel->data(teamsTasksModel->index(j, 1)).toInt();
                int idTeam = teamsTasksModel->data(teamsTasksModel->index(j, 2)).toInt();
                if (idTask == taskId && idTeam == teamId){
                    item->setCheckState(Qt::Checked);
                    break;
                }
            }
        }
        model->setItem(i,0,item);
    }
    return model;
}

QStandardItemModel *DataBaseHelper::getTasksCheckList(int projectId)
{

    int tasks =  tasksModel->rowCount();
    QSqlTableModel* modelTasks = getRegularTasksModel();
    modelTasks->select();

    QStandardItemModel* model = new QStandardItemModel(tasks,1);
    for (int i=0; i<tasks; i++){
        QStandardItem* item = new QStandardItem();
        item->setData(modelTasks->data(modelTasks->index(i,1)),
                      Qt::DisplayRole);
        int taskId = modelTasks->data(modelTasks->index(i,0)).toInt();
        item->setData(taskId);
        item->setCheckable(true);
        item->setCheckState(Qt::Unchecked);

        if (projectId != -1){
            int projId = modelTasks->data(modelTasks->index(i,2)).toInt();
            if (projId == projectId)
                item->setCheckState(Qt::Checked);
        }

        model->setItem(i,0,item);
    }
    return model;
}

QStandardItemModel *DataBaseHelper::getTaskTeamsForProject(int projectId)
{
    QStandardItemModel* model = new QStandardItemModel();
    QMap<QString,QStandardItem*> teamsMap;
    QSet<QString> tasksOfProject;
    QSqlTableModel* modelTasks = getRegularTasksModel();
    QSqlRelationalTableModel* modelTeamsTasks = getRelTeamsTasksModel();
    for (int i=0; i<modelTasks->rowCount(); i++){
        if (modelTasks->data(modelTasks->index(i,2)).toInt() == projectId){
            tasksOfProject.insert(modelTasks->data(modelTasks->index(i,1)).toString());
        }
    }
    for (int i=0; i<modelTeamsTasks->rowCount(); i++){
        QString task = modelTeamsTasks->data(modelTeamsTasks->index(i,1)).toString();
        if (tasksOfProject.contains(task)){
            QString team = modelTeamsTasks->data(modelTeamsTasks->index(i,2)).toString();
            if (!teamsMap.contains(team)){
                teamsMap.insert(team,new QStandardItem(team));
            }
            teamsMap[team]->appendRow(new QStandardItem(task));
        }
    }
    for (QMap<QString, QStandardItem*>::iterator it = teamsMap.begin(); it!=teamsMap.end(); ++it){
        model->appendRow(it.value());
    }
    return model;
}
