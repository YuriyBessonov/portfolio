#include "customdatetimegrid.h"
#define d d_func()

const int CustomDateTimeGrid::DEFAULT_SCALE = 1;
const int  CustomDateTimeGrid::SCALE_RANGE = 6;
const GridScale CustomDateTimeGrid::scalesArr[] =
    {/*0*/{80, KDGantt::DateTimeScaleFormatter::Day, "dd MMM, ddd",     KDGantt::DateTimeScaleFormatter::Week, "MMMM yyyy"},
     /*1*/{55, KDGantt::DateTimeScaleFormatter::Day, "dd, ddd",              KDGantt::DateTimeScaleFormatter::Week, "dd MMM, ddd"},
     /*2*/{40, KDGantt::DateTimeScaleFormatter::Day, "dd",             KDGantt::DateTimeScaleFormatter::Week, "dd MMM, ddd"},
     /*3*/{20, KDGantt::DateTimeScaleFormatter::Week, "dd",             KDGantt::DateTimeScaleFormatter::Month, "MMMM yyyy"},
     /*4*/{11, KDGantt::DateTimeScaleFormatter::Week, "dd",             KDGantt::DateTimeScaleFormatter::Month, "MMMM yyyy"},
     /*5*/{2, KDGantt::DateTimeScaleFormatter::Month, "MMMM",             KDGantt::DateTimeScaleFormatter::Year, "yyyy"} };

void CustomDateTimeGrid::drawBackground(QPainter* paint, const QRectF& rect)
{
   int offset = (int)dayWidth();
  // Figure out the date at the extreme left
  QDate date = mapToDateTime(rect.left()).date();
  int daysToToday = date.daysTo(QDate::currentDate());

  // We need to paint from one end to the other
  int startx = rect.left();
  int endx = rect.right();

  // Save the painter state
  paint->save();

  // Paint the first date column
  while (1)
  {
      QDate nextDate = mapToDateTime(startx+1).date();

      if (date != nextDate)
      {
          QRectF dayRect(startx-dayWidth(), rect.top(), dayWidth(), rect.height());
          dayRect = dayRect.adjusted(1, 0, 0, 0);

          drawDayBackground(paint, dayRect, date);
          break;
      }

      ++startx;
  }

  // Paint the remaining dates
  for (int i=startx; i<endx; i+=offset)
  {
      date = mapToDateTime(i+1).date();
      QRectF dayRect(i, rect.top(), dayWidth(), rect.height());
      dayRect = dayRect.adjusted(1, 0, 0, 0);
      drawDayBackground(paint, dayRect, date);
      //paint->fillRect(dayRect, QBrush(QColor(238,255,246)));
  }

  // Restore the painter state
  paint->restore();

}

bool CustomDateTimeGrid::zoomOut()
{
    if (currentScale < SCALE_RANGE - 1){
        currentScale++;
        updateScale();
        return (currentScale !=  currentScale-1);
    }
    return false;
}

bool CustomDateTimeGrid::zoomIn()
{
    if (currentScale > 0){
        currentScale--;
        updateScale();
        return (currentScale != 0);
    }
    return false;
}

void CustomDateTimeGrid::useDefaultScale()
{
    currentScale = DEFAULT_SCALE;
    updateScale();
}

void CustomDateTimeGrid::updateScale()
{
    setUserDefinedUpperScale( new KDGantt::DateTimeScaleFormatter(scalesArr[currentScale].highRange,
                                                                  scalesArr[currentScale].highFormat) );
    setUserDefinedLowerScale( new KDGantt::DateTimeScaleFormatter(scalesArr[currentScale].lowRange,
                                                                  scalesArr[currentScale].lowFormat) );
    setDayWidth( scalesArr[currentScale].dayWidth );
}


void CustomDateTimeGrid::paintUserDefinedHeader( QPainter* painter, const QRectF& headerRect, const QRectF& exposedRect, qreal offset, const KDGantt::DateTimeScaleFormatter* formatter, QWidget* widget)
{
    const QStyle* const style = widget ? widget->style() : QApplication::style();

    QDateTime dt = formatter->currentRangeBegin( mapToDateTime( offset + exposedRect.left() ) ).toUTC();
    qreal x = mapFromDateTime( dt );

    while ( x < exposedRect.right() + offset ) {
        const QDateTime next = formatter->nextRangeBegin( dt );
        const qreal nextx = mapFromDateTime( next );

        QStyleOptionHeader opt;
        if ( widget ) opt.init( widget );
        opt.rect = QRectF( x - offset+1, headerRect.top(), qMax( 1., nextx-x-1 ), headerRect.height() ).toAlignedRect();
        //opt.state = QStyle::State_Raised | QStyle::State_Enabled;
        opt.textAlignment = formatter->alignment();
        KDGantt::DateTimeScaleFormatter* myFormatter = new KDGantt::DateTimeScaleFormatter(*formatter);
        if (myFormatter->range() == KDGantt::DateTimeScaleFormatter::Week){
            if (currentScale == 4)
            opt.text = dt.toString("dd.MM") + " - " + dt.addDays(6).toString("dd.MM");
            else opt.text = dt.toString("dd.MM.yyyy") + " - " + dt.addDays(6).toString("dd.MM.yyyy");
        }
        else opt.text = formatter->text( dt );

        // use white text on black background
        opt.palette.setColor(QPalette::Window, QColor("black"));
        opt.palette.setColor(QPalette::ButtonText, QColor("black"));

        style->drawControl( QStyle::CE_Header, &opt, painter, widget );

        dt = next;
        x = nextx;
    }
}

