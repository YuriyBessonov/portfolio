#include "custompiechart.h"
#include <QColor>
CustomPieChart::CustomPieChart(QWidget* parent)
    : QWidget(parent)
  {
       m_model.insertRows( 0, 1, QModelIndex() );

        PolarCoordinatePlane* polarPlane = new PolarCoordinatePlane( &m_chart );
        m_chart.replaceCoordinatePlane( polarPlane );
        diagram = new PieDiagram;
        diagram->setModel(&m_model);
}

CustomPieChart* CustomPieChart::addData(QString name, int value)
{
    QList<QStandardItem*> items;
    QStandardItem* item = new QStandardItem();
    item->setData(QVariant(value),Qt::EditRole);
    item->setData(QVariant(name),Qt::ToolTipRole);
    items<<item;
    m_model.appendColumn(items);
    return this;
}

void CustomPieChart::chartSetup()
{
    diagram->setModel(&m_model);
    const QFont font(QFont( "Comic", 10 ));
    const int colCount = diagram->model()->columnCount();
    for ( int iColumn = 0; iColumn<colCount; ++iColumn ) {
        DataValueAttributes dva( diagram->dataValueAttributes( iColumn ) );
        TextAttributes ta( dva.textAttributes() );
        ta.setRotation( 0 );
        ta.setFont( font );
        ta.setPen( QPen( Qt::black) );
        ta.setVisible( true );
        dva.setTextAttributes( ta );

        RelativePosition posPos( dva.positivePosition() );
        posPos.setReferencePosition( KDChart::Position::North );
        posPos.setAlignment( Qt::AlignCenter );
        posPos.setHorizontalPadding( KDChart::Measure(0.0) );
        posPos.setVerticalPadding( KDChart::Measure(-1000.0) );
        dva.setPositivePosition( posPos );
        dva.setVisible( true );
        diagram->setDataValueAttributes( iColumn, dva);
    }

    //настройка легенды
    Legend* legend = new Legend( diagram, &m_chart );
    legend->setPosition( Position::East );
    legend->setAlignment( Qt::AlignCenter );
    legend->setShowLines( false );
    legend->setSpacing( 1 );
    legend->setOrientation( Qt::Vertical);
    legend->setMaximumHeight(300);
    m_chart.addLegend(legend);


    // Configure the items markers
    MarkerAttributes lma ( legend->markerAttributes( 0 ) );
    lma.setMarkerStyle( MarkerAttributes::MarkerDiamond );
    for (int i=0; i<m_model.columnCount(); i++)
        legend->setMarkerAttributes( i,  lma );

    // Configure Legend Title and labels
    for (int i=0; i<m_model.columnCount(); i++){
        QModelIndex index = m_model.index(0, i, QModelIndex());
        legend->setText(i, m_model.data(index,Qt::ToolTipRole).toString());
    }

    // adjust the legend item's font:
    TextAttributes lta( legend->textAttributes() );
    lta.setPen( QPen( Qt::darkGray ) );
    Measure me( lta.fontSize() );
    me.setValue( me.value() * 1.5 );
    lta.setFontSize( Measure( 8, KDChartEnums::MeasureCalculationModeAbsolute ) );
    legend->setTextAttributes(  lta );

    // adjust the legend title's font:
    lta = legend->titleTextAttributes();
    lta.setVisible(false);
    legend->setTitleTextAttributes(  lta );

    QPen markerPen;
    markerPen.setColor(  Qt::darkGray );
    markerPen.setWidth( 2 );

    // Add a background to your legend
    BackgroundAttributes ba;
    ba.setBrush(  Qt::white );
    ba.setVisible( true );
    legend->setBackgroundAttributes(  ba );

    FrameAttributes fa;
    fa.setPen( markerPen );
    fa.setVisible( true );
    legend->setFrameAttributes(  fa );

    m_chart.coordinatePlane()->replaceDiagram(diagram);
    m_chart.legend()->adjustSize();
    QVBoxLayout* l = new QVBoxLayout(this);
    l->addWidget(&m_chart);
    setLayout(l);
}

void CustomPieChart::setSectorColors(QList<QColor> colors)
{
    QBrush sectionBrush;
    sectionBrush.setStyle(Qt::SolidPattern);
    for (int i=0; i<colors.size(); i++){
        sectionBrush.setColor(colors.at(i));
        diagram->setBrush(i,sectionBrush);
    }
}

