#ifndef CUSTOMDATETIMEGRID_H
#define CUSTOMDATETIMEGRID_H

#include <KDGanttGlobal>
#include <KDGanttView>
#include <KDGanttItemDelegate>
#include <KDGanttDateTimeGrid>
#include <KDGanttStyleOptionGanttItem>
#include <KDGanttConstraintModel>
#include <KDGanttGraphicsView>
#include <QApplication>
#include <KDGanttDateTimeScaleFormatter>

struct GridScale {
    int dayWidth;
    KDGantt::DateTimeScaleFormatter::Range lowRange;
    QString lowFormat;
    KDGantt::DateTimeScaleFormatter::Range highRange;
    QString highFormat;

};
class CustomDateTimeGrid : public KDGantt::DateTimeGrid
{
public:
    CustomDateTimeGrid(QObject* parent=0)
    {
        setParent(parent);
        setWeekStart(Qt::Monday);
        setScale(KDGantt::DateTimeGrid::ScaleUserDefined);
        useDefaultScale();
    }
    ~CustomDateTimeGrid() { }
    virtual void drawBackground(QPainter* painter, const QRectF& rect);
    virtual void paintUserDefinedHeader( QPainter* painter, const QRectF& headerRect,
                                                     const QRectF& exposedRect, qreal offset,
                                                     const KDGantt::DateTimeScaleFormatter* formatter, QWidget* widget);
    bool zoomIn();
    bool zoomOut();
    void useDefaultScale();
    QColor bgColor;
    QColor weekendBgColor;
    QColor todayBgColor;
private:
    static const int SCALE_RANGE;
    static const GridScale scalesArr[];
    static const int DEFAULT_SCALE;
    int currentScale;
    void updateScale();

};

#endif // CUSTOMDATETIMEGRID_H
