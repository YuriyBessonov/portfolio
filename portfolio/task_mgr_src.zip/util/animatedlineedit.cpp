#include "animatedlineedit.h"
