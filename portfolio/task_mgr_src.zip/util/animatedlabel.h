#ifndef ANIMATEDLABEL_H
#define ANIMATEDLABEL_H
#include <QPropertyAnimation>
#include <QLineEdit>
#include <QColor>

class AnimatedLineEdit : public QLineEdit
{

  Q_OBJECT
  Q_PROPERTY(QColor color READ color WRITE setColor)

public:
  AnimatedLineEdit(QWidget *parent = 0)
  {
  }
  void setColor (QColor color){
    setStyleSheet(QString("background-color: rgb(%1, %2, %3);").arg(color.red()).arg(color.green()).arg(color.blue()));
  }
  QColor color(){
    return Qt::black;
  }
  void highlightError(){
      QPropertyAnimation *animation = new QPropertyAnimation(this, "color");
      animation->setDuration(2000);
      animation->setStartValue(QColor(255, 255, 255));
      animation->setEndValue(QColor(200, 0, 0));
      animation->start();
  }
};

#endif // ANIMATED
