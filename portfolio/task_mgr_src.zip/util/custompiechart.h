#ifndef CUSTOMPIECHART_H
#define CUSTOMPIECHART_H

#include <KDChartChart>
#include <KDChartPieDiagram>
#include <KDChartDataValueAttributes>
#include <KDChartBackgroundAttributes>
#include <KDChartPieAttributes>
#include <KDChartPosition>
#include <QStandardItemModel>
#include <KDChartLegend>
#include <KDChartFrameAttributes>

using namespace KDChart;

class CustomPieChart : public QWidget {
  Q_OBJECT
public:
  explicit CustomPieChart(QWidget* parent=0);
    CustomPieChart *addData(QString name, int value);
    void chartSetup();
    void setSectorColors(QList<QColor> colors);
private:
  Chart m_chart;
  QStandardItemModel m_model;
  PieDiagram* diagram;
};

#endif // CUSTOMPIECHART_H
