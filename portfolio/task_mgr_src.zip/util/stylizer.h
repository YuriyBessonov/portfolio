#ifndef STYLIZER_H
#define STYLIZER_H
#include <QColor>

class Stylizer
{
    QString colorPrimary;
    QString colorPrimaryLight;
    QString colorSecondary;
    QString colorSecondaryLight;
    QString colorBorder;
    QString colorText;
    QString colorExtra;
    QString styleSheet;
public:
    Stylizer(QString filename);
    void setColorScheme(QString file);
    void prepareStyle();
};

#endif // STYLIZER_H
