#include "progresswidget.h"
#include "ui_progresswidget.h"

ProgressWidget::ProgressWidget(QWidget *parent):
    QWidget(parent),
    ui(new Ui::ProgressWidget)
{

}

ProgressWidget::ProgressWidget(QString name, int actualProgress, int expectedProgress, QWidget *parent ):
    QWidget(parent),
    ui(new Ui::ProgressWidget)
{
    ui->setupUi(this);
    ui->taskName->setText(name);
    ui->actualProgressBar->setValue(actualProgress);
    ui->expectedProgressBar->setValue(expectedProgress);
}

ProgressWidget::~ProgressWidget()
{
    delete ui;
}
