#ifndef UTIL_H
#define UTIL_H
#include <QString>
#include <QMessageBox>
#include <QObject>
#include <QWidget>
#include <QDebug>
class Util
{
public:
    Util();
    static bool accept(const QString& msg,QWidget* parent = 0){
        int r = QMessageBox::warning(parent,
                                     QObject::tr("Предупреждение"),
                                     msg,
                                     QObject::tr("Да"),
                                     QObject::tr("Нет"),
                                     QString(),
                                     0,
                                     1
                                    );
        return !r;
    }
    static int choice(const QString& msg, QWidget* parent = 0){
        int ret = QMessageBox::warning(parent, QObject::tr("Предупреждение"),
                                       msg,
                                       QMessageBox::Yes | QMessageBox::No
                                       | QMessageBox::Cancel,
                                       QMessageBox::Yes);
        return ret;
    }
};

#endif // UTIL_H
