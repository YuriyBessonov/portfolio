#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include <KDChartWidget>
#include <QItemSelection>
#include <QTreeView>
#include <QTableView>
#include <QSqlRelationalTableModel>
#include "databasehelper.h"
#include "standardtreemodel.h"
#include "standardtablemodel.h"
#include "taskssortfilterproxymodel.h"
#include "customdatetimegrid.h"
#include <QSettings>


QT_BEGIN_NAMESPACE
class QStandardItemModel;
class QCloseEvent;
namespace Ui {
    class MainWindow;
}
QT_END_NAMESPACE

namespace KDGantt {
    class ConstraintModel;
    class DateTimeGrid;
    class Legend;
}

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(DataBaseHelper dbHelper, QWidget *parent = 0,  Qt::WindowFlags flags = 0 );
    virtual ~MainWindow();
    virtual void closeEvent(QCloseEvent *event);
public slots:
    void open();
    void save();
    void create();
private slots:
    void showTreeContextMenu( const QPoint& );
    void showTableContextMenu(const QPoint& pos);
    void enableActions( const QItemSelection& selected );
    void zoomIn();
    void zoomOut();

    void on_addProjectPb_clicked();
    void on_addTaskPb_clicked();
    void on_projectSummary_clicked();
    void on_manageTeamsPb_clicked();
    void on_graphViewRb_toggled(bool checked);
    void on_pushButton_clicked();
    void editItem();
    void removeItem();
    void on_editPb_clicked();
    void on_removePb_clicked();
    void showHelp();
public:
    void updateModel();
private:
    void initModel();
    void initActions();
    void initSortActions();
    void initItemDelegate();
    void initGrid();
    void initTreeView();
    void initTableView();
    void offerAutoSchedule(int projectId,  Change change, int oldProjectId=0);
    void applyStyle(int styleNo, bool hover = true);
    QModelIndex getSelectedIndex();

    QTreeView* ganttTreeView;
    QTableView* tasksTableView;
    StandardTreeModel* treeModel;
    StandardTableModel* tableModel;
    TasksSortFilterProxyModel* proxyModel;
    CustomDateTimeGrid* grid;

    QAction* addProjectAction;
    QAction* addTaskAction;
    QAction* removeAction;
    QAction* zoomInAction;
    QAction* zoomOutAction;
    QAction* filterActualAction;
    QAction* filterComplAction;
    QAction* filterLateAction;
    QAction* filterPlannedAction;
    QAction* color1;
    QAction* color2;
    QAction* color3;
    QAction* color4;

    QSqlRelationalTableModel* sqlModel;
    DataBaseHelper* dbHelper;
    Ui::MainWindow *ui;
    QLabel* currentDateLbl;

    QSettings colorSettings;
    int selectedProjectId;
private slots:
    void sortNone(bool st);
    void sortProgress(bool st);
    void sortPrio(bool st);
    void sortBegin(bool st);
    void sortEnd(bool st);
    void sortAsc(bool st);
    void sortDesc(bool st);
    void filterCompl(bool st);
    void filterActual(bool st);
    void filterLate(bool st);
    void filterPlanned(bool st);
    void filterAll(bool st);
    void on_groupByProjectsCb_toggled(bool checked);
    void on_toggleEditCb_toggled(bool checked);
    void changeStyle();
    void col1Hovered();
    void col2Hovered();
    void col3Hovered();
    void col4Hovered();
};

#endif // MAINWINDOW_H
