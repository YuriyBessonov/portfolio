#include "summarywindow.h"
#include "ui_summarywindow.h"
#include <QSqlTableModel>
#include <QDate>
#include <QProgressBar>
#include "progresswidget.h"
#include <QDebug>
#include <KDChartWidget>
#include <KDChartPieDiagram>
#include <KDChartPolarCoordinatePlane>
#include <QPen>
#include "custompiechart.h"
using namespace KDChart;

SummaryWindow::SummaryWindow(int projectId, DataBaseHelper* dbHelper, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SummaryWindow)
{
    ui->setupUi(this);
    this->dbHelper= dbHelper;

    projects = dbHelper->getProjectsModel();
    row = 0;
    id = projectId;
    for (int i=0; i<projects->rowCount(); i++){
        int pId = projects->data(projects->index(i,0)).toInt();
        if (pId == projectId){
            row = i;
            break;
        }
    }
    ui->projectNameLbl->setText(projects->data(projects->index(row,1)).toString());
    QDate begin = projects->data(projects->index(row,3)).toDate();
    QDate end = projects->data(projects->index(row,4)).toDate();
    if (QDate::currentDate() > end){
        ui->statusLbl->setText(tr("(Проект сдан)"));
    }
    else if (QDate::currentDate() < begin){
        ui->statusLbl->setText(tr("(Проект не начат)"));
    }
    else {
        QString str = tr("(Сегодня ") +
                QString("%1").arg(begin.daysTo(QDate::currentDate())+1)+
                tr("-й день из ") + QString("%1").arg(begin.daysTo(end)) +")";
        ui->statusLbl->setText(str);
    }
    ui->datesLbl->setText(begin.toString("dd.MM.yyyy")+" - "+end.toString("dd.MM.yyyy"));
    QPixmap pixmap = QPixmap();
    pixmap.loadFromData(projects->data(projects->index(row,2)).toByteArray());
    ui->projectImageLbl->setPixmap(pixmap);

    ui->teamsTv->setModel(dbHelper->getTaskTeamsForProject(id));
    ui->teamsTv->model()->setHeaderData(0,Qt::Horizontal,tr("Бригады и их задачи"));
    setupTasksProgress();
    setupPieCharts();

}

SummaryWindow::~SummaryWindow()
{
    delete ui;
}

void SummaryWindow::setupTasksProgress()
{
    QSqlTableModel* tasksModel = dbHelper->getRegularTasksModel();
    for (int i=0; i<tasksModel->rowCount(); i++){
        if (tasksModel->data(tasksModel->index(i,2)).toInt() == id){
            int progress = tasksModel->data(tasksModel->index(i,7)).toInt();
            int expected = 0;
            QDate begin = tasksModel->data(tasksModel->index(i,5)).toDate();
            QDate end = begin.addDays(tasksModel->data(tasksModel->index(i,6)).toInt());
            if (QDate::currentDate() > end){
                expected = 100;
            }
            else if (QDate::currentDate() > begin){
                float daysPassed = begin.daysTo(QDate::currentDate());
                float daysTotal = begin.daysTo(end);
                expected = (daysPassed/daysTotal)*100;
            }
            ProgressWidget* pw = new ProgressWidget(tasksModel->data(tasksModel->index(i,1)).toString(),
                                                    progress, expected);
            ui->progressTiles->layout()->addWidget(pw);
        }
    }
}

void SummaryWindow::setupPieCharts()
{
    QList<int> tasksRows;
    QSqlTableModel* tasks = dbHelper->getRegularTasksModel();
    for (int i=0; i<tasks->rowCount(); i++){
        if (tasks->data(tasks->index(i, 2)).toInt() == id)
            tasksRows<<i;
    }
    QLabel* label = new QLabel(tr("<b>Общий прогресс проекта (%)</b>"));
    label->setAlignment(Qt::AlignHCenter);
    ui->pieCharts->layout()->addWidget(label);
    CustomPieChart* totalProgress = new CustomPieChart();
    CustomPieChart* progressChart = new CustomPieChart();
    int currentProgress = 0;
    for (int i=0; i<tasksRows.size(); i++){
        int progress = tasks->data(tasks->index(tasksRows.at(i),7)).toInt();
        QString name = tasks->data(tasks->index(tasksRows.at(i),1)).toString();
        progressChart->addData(name,progress);
        currentProgress+=progress;
    }
    int complete = (float)currentProgress / (float)(tasksRows.size()*100) * 100;
    totalProgress->addData(tr("Выполнено"),complete)
                 ->addData(tr("Не выполнено"),100 - complete);
    totalProgress->setSectorColors(QList<QColor>()<<QColor(6,222,42)<<QColor(160,160,160));
    totalProgress->chartSetup();
    ui->pieCharts->layout()->addWidget(totalProgress);

    label = new QLabel(tr("<b>Соотношение прогресса задач проекта (в %)</b>"));
    label->setAlignment(Qt::AlignHCenter);
    ui->pieCharts->layout()->addWidget(label);
    progressChart->chartSetup();
    ui->pieCharts->layout()->addWidget(progressChart);

    label = new QLabel(tr("<b>Соотношение числа задач проекта по статусу выполнения</b>"));
    label->setAlignment(Qt::AlignHCenter);
    ui->pieCharts->layout()->addWidget(label);
    CustomPieChart* chart = new CustomPieChart();
    int statusCount[4] = {0,0,0,0};
    for (int i=0; i<tasksRows.size(); i++){
        int status = dbHelper->getTaskStatusByRow(tasksRows.at(i));
        statusCount[status]++;
    }
    chart->addData(tr("Запланированные"),statusCount[Planned])
         ->addData(tr("Отстающие от\nграфика"),statusCount[Late])
         ->addData(tr("Следующие графику"),statusCount[Actual])
         ->addData(tr("Завершенные"),statusCount[Completed]);
    chart->setSectorColors(QList<QColor>()<<QColor(58,194,239)<<QColor(200,129,30)<<
                           QColor(194,239,58)<<QColor(38,255,98));
    chart->chartSetup();
    ui->pieCharts->layout()->addWidget(chart);

    label = new QLabel(tr("<b>Соотношение времен выполнения задач проекта (в днях)</b>"));
    label->setAlignment(Qt::AlignHCenter);
    ui->pieCharts->layout()->addWidget(label);
    chart = new CustomPieChart();
    for (int i=0; i<tasksRows.size(); i++){
        int duration = tasks->data(tasks->index(tasksRows.at(i),6)).toInt();
        QString name = tasks->data(tasks->index(tasksRows.at(i),1)).toString();
        chart->addData(name,duration);
    }
    chart->chartSetup();
    ui->pieCharts->layout()->addWidget(chart);

}
