#include "entrydelegate.h"
#include "projectdialog.h"
#include "taskdialog.h"

#include <KDGanttConstraintModel>
#include <KDGanttGlobal>
#include <QEvent>
#include <QModelIndex>
#include <QStandardItemModel>
#include <QPointer>
#include <QSortFilterProxyModel>


EntryDelegate::EntryDelegate(bool tree, DataBaseHelper* dbHelper, QObject* parent )
    : QItemDelegate( parent )
{
    this->dbHelper = dbHelper;
    this->tree = tree;
}

bool EntryDelegate::editorEvent( QEvent* event, QAbstractItemModel *model, const QStyleOptionViewItem& option, const QModelIndex& index )
{
    if ( event->type() != QEvent::MouseButtonDblClick )
        return false;

    if ( !index.isValid() )
        return true;

    int row = index.row();
    const QModelIndex parent = index.parent();

    QPointer<TaskDialog> taskDialog;
    QPointer<ProjectDialog> projectDialog;
    if (tree){
        int type = model->data(model->index(row, 1, parent)).toInt();
        if (type == KDGantt::TypeTask) {
            int id = model->data(model->index(row, 5, parent)).toInt();
            taskDialog = new TaskDialog(dbHelper,id);
            taskDialog->exec();
            if (!taskDialog)
                 return true;
        }
        else if (type == KDGantt::TypeSummary){
            int id = model->data(model->index(row, 5, parent)).toInt();
            projectDialog = new ProjectDialog(dbHelper,id);
            projectDialog->exec();
            if (!projectDialog)
                return true;
        }
        else return true;
        if (type == KDGantt::TypeTask)
            delete taskDialog;
        else if (type == KDGantt::TypeSummary)
            delete projectDialog;
    } else {
      int id = model->data(model->index(index.row(),0,index.parent())).toInt();
      taskDialog = new TaskDialog(dbHelper,id);
      taskDialog->exec();
      if (!taskDialog)
           return true;
      delete taskDialog;
    }

    return true;
}

