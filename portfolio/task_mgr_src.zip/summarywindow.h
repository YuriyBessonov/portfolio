#ifndef SUMMARYWINDOW_H
#define SUMMARYWINDOW_H

#include <QDialog>
#include "databasehelper.h"

namespace Ui {
class SummaryWindow;
}

class SummaryWindow : public QDialog
{
    Q_OBJECT

public:
    explicit SummaryWindow(int projectId,DataBaseHelper* dbHelper, QWidget *parent = 0);
    ~SummaryWindow();

private:
    Ui::SummaryWindow *ui;
    DataBaseHelper* dbHelper;
    QSqlTableModel* projects;
    int id;
    int row;
    void setupTasksProgress();
    void setupPieCharts();
};

#endif // SUMMARYWINDOW_H
