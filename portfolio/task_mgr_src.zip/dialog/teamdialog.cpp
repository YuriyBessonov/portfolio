#include "teamdialog.h"
#include "ui_teamdialog.h"
#include <QPropertyAnimation>
#include <QDebug>
#include "util/util.h"
#include <QSqlError>

TeamDialog::TeamDialog(DataBaseHelper *dbHelper, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::TeamDialog)
{
    ui->setupUi(this);
    this->dbHelper = dbHelper;

    model = dbHelper->getTeamsModel();
    ui->teamsList->setModel(model);
    ui->teamsList->setModelColumn(1);
}

TeamDialog::~TeamDialog()
{
    delete ui;
}

void TeamDialog::on_teamEditPb_clicked()
{
    QModelIndex index = ui->teamsList->currentIndex();
    if ( !index.isValid() )
        return;

    ui->teamsList->edit(index);
}

void TeamDialog::on_teamRemovePb_clicked()
{
    QModelIndex ind = ui->teamsList->currentIndex();
    if ( !ind.isValid() )
        return;

    if (Util::accept(tr("Вы уверены, что хотите удалить запись?"),this)) {
        QItemSelectionModel    *selectModel;
        QModelIndexList         indexes;
        QModelIndex             index;

        selectModel = ui->teamsList->selectionModel();
        indexes = selectModel->selectedIndexes();

        foreach(index, indexes)
        {
            QString str;
            int row = index.row();
            if (!model->removeRows(row,1))
            {
                str = model->lastError().text();
                qDebug() << str << "\n\r";
                break;
            }
            else
            {
                ui->teamsList->setRowHidden(row, true);
            }
            model->submitAll();
        }
    }
}

void TeamDialog::on_teamAddPb_clicked()
{
    if (ui->teamNameLe->text().length() == 0){
        ui->teamNameLe->animateErrorHighlight();
        return;
    }
    int rowCount = model->rowCount(QModelIndex());
    int id = (rowCount == 0) ? 1 :
                      model->data(model->index(rowCount -1,0)).toInt() + 1;
    model->insertRow(rowCount);
    model->setData(model->index(rowCount,1), ui->teamNameLe->text());
    model->setData(model->index(rowCount,0), id);
    ui->teamNameLe->clear();
    model->submitAll();
}

void TeamDialog::on_pushButton_clicked()
{
    close();
}
