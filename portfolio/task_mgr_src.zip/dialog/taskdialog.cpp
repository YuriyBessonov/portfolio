#include "taskdialog.h"
#include "ui_taskdialog.h"
#include "teamdialog.h"
#include <QStringListModel>
#include <QSqlRelationalDelegate>
#include <QDebug>
#include <QSqlError>
#include <QSqlRecord>
#include "mainwindow.h"



TaskDialog::TaskDialog(DataBaseHelper *dbHelper, int id, bool toNew, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::TaskDialog)
{
    this->parent = parent;
    ui->setupUi(this);
    this->dbHelper = dbHelper;
    this->id = id;
    if (id != -1)
        setWindowTitle(tr("Редактировать задачу"));
    this->toNew = toNew;
    added = (id == -1);
    teamsCheckList = dbHelper->getTeamsCheckList(id);
    priorityChanged = false;
    projectChanged = false;

    ui->beginDateDe->setCalendarPopup(true);
    ui->beginDateDe->setDate(QDate::currentDate());
    ui->beginDateDe->setMinimumDate(QDate(1900,1,1));
    ui->workTimeSb->setMaximum(999);
    ui->progressSb->setMaximum(100);

    model = dbHelper->getTasksModel();
    mapper=new QDataWidgetMapper(this);
    mapper->setModel(model);
    mapper->setItemDelegate(new QSqlRelationalDelegate(this) );
    mapper->setSubmitPolicy(QDataWidgetMapper::ManualSubmit);

    mapper->addMapping(ui->taskNameLe,1);
    mapper->addMapping(ui->groupLe,3);
    mapper->addMapping(ui->beginDateDe,5);
    mapper->addMapping(ui->workTimeSb,6);
    mapper->addMapping(ui->progressSb,7);
    mapper->addMapping(ui->projectCb,2);

    model->relationModel(2)->select();
    ui->projectCb->setModel(model->relationModel(2));
    ui->projectCb->setModelColumn(1);

    if (toNew){
       for (int i=0; i<model->relationModel(2)->rowCount(); i++)
           if (model->relationModel(2)->
                   data(model->relationModel(2)->index(i,1)).toString() == tr("Вне проектов")){
               ui->projectCb->setCurrentIndex(i);
               break;
           }
       ui->projectCb->setEnabled(false);
    }

    QStringList priorities;
    priorities<<tr("Незначительный")<<tr("Низкий")<<tr("Обычный")<<tr("Высокий")<<tr("Критически высокий");
    ui->priorityCb->setModel(new QStringListModel(priorities));

   ui->brigadeList->setModel(teamsCheckList);

    if (id == -1){
        int tasksCount = model->rowCount(QModelIndex());
        this->id = (tasksCount == 0) ? 1 :
                        model->data(model->index(tasksCount-1,0)).toInt() + 1;
        model->insertRow(tasksCount);
        model->setData(model->index(tasksCount,0),this->id);
        mapper->toLast();
        ui->priorityCb->setCurrentIndex(2);
        row = tasksCount;
    }
    else{
        oldProjectId = dbHelper->getTaskData(id, Task_ProId).toInt();
        qDebug()<<"old project "<<oldProjectId;
        for (int i=0; i<model->rowCount(); i++ ){
            int taskId = model->data(model->index(i,0)).toInt();
            if (taskId == id){
                row = i;
                break;
            }
        }
        mapper->setCurrentModelIndex(model->index(row,0));
        ui->priorityCb->setCurrentIndex(model->data(model->index(row,4)).toInt());
    }
    oldPrio = ui->priorityCb->currentIndex();
}

TaskDialog::~TaskDialog()
{
    delete ui;
}

void TaskDialog::on_editBrigadesPb_clicked()
{
    TeamDialog* d = new TeamDialog(dbHelper, this);
    d->show();
}

void TaskDialog::on_okPb_clicked()
{
    if (ui->taskNameLe->text().length() == 0){
        ui->taskNameLe->animateErrorHighlight();
        return;
    }
    model->setData(model->index(row,4),ui->priorityCb->currentIndex());
    QSqlTableModel* taskTeam=dbHelper->getTeamsTasksModel();

    if (!added){
        for (int i=0; i<taskTeam->rowCount(); i++){
            int taskId = taskTeam->data(taskTeam->index(i,1)).toInt();
            if (taskId == id){
                taskTeam->removeRow(i);
            }
        }
        taskTeam->submitAll();
    }
    int rowCount = taskTeam->rowCount();
    int recordId = (rowCount == 0) ? 1 :
                      taskTeam->data(taskTeam->index(rowCount -1,0)).toInt() + 1;
    if (!added && (ui->priorityCb->currentIndex() != oldPrio))
        priorityChanged = true;
    mapper->submit();
    if (!model->submitAll())
        qDebug()<<model->lastError();
    model->selectRow(row);

    int teams = teamsCheckList->rowCount();
    int checkedCount = 0;
    for (int i=0; i<teams; i++)
        if (teamsCheckList->item(i)->checkState() == Qt::Checked)
            checkedCount++;
    taskTeam->insertRows(rowCount,checkedCount);
    taskTeam->submitAll();

    for (int i=0; i<teams; i++){
        if (teamsCheckList->item(i)->checkState() == Qt::Checked){
            taskTeam->selectRow(rowCount);
            taskTeam->setData(taskTeam->index(rowCount,0),recordId++);
            taskTeam->setData(taskTeam->index(rowCount,2), teamsCheckList->item(i)->data());
            taskTeam->setData(taskTeam->index(rowCount,1),id);
            taskTeam->submitAll();
            rowCount++;
        }
    }
    dbHelper->updateModel();
    setResult(QDialog::Accepted);
    if (!added && (dbHelper->getTaskData(id, Task_ProId).toInt() != oldProjectId))
        projectChanged = true, qDebug()<<"changed";
    qDebug()<<"new project "<<dbHelper->getTaskData(id, Task_ProId).toInt();
    accept();
}

void TaskDialog::on_cancelPb_clicked()
{
    setResult(QDialog::Rejected);
    mapper->revert();
    if (added){
        QSqlTableModel* model = dbHelper->getTasksModel();
        model->removeRow(model->rowCount(QModelIndex())-1);
    }
    reject();
}

int TaskDialog::getOldProjectId() const
{
    return oldProjectId;
}

bool TaskDialog::isProjectChanged() const
{
    return projectChanged;
}

bool TaskDialog::getToNew() const
{
    return toNew;
}

bool TaskDialog::priorityIsChanged()
{
    return priorityChanged;
}

int TaskDialog::getId()
{
    return id;
}

bool TaskDialog::isAdded()
{
    return added;
}
