#include "helpdialog.h"
#include "ui_helpdialog.h"
#include <QUrl>

HelpDialog::HelpDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::HelpDialog)
{
    ui->setupUi(this);

    QWebSettings::globalSettings()->setAttribute(QWebSettings::AutoLoadImages,true);
    QWebSettings::globalSettings()->setAttribute(QWebSettings::JavascriptEnabled, true);
    QWebSettings::globalSettings()->setAttribute(QWebSettings::PluginsEnabled, true);
    QWebSettings::globalSettings()->setAttribute(QWebSettings::CSSGridLayoutEnabled, true);
    QWebSettings::globalSettings()->setAttribute(QWebSettings::CSSRegionsEnabled, true);

    ui->webView->page()->setLinkDelegationPolicy(QWebPage::DelegateAllLinks);
    ui->webView->load(QUrl("file://.../index.htm"));
}

HelpDialog::~HelpDialog()
{
    delete ui;
}
