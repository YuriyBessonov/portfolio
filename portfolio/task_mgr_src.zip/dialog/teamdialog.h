#ifndef TEAMDIALOG_H
#define TEAMDIALOG_H

#include <QDialog>
#include <QDataWidgetMapper>
#include "databasehelper.h"
#include <QDebug>
#include <QStandardItemModel>
namespace Ui {
class TeamDialog;
}

class TeamDialog : public QDialog
{
    Q_OBJECT

public:
    explicit TeamDialog(DataBaseHelper* dbHelper,QWidget *parent = 0);
    ~TeamDialog();

private slots:
    void on_teamEditPb_clicked();
    void on_teamRemovePb_clicked();
    void on_teamAddPb_clicked();

    void on_pushButton_clicked();

private:
    Ui::TeamDialog *ui;
    QDataWidgetMapper* mapper;
    DataBaseHelper* dbHelper;
    QSqlTableModel* model;
    QStandardItemModel* tasksCheckList;
};

#endif // TEAMDIALOG_H
