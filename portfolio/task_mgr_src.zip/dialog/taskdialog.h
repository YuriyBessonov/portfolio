#ifndef TASKDIALOG_H
#define TASKDIALOG_H

#include <QDialog>
#include <QAbstractItemModel>
#include <QDataWidgetMapper>
#include <QStandardItemModel>
#include "databasehelper.h"

namespace Ui {
class TaskDialog;
}

class TaskDialog : public QDialog
{
    Q_OBJECT

public:
    int getId();
    bool isAdded();
    explicit TaskDialog(DataBaseHelper* dbHelper, int id = -1, bool toNew = false, QWidget *parent = 0);
    ~TaskDialog();
    bool priorityIsChanged();
    bool getToNew() const;

    bool isProjectChanged() const;

    int getOldProjectId() const;

private slots:
    void on_editBrigadesPb_clicked();
    void on_okPb_clicked();
    void on_cancelPb_clicked();

private:
    Ui::TaskDialog *ui;
    int row;
    int id;
    bool added;
    bool toNew;
    int oldProjectId;
    QDataWidgetMapper* mapper;
    DataBaseHelper* dbHelper;
    QSqlRelationalTableModel* model;
    QStandardItemModel* teamsCheckList;
    QObject* parent;
    int oldPrio;
    bool priorityChanged;
    bool projectChanged;
};

#endif // TASKDIALOG_H
