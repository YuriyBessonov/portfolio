#ifndef PROJECTDIALOG_H
#define PROJECTDIALOG_H

#include <QDialog>
#include <QAbstractItemModel>
#include <QDataWidgetMapper>
#include <QStandardItemModel>
#include "databasehelper.h"

namespace Ui {
class ProjectDialog;
}

class ProjectDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ProjectDialog(const QAbstractItemModel* model = 0, QWidget *parent = 0);
    ProjectDialog(DataBaseHelper* dbHelper, int id = -1, QWidget *parent = 0);
    ~ProjectDialog();

private slots:
    void on_addTaskPb_clicked();
    void on_openImagePb_clicked();

    void on_okPb_clicked();

    void on_cancelPb_clicked();

    void on_editTaskPb_clicked();

private:
    Ui::ProjectDialog *ui;
    int row;
    int id;
    bool added;
    bool accepted;
    QSqlTableModel* model;
    DataBaseHelper* dbHelper;
    QDataWidgetMapper* mapper;
    QStandardItemModel* tasksCheckList;
    void closeEvent(QCloseEvent *);
};

#endif // PROJECTDIALOG_H
