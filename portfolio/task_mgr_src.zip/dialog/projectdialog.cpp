#include "projectdialog.h"
#include "ui_projectdialog.h"
#include "taskdialog.h"
#include <QSqlRelationalDelegate>
#include <QDebug>
#include <QFile>
#include <QFileDialog>
#include <QSqlError>
#include <QCloseEvent>
#include "util.h"
ProjectDialog::ProjectDialog(const QAbstractItemModel *model, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ProjectDialog)
{
    ui->setupUi(this);
}

ProjectDialog::ProjectDialog(DataBaseHelper *dbHelper, int id, QWidget *parent):
    QDialog(parent),
    ui(new Ui::ProjectDialog)
{
    ui->setupUi(this);
    this->dbHelper = dbHelper;
    this->id = id;
    if (id != -1)
        setWindowTitle(tr("Редактировать проект"));
    tasksCheckList = dbHelper->getTasksCheckList(id);
    added = (id == -1);
    accepted = false;

    ui->beginDateDe->setCalendarPopup(true);
    ui->beginDateDe->setDate(QDate::currentDate());
    ui->beginDateDe->setMinimumDate(QDate(1900,1,1));
    ui->endDateDe->setCalendarPopup(true);
    ui->endDateDe->setDate(QDate::currentDate());
    ui->endDateDe->setMinimumDate(QDate(1900,1,1));

    model = dbHelper->getProjectsModel();
    mapper=new QDataWidgetMapper(this);
    mapper->setModel(dbHelper->getProjectsModel());
    mapper->setItemDelegate(new QSqlRelationalDelegate(this) );
    mapper->setSubmitPolicy(QDataWidgetMapper::AutoSubmit);
    mapper->addMapping(ui->projectNameLe,1);
    mapper->addMapping(ui->beginDateDe,3);
    mapper->addMapping(ui->endDateDe,4);

    ui->tasksList->setModel(tasksCheckList);

    if (id == -1){
        int rowCount = model->rowCount(QModelIndex());
        row = rowCount;
        model->insertRow(rowCount);
        model->setData(model->index(rowCount,1),"");
        model->submitAll();
        this->id = model->data(model->index(model->rowCount()-1,0)).toInt();
        mapper->toLast();
    }
    else{
        for (int i=0; i<model->rowCount(); i++ ){
            this->id = model->data(model->index(i,0)).toInt();
            if (this->id == id){
                row = i;
                break;
            }
        }
        mapper->setCurrentModelIndex(model->index(row,0));
        QPixmap pixmap = QPixmap();
        pixmap.loadFromData(model->data(model->index(row,2)).toByteArray());
        ui->resultImageLbl->setPixmap(pixmap);
    }
}

ProjectDialog::~ProjectDialog()
{
    delete ui;
}

void ProjectDialog::on_addTaskPb_clicked()
{
    TaskDialog *d = new TaskDialog(dbHelper, -1, true, this);
    if ( d->exec() == QDialog::Rejected || !d ) {
        delete d;
        return;
    }
    else{
        tasksCheckList = dbHelper->getTasksCheckList(id);
        ui->tasksList->setModel(tasksCheckList);
    }
}


void ProjectDialog::on_openImagePb_clicked()
{
    QSqlTableModel* model = dbHelper->getProjectsModel();
    QString filename = QFileDialog::
               getOpenFileName(this, tr("Открыть файл"), "C:/", tr("Изображения (*.png *.jpg)"));
    QFile file(filename);
    if (!file.open(QIODevice::ReadOnly)) return;
    ui->resultImageLe->setText(filename);
    QByteArray inByteArray = file.readAll();

    model->setData(model->index(row,2),inByteArray);
    model->submitAll();
    file.close();
    QPixmap pixmap = QPixmap();
    pixmap.loadFromData(inByteArray);
    ui->resultImageLbl->setPixmap(pixmap);
}

void ProjectDialog::closeEvent(QCloseEvent *e)
{
    if (!accepted) {
        mapper->revert();
        if (added){
            model->removeRow(model->rowCount(QModelIndex())-1);
            model->submitAll();
        }
    }
    QWidget::closeEvent(e);
}

void ProjectDialog::on_okPb_clicked()
{
    if (ui->projectNameLe->text().length() == 0){
        ui->projectNameLe->animateErrorHighlight();
        return;
    }

    if (ui->beginDateDe->date().daysTo(ui->endDateDe->date()) < 0){
        QMessageBox::warning(0,tr("Ошибка"), tr("Дата начала проекта не может быть"
                                                " больше даты завершения!"),"ОК");
        return;
    }

    QList<int> tasksRows;
    QSqlTableModel* tasks = dbHelper->getRegularTasksModel();
    for (int i=0; i<tasksCheckList->rowCount(); i++)
        if (tasksCheckList->item(i)->checkState() == Qt::Checked)
            tasksRows<<i;
    if (ui->autoPlanningChb->isChecked()){
        dbHelper->reorderTasks(tasksRows,ui->beginDateDe->date(),ui->endDateDe->date());
    }

    mapper->submit();
    model->submitAll();


    for (int i=0; i<tasksCheckList->rowCount(); i++){
        int currentId = tasks->data(tasks->index(i,2)).toInt();
        if (tasksCheckList->item(i)->checkState() == Qt::Checked){
            if (currentId == id)
                continue;
            if (currentId != 0){
                QSqlRelationalTableModel* relTasksModel = dbHelper->getTasksModel();
                QString projectName = relTasksModel->data(relTasksModel->index(i,2)).toString();
                if (projectName != tr("Вне проектов")){
                    QString msg = tr("Задача '") +
                            tasksCheckList->item(i)->data(Qt::DisplayRole).toString() +
                            tr("' относится к проекту '") + projectName +
                            tr("'. Вы уверены, что хотите это изменить?");
                    if (!Util::accept(msg)){
                        tasksCheckList->item(i)->setCheckState(Qt::Unchecked);
                        continue;
                    }
                }
            }
            tasks->setData(tasks->index(i,2),id);
        }
        else {
            if (currentId == id){
                tasks->setData(tasks->index(i,2),model->data(model->index(0,0)));
            }
        }
    }
     tasks->submitAll();

     accepted = true;
     accept();
}

void ProjectDialog::on_cancelPb_clicked()
{
    mapper->revert();
    if (added){
        model->removeRow(model->rowCount(QModelIndex())-1);
        model->submitAll();
    }
    reject();
}

void ProjectDialog::on_editTaskPb_clicked()
{
    if (!ui->tasksList->selectionModel()->selectedIndexes().empty()){
        QModelIndex selected = ui->tasksList->selectionModel()->selectedIndexes().at(0);
        int id = tasksCheckList->data(selected,Qt::UserRole+1).toInt();
        TaskDialog *d = new TaskDialog(dbHelper, id, false, this);
        if ( d->exec() == QDialog::Rejected || !d ) {
            delete d;
            return;
        }
        else{
            tasksCheckList = dbHelper->getTasksCheckList(id);
            ui->tasksList->setModel(tasksCheckList);
        }
    }

}
