
#ifndef ENTRYDELEGATE_H
#define ENTRYDELEGATE_H

#include <QItemDelegate>
#include "databasehelper.h"
#include <KDGanttStyleOptionGanttItem>


namespace KDGantt {
    class StyleOptionGanttItem;
}

class EntryDelegate : public QItemDelegate {
public:
    explicit EntryDelegate(bool tree, DataBaseHelper *dbHelper, QObject* parent = 0 );
    
    bool editorEvent( QEvent* event, QAbstractItemModel* model, const QStyleOptionViewItem& option, const QModelIndex& index );
private:
    DataBaseHelper* dbHelper;
    bool tree;
};

#endif /* ENTRYDELEGATE_H */
