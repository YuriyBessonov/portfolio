#ifndef LEGEND_H
#define LEGEND_H

#include <QDialog>

namespace Ui {
class Legend;
}
namespace Q {
    class Legend;
}

class Q::Legend : public QDialog
{
    Q_OBJECT

public:
    explicit Legend (QWidget *parent = 0);
    ~Legend();

private:
    Ui::Legend *ui;
};

#endif // LEGEND_H
