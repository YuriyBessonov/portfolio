#include "legend.h"
#include "ui_legend.h"

Q::Legend::Legend(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Legend)
{
    ui->setupUi(this);
}

Q::Legend::~Legend()
{
    delete ui;
}
