DR_EXPLAIN.namespace( 'DR_EXPLAIN.data_index' );
DR_EXPLAIN.data_index = {

	// index
	DREX_NODE_KEYWORDS: [],
	DREX_NODE_KEYWORDS_START: [0,0,0,0,0,0,0,0,0], //length:= drex.nodes_count,
	DREX_NODE_KEYWORDS_END: [0,0,0,0,0,0,0,0,0], //length:= drex.nodes_count,

	DREX_KEYWORD_NAMES: ["<НОВЫЙ ТЕРМИН>"],
	DREX_KEYWORD_CHILD_START: [1],
	DREX_KEYWORD_CHILD_END: [1]
	
};