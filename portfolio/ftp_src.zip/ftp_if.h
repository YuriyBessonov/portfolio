#ifndef FTP_IF_H
#define FTP_IF_H
#include <ncurses.h>
#include <form.h>
#include <string.h>
#include <locale.h>
#include <dirent.h>
#include <stdlib.h>
#include <unistd.h>
#include "ftp_common.h"

#define MENU_H 1
#define STATUS_H 1
#define CONSOLE_H 3
#define HEADER_H 2
#define MENU_ENTRIES 6
#define MAX_NAME_W 24
#define ATTR_COLS 9

enum Dir {UP, DOWN};
enum ConfirmStatus {CF_CONFIRMED, CF_REJECTED};
enum Content {C_LOCAL, C_FTP};
enum Content contentType;
enum {COLOR_MAIN=1, COLOR_MENU_1, COLOR_MENU_2, COLOR_STATUS, 
	COLOR_CONSOLE, COLOR_HEADER, COLOR_PATH, COLOR_SEL, COLOR_INPUT};

void initScreen();
WINDOW *createWin(int height, int width, int starty, int startx, int colorPair, int useBox);
void initWindows();
void closeInterface();
void displayMenu();
void unselectRow(int row);
void selectRow(int row);
void setContentLocal(struct dirent* content, int count, char* headerStr);
void setContentFTP(struct FileAttr* content, int count, char* currentDir);
void displayDirContent();
void initInterface();
void displayEntry(int index, int row);
void updateEntriesView();
void moveSelection(enum Dir dir);
void displayMessage(char* msg);
void displayHeader();
void getSelectedFileInfo(char* name, enum FileType* type);
void inputDialog(char* title, char* inpStr);
int confirmationDialog(char* action);
void displayStatus(char* statusStr, char* additionalStr);
void displayContextMenu(char *menuEnt[], char* menuKeys[], int entries);
#endif
