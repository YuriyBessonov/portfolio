#ifndef FTP_COMMON_H
#define FTP_COMMON_H

#define BUF_SMALL 64
#define BUF_S 256
#define BUF_DATA_S 2048
#define BUF_FILES_S 4096
#define BUF_PATH_S 4096

#define ERR_CANNOT_WRITE -1
#define ERR_CANNOT_READ -2
#define ERR_TRANSFER_FAIL -3
#define ERR_ABORTED -4

char lastMsg[BUF_S];
enum FileType {FT_FILE, FT_DIR, FT_PARENT};
enum Status {ANS_WIP=1, ANS_DONE=2, ANS_CMD_REQ=3, ERR_NOT_NOW=4, 
	ERR_NOT_POSSIBLE=5 };

enum TransferType { T_ASCII='A', T_EBCDIC='E', T_BINARY='I' };

struct FileAttr {
	char perm[12];
	int symbLinks;
	char owner[BUF_SMALL];
	char group[BUF_SMALL];
	unsigned long size;
	char month[12];
	int day;
	char timeHM[6];
	char name[BUF_S];
};

struct FileProcessArgs {
	int cSock;
	int dSock;
	char* fileName;
};

#endif
