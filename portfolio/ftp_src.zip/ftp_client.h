#ifndef FTP_CLENT
#define FTP_CLENT
#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <netdb.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/time.h>
#include <pthread.h>
#include <sys/param.h>
#include <sys/stat.h>
#include <dirent.h>
#include "ftp_common.h"

/** Функции, отвечающие за логику программы **/
int prepareClient();
void actionGetFile(int cSock);
void actionStoreFile(int cSock);
void actionRename(int cSock);
void actionDelete(int cSock);
void actionMakeDir(int cSock);
void actionOpenDir(int cSock);
void updateCurrentDir(int cSock);
void processInput(int cSock);

/** Функции отправки основных команд FTP **/
int simpleCommand(int cSock, char* cmd, char* arg);
int getWorkDir(int cSock, char* wd);
int changeWorkDir(int cSock, char* wd);
int makeParentWorkDir(int cSock);
int makeDir(int cSock, char* dir);
int deleteDir(int cSock, char* dir);
int deleteFile(int cSock, char* file);
int quit(int cSock);
int setType(int cSock, enum TransferType t);
int list(int cSock, char* dir, struct FileAttr content[]);
int getFile(int cSock, char* file);
int storeFile(int cSock, char* file);
int renameEntry(int cSock, char* from, char* to);

/** Прочие функции взаимодействия с сервером  **/
void fileReceiver(void* args);
void fileSender(void* args);
int login(int cSock);
int initControlConn(char* ip);
int initDataConn(int cSock);
int sendCmd(int sock, char* cmd);
int recvAns(int sock);

/** Функции работы с локальной ФС **/
int loadLocalDirContent(char* dirName, struct dirent dirContent[]);
int navigateLocalFS(char* headerStr, char* menuEntStr, char* pickedFile);

/** Вспомогательные функции **/
int parseFileAttr(char* str, struct FileAttr* attr);
int isBusy();
void setBusy(int val);
char* cutCode(char* msg);
void printLastMsg();
int getAnsStatus(char* ans);
#endif
