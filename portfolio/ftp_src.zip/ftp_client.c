#include "ftp_client.h"
#include "ftp_if.h"

int busy = 0;
pthread_mutex_t busyMut;
char lastMsg[BUF_S];

int main(int argc, char* argv[]){
	int cSock = prepareClient();
	initInterface();
	
	char dir[BUF_S];
	getWorkDir(cSock, dir);
	struct FileAttr content[BUF_FILES_S];
	int count = list(cSock,NULL, content);
	setContentFTP(content,count, dir);
	pthread_mutex_init(&busyMut, 0);
	
	while (1)
		processInput(cSock);
		
	return 0;
}

/** Функции, отвечающие за логику программы **/
//подключиться и авторизоваться
int prepareClient(){
	char ipStr[BUF_SMALL];
	printf("Введите IP адрес FTP сервера: ");
	scanf("%s",ipStr);
	int cSock = initControlConn(ipStr);
	
	//приветственное сообщение
	recvAns(cSock);
	printLastMsg();
	char s[BUF_S];
	while (login(cSock) < 0){
		printLastMsg();
		printf("Попробовать авторизоваться снова? (y/n)?: ");
		scanf("%s",s);
		if (strcmp(s,"n") == 0){
			exit(0);
		}
	}
	return cSock;
}

//получить выбранный файл
void actionGetFile(int cSock){
	if (isBusy()){
		displayStatus("Дождитесь завершения предыдущей операции",NULL);
		return;
	}
	
	char name[BUF_S];
	enum FileType fileType;
	getSelectedFileInfo(name, &fileType);
	if (fileType == FT_PARENT)
		return;
	else if (fileType == FT_DIR){
		displayStatus("Нужно указать файл, а не папку",NULL);
		return;
	}
	
	setBusy(1);
	int result = navigateLocalFS("Укажите папку для сохранения","Выбрать текущ. папку", NULL);
	updateCurrentDir(cSock);
	displayMenu();
	
	if (result < 0){
		setBusy(0);
		displayStatus("Операция отменена",NULL);
	}
	else if (getFile(cSock, name) < 0){
			setBusy(0);
			displayStatus("Сервер отклонил запрос получения файла",NULL);
	}
}

//выбрать и отправить файл
void actionStoreFile(int cSock){
	if (isBusy()){
		displayStatus("Дождитесь завершения предыдущей операции",NULL);
		return;
	}
	
	setBusy(1);
	char pickedFile[BUF_S];
	int result = navigateLocalFS("Укажите файл для отправки","Отправить выбр. файл", pickedFile);
	updateCurrentDir(cSock);
	displayMenu();
	
	if (result < 0){
		setBusy(0);
		displayStatus("Операция отменена",NULL);
	}
	else if (storeFile(cSock, pickedFile) < 0){
			setBusy(0);
			displayStatus("Сервер отклонил запрос отправки файла файла",NULL);
	}
}

//переименовать выбранный объект
void actionRename(int cSock){
	char nameOld[BUF_S];
	char nameNew[BUF_S];
	char result[BUF_S];
	enum FileType fileType;
	getSelectedFileInfo(nameOld, &fileType);
	if (fileType == FT_PARENT)
		return;
	inputDialog("Новое имя",nameNew);
	if (strlen(nameNew) == 0)
		sprintf(result,"Операция отменена");
	else if (renameEntry(cSock, nameOld, nameNew) < 0){
		sprintf(result,"Не удалось переименовать объект %s в %s",nameOld, nameNew);
	}
	else {
		sprintf(result,"Объект %s переименован в %s",nameOld, nameNew);
		updateCurrentDir(cSock);
	}
	displayStatus(result,NULL);
}

//удалить выбранный объект
void actionDelete(int cSock){
	char name[BUF_S];
	char result[BUF_S];
	enum FileType fileType;
	getSelectedFileInfo(name, &fileType);
	if (fileType == FT_PARENT)
		return;
	if (confirmationDialog("удалить выбранный объект") == CF_REJECTED){
		sprintf(result,"Операция отменена");
	}
	else if (fileType == FT_DIR){
		if (deleteDir(cSock,name) < 0){
			sprintf(result,"Не удалось удалить папку %s",name);
		}
		else{
			sprintf(result,"Папка %s успешно удалена",name);
			updateCurrentDir(cSock);
		} 
	}
	else {
		if (deleteFile(cSock,name) < 0){
			sprintf(result,"Не удалось удалить файл %s",name);
		}
		else{
			sprintf(result,"Файл %s успешно удален",name);
			updateCurrentDir(cSock);
		} 
	}
	displayStatus(result,NULL);
}

//создать новую папку
void actionMakeDir(int cSock){
	char name[BUF_S] = "";
	inputDialog("Имя новой папки",name);
	char result[BUF_S];
	if (strlen(name) == 0){
		sprintf(result,"Операция отменена");
	}
	else {
		if (makeDir(cSock, name) < 0){
			sprintf(result,"Не удалось создать папку %s",name);
		}
		else {
			sprintf(result,"Папка %s успешно создана",name);
			updateCurrentDir(cSock);
		}
	}
	displayStatus(result,NULL);
}

//сделать выбранную папку (если это папка) рабочей
void actionOpenDir(int cSock){
	char selectedFile[BUF_S];
	enum FileType fileType;
	bzero(selectedFile,BUF_S);
	getSelectedFileInfo(selectedFile, &fileType);
	switch (fileType){
		case FT_DIR:
			changeWorkDir(cSock, selectedFile);
			updateCurrentDir(cSock);
			break;
		case FT_PARENT:
			makeParentWorkDir(cSock);
			updateCurrentDir(cSock);
			break;
		default:
			break;
	}
}

//отобразить содержимое рабочей папки сервера
void updateCurrentDir(int cSock){
	struct FileAttr content[BUF_FILES_S];
	char pathBuf[BUF_PATH_S]="";
	getWorkDir(cSock, pathBuf);
	int count = list(cSock,NULL, content);
	setContentFTP(content,count, pathBuf);
}

//обработка пользовательского ввода (основной цикл программы)
void processInput(int cSock){
	int ch=getch();
	
	switch (ch){
		case 27://ESC
			closeInterface();
			exit(0);
			break;
		case KEY_DOWN:
			moveSelection(DOWN);
			break;
		case KEY_UP:
			moveSelection(UP);
			break;
		case KEY_ENTER:
		case 10:
			actionOpenDir(cSock);
			break;
	   case KEY_F(2):
			actionGetFile(cSock);
			break;
	   case KEY_F(3):
			actionRename(cSock);
			break;
		case KEY_F(4):
			actionDelete(cSock);
			break;
		case KEY_F(5):
			actionMakeDir(cSock);
			break;
		case KEY_F(6):
			actionStoreFile(cSock);
			break;
	}
}

/** Функции отправки основных команд FTP **/
//отправка простейшей команды
int simpleCommand(int cSock, char* cmd, char* arg){
	char buf[BUF_S];
	if (arg != NULL)
		sprintf(buf,"%s %s\r\n",cmd, arg);
	else 
		sprintf(buf,"%s\r\n",cmd);
	sendCmd(cSock, buf);
	recvAns(cSock);
	if (getAnsStatus(lastMsg) == ANS_DONE)
		return 0;
	return -1;
}

//запрос рабочей папки
int getWorkDir(int cSock, char* wd){
	char cmd[BUF_S] = "PWD\r\n";
	sendCmd(cSock, cmd);
	
	char pathBuf[BUF_PATH_S];
	recv(cSock,&pathBuf,BUF_PATH_S,0); 
	if (getAnsStatus(pathBuf) != ANS_DONE){
		wd = NULL;
		return -1;
	}
	char *dir = strchr(pathBuf, '\"');
	char* end = strchr(++dir, '\"');
	strncpy(wd, dir, end-dir); 
	return 0;
}

//смена рабочей папки
int changeWorkDir(int cSock, char* wd){
	return simpleCommand(cSock,"CWD",wd);
}

//установка родительской папки в качестве текущей 
int makeParentWorkDir(int cSock){
	return simpleCommand(cSock,"CDUP",NULL);
}

//создание папки
int makeDir(int cSock, char* dir){
	return simpleCommand(cSock,"MKD",dir);
}

//удаление папки 
int deleteDir(int cSock, char* dir){
	return simpleCommand(cSock,"RMD",dir);
}

//удаление файла
int deleteFile(int cSock, char* file){
	return simpleCommand(cSock,"DELE",file);
}

//завершение работы с ftp
int quit(int cSock){
	char cmd[BUF_S] = "QUIT\r\n";
	sendCmd(cSock, cmd);
	return 0;
}

//установка типа передачи файлов
int setType(int cSock, enum TransferType t){
	char buf[BUF_SMALL];
	sprintf(buf,"%c",t);
	return simpleCommand(cSock, "TYPE", buf);
}

//получение содержимого рабочей папки
int list(int cSock, char* dir, struct FileAttr content[]){
	setType(cSock, T_ASCII);
	int dSock = initDataConn(cSock);
	char cmd[BUF_S];
	if (dir != NULL)
		sprintf(cmd,"LIST %s\r\n",dir);
	else 
		sprintf(cmd,"LIST\r\n");
	sendCmd(cSock, cmd);
	recvAns(cSock);
	
	if (getAnsStatus(lastMsg) == ANS_WIP){
		recvAns(cSock);
	}
	if (getAnsStatus(lastMsg) != ANS_DONE){
		close(dSock);
		return -1;
	}
		
	char buf[BUF_DATA_S] = "";
	char* wp = buf;
	bzero(buf, BUF_DATA_S);
	int r;
	int i = 0;
	bzero(&content[i], sizeof(content[i]));
	strcpy(content[i].name,"..");
	i++;
	while ((r = recv(dSock,wp, buf + BUF_DATA_S - wp,0)) > 0){
		char *p = strtok (buf,"\n");
		while (p != NULL){
			if (parseFileAttr(p,&content[i]) < 0){
				int left = buf + BUF_DATA_S - p;
				strncpy(buf,p,left);
				wp = buf + left;
				break;
			}
			if (++i >= BUF_FILES_S){
				close(dSock);
				return 1;
			}
			p = strtok (NULL, "\n");
		}
	}
	close(dSock);
	return i;
}

//получение файла
int getFile(int cSock, char* file){
	setType(cSock, T_BINARY);
	int dSock = initDataConn(cSock);
	char cmd[BUF_S+BUF_SMALL];
    sprintf(cmd,"RETR %s\r\n",file);
    sendCmd(cSock, cmd);
    recvAns(cSock);
    
    if (getAnsStatus(lastMsg) != ANS_WIP){
		setBusy(0);
		return -1;
	}
    
    pthread_t tid;
    struct FileProcessArgs args = {cSock, dSock, file};
    pthread_create(&tid, NULL,(void*(*)(void*))fileReceiver,(void*)&args);
    return 0;
}

//отправка файла
int storeFile(int cSock, char* file){
	setType(cSock, T_BINARY);
	int dSock = initDataConn(cSock);
	char cmd[BUF_S+BUF_SMALL];
    sprintf(cmd,"STOR %s\r\n",file);
    sendCmd(cSock, cmd);
    recvAns(cSock);
    
    if (getAnsStatus(lastMsg) != ANS_WIP){
		setBusy(0);
		return -1;
	}
    
    pthread_t tid;
    struct FileProcessArgs args = {cSock, dSock,file};
    pthread_create(&tid, NULL,(void*(*)(void*))fileSender,(void*)&args);
    return 0;
}

//переименование
int renameEntry(int cSock, char* from, char* to){
	char cmd[BUF_S];
	sprintf(cmd,"RNFR %s\r\n",from);
	sendCmd(cSock, cmd);
	recvAns(cSock);
	if (getAnsStatus(lastMsg) != ANS_CMD_REQ)
		return -1;
		
	sprintf(cmd,"RNTO %s\r\n",to);
	sendCmd(cSock, cmd);
	recvAns(cSock);
	if (getAnsStatus(lastMsg) != ANS_DONE)
		return -1;
	return 0;
}


/** Прочие функции взаимодействия с сервером  **/
//функция потока получения файла
void fileReceiver(void* args){
	int err = 0;
	struct FileProcessArgs* targs = (struct FileProcessArgs*)args;
	int cSock = targs->cSock;
	int dSock = targs->dSock;
	char fileName[BUF_S];
	strcpy(fileName, targs->fileName);
	char *tmp;
    tmp = strtok(lastMsg,"(");
    tmp = strtok(NULL,"(");
    tmp = strtok(tmp, ")");
    tmp = strtok(tmp, " ");
    
    unsigned long fileSize;
    sscanf(tmp,"%lu", &fileSize);
    FILE *f;
    f = fopen(fileName, "wb");
    int ansReceived = 0;
    char statBuf[BUF_S];

    if (f != NULL)
    {
		unsigned long received = 0;
		char buf[BUF_DATA_S]; 
		
		fd_set rfds;
		FD_ZERO(&rfds);
		int nfds = MAX(cSock,dSock)+1;
		sprintf(statBuf, "Получение файла %s...",fileName);
		displayStatus(statBuf,NULL);
		while (1){
			FD_SET(cSock,&rfds);
			FD_SET(dSock,&rfds);
			if (select(nfds,&rfds,0,0,0) < 0)
				break;
			
			if (FD_ISSET(dSock, &rfds)){
				int read = recv(dSock, buf, BUF_DATA_S, 0);
				if (read <= 0)
					break;
				received += read;
				if (fwrite(buf,1,read,f) < read){
					err = ERR_CANNOT_WRITE;
					break;
				}
			}
			if (FD_ISSET(cSock, &rfds)){
				recvAns(cSock);
				ansReceived = 1;
				if (getAnsStatus(lastMsg) == ERR_NOT_NOW){
					err = ERR_ABORTED;
					break;
				}
			}
			if (received >= fileSize)
				break;
		}
		fclose(f);
		if (!err && received < fileSize)
			err = ERR_TRANSFER_FAIL;
	}
	else err = ERR_CANNOT_WRITE;
    close(dSock);
    if (!ansReceived)
		recvAns(cSock);
		
	if (!err){
		sprintf(statBuf, "Прием файла %s завершен",fileName);
	}
	else if (err == ERR_CANNOT_WRITE){
		sprintf(statBuf, "Ошибка сохранения файла %s",fileName);
	}
	else if (err == ERR_ABORTED){
		sprintf(statBuf, "Прием файла %s прерван",fileName);
	}
	else if (err == ERR_TRANSFER_FAIL){
		sprintf(statBuf, "Во время получения файла %s произошла ошибка",fileName);
	}
	setBusy(0);
	displayStatus(statBuf,NULL);
} 

//функция потока отправки файла
void fileSender(void* args){
	int err = 0;
	struct FileProcessArgs* targs = (struct FileProcessArgs*)args;
	int cSock = targs->cSock;
	int dSock = targs->dSock;
	char fileName[BUF_S];
	strcpy(fileName, targs->fileName);
	char statBuf[BUF_S];
    FILE *f;
    f = fopen(fileName, "rb");
    if (f != NULL)
    {
		struct stat file_stat;
		stat(fileName, &file_stat);
		off_t fileSize = file_stat.st_size;
		off_t totalSent = 0;
		
		char buf[BUF_DATA_S]; 
		int read;
		sprintf(statBuf, "Отправка файла %s...",fileName);
		displayStatus(statBuf,NULL);
		while ( (read = fread(buf,1,BUF_DATA_S,f)) > 0){
			int sent = send(dSock, buf, read, 0);
			if (sent <= 0){
				err = ERR_TRANSFER_FAIL;
				break;
			}
			totalSent+=sent;
		}
		if (read < 0)
			err = ERR_CANNOT_READ;
		if (totalSent < fileSize)
			err = ERR_TRANSFER_FAIL;
		fclose(f);
	}
	else err = ERR_CANNOT_READ;
	
	close(dSock);
	recvAns(cSock);
	if (!err && getAnsStatus(lastMsg) != ANS_DONE)
		err = ERR_ABORTED;
		
	if (!err){
		sprintf(statBuf, "Отправка файла %s завершена",fileName);
		updateCurrentDir(cSock);
	}
	else if (err == ERR_CANNOT_READ){
		sprintf(statBuf, "Ошибка чтения файла %s",fileName);
	}
	else if (err == ERR_ABORTED){
		sprintf(statBuf, "Отправка файла была %s прервана",fileName);
	}
	else if (err == ERR_TRANSFER_FAIL){
		sprintf(statBuf, "Во время отправки файла %s произошла ошибка",fileName);
	}
	setBusy(0);
	displayStatus(statBuf,NULL);
}

//авторизация
int login(int cSock){
	char buf[BUF_S];
	char name[BUF_S/2];
	int ans;
	printf("Введите логин: ");
	scanf("%s", name);
	sprintf(buf, "USER %s\r\n",name);
	sendCmd(cSock, buf);
	ans = recvAns(cSock);
	
	if (ans == ANS_CMD_REQ){
		char pass[BUF_S/2];
		printf("Введите пароль: ");
		scanf("%s", pass);
		sprintf(buf, "PASS %s\r\n",pass);
		sendCmd(cSock, buf);
		ans = recvAns(cSock);
	}
	
	if (ans == ANS_DONE){
		printf("Авторизация успешна.\n");
		return 0;
	}
	else {
		printf("Авторизация не удалась.\n");
		return -1;
	}
}

//установка управляющего соединения
int initControlConn(char* ip){
	int sock;
	struct sockaddr_in servAddr;
	if ( (sock = socket(AF_INET, SOCK_STREAM, 0)) < 0 ){
		perror("Socket не получен");
		exit(1);
	}
	
	bzero( (char*)&servAddr, sizeof(servAddr));
	servAddr.sin_family = AF_INET;
	if (inet_aton(ip, &servAddr.sin_addr) == 0){
		printf("Указан неправильный ip адрес\n");
		exit(1);
	}
	servAddr.sin_port = htons(21);
	
	if (connect(sock, (struct sockaddr*)&servAddr, sizeof(servAddr)) < 0){
		perror("Клиент не может соединиться");
		exit(1);
	}
	return sock;
}

//установка соединения передачи данных
int initDataConn(int cSock){
	char pasv[] = "PASV\r\n";
	sendCmd(cSock, pasv);
	recvAns(cSock);
	char* tmp;
	tmp = strtok(lastMsg, "(");
	tmp = strtok(NULL, "(");
	tmp = strtok(tmp, ")");
	int ip[4];
	int a,b;
	sscanf(tmp, "%d, %d, %d, %d, %d, %d", &ip[0], &ip[1], &ip[2], &ip[3],
												&a, &b);
	char ipStr[BUF_SMALL];
	sprintf(ipStr,"%d.%d.%d.%d", ip[0],ip[1],ip[2],ip[3]);
	int port = b + (a << 8);
	int dSock;
	struct sockaddr_in addr;
	if ( (dSock = socket(AF_INET, SOCK_STREAM, 0)) < 0 ){
		return -1;
	}
	
	bzero( (char*)&addr, sizeof(addr));
	addr.sin_family = AF_INET;
	if (inet_aton(ipStr, &addr.sin_addr) == 0){
		return -1;
	}
	addr.sin_port = htons(port);
	
	if (connect(dSock, (struct sockaddr*)&addr, sizeof(addr)) < 0){
		return -1;
	}
	return dSock;
}

//отправка команды
int sendCmd(int sock, char* cmd){
	return send(sock,cmd,strlen(cmd), 0);
}

//получение ответа по управляющему соединению
int recvAns(int sock) {
    int ret = -1;
    bzero(lastMsg,BUF_S);
    if (recv(sock,&lastMsg,BUF_S,0) < 0)
		return -1;
    ret = getAnsStatus(lastMsg);
    return ret;
}	


/** Функции работы с локальной ФС **/
//получить содержимое указанной папки
int loadLocalDirContent(char* dirName, struct dirent dirContent[]){
    DIR *dir;
    
    dir = opendir(dirName);
    if (!dir)
        return -1;
        
    if (chdir(dirName) < 0)
		return -1;
		
    int i=1;
    struct dirent* entry;
    while ( (entry = readdir(dir)) != NULL ) {
        if (strcmp("..",entry->d_name) == 0){
            dirContent[0] = *entry;
        }
        else if (strncmp(".",entry->d_name, 1) != 0){
            dirContent[i] = *entry;
            i++;
        }
    };
    return i;
}

//выбор файла/папки на компьютере
int navigateLocalFS(char* headerStr, char* menuEntStr, char* pickedFile){
	struct dirent entries[BUF_FILES_S];
	int count = loadLocalDirContent("/", entries);
	setContentLocal(entries, count,headerStr);
	char* menuEnt[] = {menuEntStr, "Отменить"};
	char* menuKeys[] = {"F2", "Esc"};
	displayContextMenu(menuEnt, menuKeys, 2);
	
	char selected[BUF_S];
	enum FileType fileType;
	int ret = -1;
	while (1){
		int ch=getch();
		if (ch == 27){
			break;
		}
		else if (ch == KEY_UP)
			moveSelection(UP);
		else if (ch == KEY_DOWN)
			moveSelection(DOWN);
		else if (ch == KEY_F(2)){
			if (pickedFile != NULL){
				getSelectedFileInfo(selected, &fileType);
				if (fileType == FT_FILE){
					strcpy(pickedFile,selected);
					ret = 0;
					break;
				}
				else displayStatus("Выберите файл, а не папку",NULL);
			}
			else {
				ret = 0;
				break;
			}
		}
		else if (ch == KEY_ENTER || ch == 10){
			getSelectedFileInfo(selected, &fileType);
			if (fileType != FT_FILE){
				count = loadLocalDirContent(selected, entries);
				setContentLocal(entries, count, headerStr);
			}
		}
	}
	return ret;
}

/** Вспомогательные функции **/
//формирование массива структур на основе результата команды LIST
int parseFileAttr(char* str, struct FileAttr* attr){
	int read = sscanf(str, "%s %d %s %s %lu %s %d %s %[^\r]s",attr->perm, &attr->symbLinks, attr->owner,
		attr->group, &attr->size, attr->month, &attr->day, attr->timeHM, attr->name);
	if (read < 9)
		return -1;
	return 0;
}

//происходит ли обмен данными с сервером
int isBusy(){
	int ret;
	pthread_mutex_lock(&busyMut);
	ret = busy;
	pthread_mutex_unlock(&busyMut);
	return ret;
}

//установка флага занятости
void setBusy(int val){
	pthread_mutex_lock(&busyMut);
	busy = val;
	pthread_mutex_unlock(&busyMut);
}

//удаление кода ответа из строки
char* cutCode(char* msg){
	return msg + 4;
}

//отображение последнего полученного ответа
void printLastMsg(){
	printf("> %s\n",cutCode(lastMsg));
}

//определить статус ответа
int getAnsStatus(char* ans){
	if (strlen(ans) > 0){
		char c = ans[0];
		if (c >= '1' && c <='5'){
			return c - '0';
		}
	}
	return -1;
}




