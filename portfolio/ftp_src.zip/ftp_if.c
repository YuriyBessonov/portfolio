#include "ftp_if.h"

WINDOW *status, *menu, *console, *mainw, *header;
struct dirent* fsEntries;
struct FileAttr* ftpEntries;
int selectedRow, selectedEntry;
int entriesCount;
int margins[ATTR_COLS] = {1, 24, 13, 8, 7, 7, 14, 4, 3};
char* curDir;
char* curHeader;

//отобразить сообщение в консоли
void displayMessage(char* msg){
	int col = getmaxx(console);
	int i;
	for (i =0; i<CONSOLE_H; i++)
		mvwhline(console, i, 0, ' ',col);
	char* buf = (char*)malloc(col);
	bzero(buf,col);
	strncpy(buf,msg,col-1);
	buf[col-1] ='\0';
	mvwprintw(console, 0, 1, "%s", buf);
	if (strlen(msg) >= col){
		bzero(buf,col);
		strcpy(buf,msg+col-1);
		mvwprintw(console, 1, 1, "%s", buf);
	}
	wrefresh(console);
}

//инициализация графического режима
void initScreen(){
    initscr();
    clear();
    curs_set(0);
    noecho();
    keypad(stdscr, TRUE);
    raw();
    start_color();
    
    curs_set(0);
    init_pair(COLOR_MAIN, COLOR_WHITE, COLOR_MAGENTA);
    init_pair(COLOR_SEL, COLOR_BLACK, COLOR_WHITE);
    init_pair(COLOR_STATUS, COLOR_BLACK, COLOR_WHITE);
    init_pair(COLOR_CONSOLE, COLOR_WHITE, COLOR_BLACK);
    init_pair(COLOR_MENU_1, COLOR_WHITE, COLOR_MAGENTA);
    init_pair(COLOR_MENU_2, COLOR_MAGENTA, COLOR_WHITE);
    init_pair(COLOR_HEADER, COLOR_WHITE, COLOR_MAGENTA);
    init_pair(COLOR_PATH, COLOR_YELLOW, COLOR_MAGENTA);
    init_pair(COLOR_INPUT, COLOR_YELLOW, COLOR_BLACK);
    refresh();
}

//создание окна с заданными параметрами
WINDOW *createWin(int height, int width, int starty, int startx, int colorPair, int useBox){	
	WINDOW *local_win;
	local_win = newwin(height, width, starty, startx);
	wbkgdset(local_win,COLOR_PAIR(colorPair));
	wclear(local_win);
	wattron(local_win, COLOR_PAIR(colorPair));
	if (useBox)//рисовать ли рамку
        box(local_win, 0 , 0);
	wrefresh(local_win);

	return local_win;
}

//создание окон программы
void initWindows(){
    int row, col;
    getmaxyx(stdscr,row,col);
    int y = row - MENU_H;
    menu = createWin(MENU_H,col,y,0,COLOR_MENU_1, FALSE);
    y-=CONSOLE_H;
    console = createWin(CONSOLE_H,col,y,0,COLOR_CONSOLE, FALSE);
    y-=STATUS_H;
    status = createWin(STATUS_H,col,y,0,COLOR_STATUS, FALSE);
    
    header = createWin(HEADER_H,col,0,0,COLOR_HEADER, FALSE);
    mainw = createWin(y-HEADER_H,col,HEADER_H,0,COLOR_MAIN, TRUE);
    attron(COLOR_PAIR(COLOR_MAIN));
}

//завершение работы в графическом режиме
void closeInterface(){
	clear();
	cbreak();
	echo();
	refresh();
	endwin();
}

//отображение основного меню
void displayMenu(){
    char *menuEnt[MENU_ENTRIES] = {"Загруз.  ", "Переименов.  ", "Удал.  ", "Созд. папку  ", "Отправ. сюда файл", "Выход" };
    char *menuKeys[MENU_ENTRIES] = {"F2", "F3", "F4", "F5", "F6", "Esc"};
    char c = 0;
    int i;
    int col = getmaxx(menu);
    wattron (menu,COLOR_PAIR(COLOR_STATUS));
    //wclear(menu);
    whline(menu, ' ', col);
    for (i =0; i<MENU_ENTRIES; i++){
        wattron (menu,COLOR_PAIR(COLOR_MENU_1));
        mvwprintw(menu, 0, c, "%s",menuKeys[i]);
        c+=strlen(menuKeys[i]);
        wattron (menu,COLOR_PAIR(COLOR_STATUS));
        mvwprintw(menu, 0, c, "%s", menuEnt[i]);
        c+=strlen(menuEnt[i])/strlen("ы")+3;
    }
    
    wrefresh(menu);
}

//отображение произвольного меню
void displayContextMenu(char *menuEnt[], char* menuKeys[], int entries){
    char c = 0;
    int i;
    wattron (menu,COLOR_PAIR(COLOR_STATUS));
    wclear(menu);
    for (i =0; i<entries; i++){
        wattron (menu,COLOR_PAIR(COLOR_MENU_1));
        mvwprintw(menu, 0, c, "%s",menuKeys[i]);
        c+=strlen(menuKeys[i]);
        wattron (menu,COLOR_PAIR(COLOR_STATUS));
        mvwprintw(menu, 0, c, "%s", menuEnt[i]);
        c+=strlen(menuEnt[i])/strlen("ы")+3;
    }
    wrefresh(menu);
}

//отмена выделения строки
void unselectRow(int row){
    attr_t attr;
    int colorPair;
    wattr_get(mainw, &attr, &colorPair,NULL);
    mvwchgat(mainw,row+1, 0, -1,  A_NORMAL, colorPair, NULL);
    box(mainw,0,0);
    wrefresh(mainw);
}

//выделение строки
void selectRow(int row){
    if (row != selectedRow)
        unselectRow(selectedRow);
    selectedRow = row;
    mvwchgat(mainw,row+1, 0, -1,  A_BOLD , COLOR_SEL, NULL);
    box(mainw,0,0);
    wrefresh(mainw);
}

//установка в качестве отображаемого содержимого список локальных файлов
void setContentLocal(struct dirent* content, int count, char* headerStr){
	entriesCount = count;
	contentType = C_LOCAL;
	curDir = (char*)malloc(BUF_PATH_S);
	curHeader = headerStr;
	getcwd(curDir,BUF_PATH_S);
	fsEntries = content;
	updateEntriesView();
}

//установка в качестве отображаемого содержимого список файлов с сервера
void setContentFTP(struct FileAttr* content, int count, char* currentDir){
	entriesCount = count;
	contentType = C_FTP;
	curDir = currentDir;
	ftpEntries = content;
	updateEntriesView();
}

//отобразить элемент
void displayEntry(int index, int row){
    wmove(mainw,row,1);
    int maxCols = getmaxx(mainw);
    whline(mainw, ' ', maxCols - 2);
    if (contentType == C_LOCAL){
		mvwprintw(mainw, row, 1, " %s%c" ,fsEntries[index].d_name,
                fsEntries[index].d_type == DT_DIR ? '/':' ');
	}
	else {
		int i=0;
		int x = margins[i++];
		if (strcmp(ftpEntries[index].name, "..") == 0){
			mvwprintw(mainw, row, x, " %s", ftpEntries[index].name);
			wrefresh(mainw);
			return;
		}
		mvwprintw(mainw, row, x, " %s%c", ftpEntries[index].name,
			((ftpEntries[index].perm[0] == 'd') ? '/' : ' '));
		x += margins[i++];
		mvwprintw(mainw, row, x,"  %s", ftpEntries[index].perm);
		x += margins[i++];
		mvwprintw(mainw, row, x,"  %d", ftpEntries[index].symbLinks);
		x += margins[i++];
		mvwprintw(mainw, row, x,"%s", ftpEntries[index].owner);
		x += margins[i++];
		mvwprintw(mainw, row, x,"%s", ftpEntries[index].group);
		x += margins[i++];
		mvwprintw(mainw, row, x,"%lu", ftpEntries[index].size);
		x += margins[i++];
		mvwprintw(mainw, row, x,"%s", ftpEntries[index].month);
		x += margins[i++];
		mvwprintw(mainw, row, x,"%d", ftpEntries[index].day);
		x += margins[i++];
		mvwprintw(mainw, row, x,"%s", ftpEntries[index].timeHM);
	}
    wrefresh(mainw);
}

//отобразить содержимое текущей папки
void displayDirContent(){
    int r = 1;
    int maxRows = getmaxy(mainw);
    int i;
    wattron (mainw,COLOR_PAIR(COLOR_MAIN));
    for (i=0; i < entriesCount && i < maxRows ; i++){
        displayEntry(i,r);
        r++;
    }
    box(mainw, 0 , 0);
    wrefresh(mainw);
}

//отоюразить заголовок
void displayHeader(){
    int col = getmaxx(header);
    wattron (header, COLOR_PAIR(COLOR_HEADER));
    mvwhline(header, 0, 0, ' ',col);
    mvwhline(header, 1, 0, ' ',col);
    if (contentType == C_FTP){
		mvwprintw(header, 0, 1, "[ftp]%s", curDir);
		char cols[ATTR_COLS][BUF_SMALL] = {"Имя", "  Права", "  Ссыл.", "Влад.", "Гр.",  "Разм.", "Дата измен."};
		int i, x;
		for (i = 0, x = 0; i< 7; i++){
			x += margins[i];
			mvwprintw(header, 1, x, "%s", cols[i]);
		}
	}
	else {
		mvwprintw(header, 0, 1, "[local]%s", curDir);
		if (curHeader != NULL)
			mvwprintw(header, 1, 1, "%s", curHeader);
	}
	mvwchgat(header,0, 0, -1,  A_BOLD , COLOR_PATH, NULL);
    wrefresh(header);
}

//обновить представление текущей папки
void updateEntriesView(){
    wclear(mainw);
    wclear(console);
    wrefresh(console);
    wclear(status);
    wrefresh(status);
    selectedRow = 0;
    selectedEntry = 0;
    displayDirContent();
    displayHeader();
    selectRow(selectedRow);
}

//инициализация интерфейса
void initInterface(){
	setlocale(0, "");
    initScreen();
    initWindows();
	displayMenu();
}

//переместить выделение
void moveSelection(enum Dir dir){
    if ( (selectedEntry <= 0 && dir == UP) ||
        (selectedEntry >= entriesCount - 1 && dir == DOWN))
            return;
    if (dir == UP){
        selectedEntry--;
        if (selectedRow > 0)
            selectRow(selectedRow - 1);
        else {
            scrollok(mainw, TRUE);
            unselectRow(selectedRow);
            wscrl(mainw,-1);
            displayEntry(selectedEntry,selectedRow+1);
            selectRow(selectedRow);
            box(mainw,0,0);
            scrollok(mainw, FALSE);
        }
    }
    else {
        selectedEntry++;
        int maxRow = getmaxy(mainw) - 2;
        if (selectedRow < maxRow - 1)
            selectRow(selectedRow+ 1);
        else {
            scrollok(mainw, TRUE);
            unselectRow(selectedRow);
            wscrl(mainw,1);
            displayEntry(selectedEntry,selectedRow+1);
            selectRow(selectedRow);
            box(mainw,0,0);
            scrollok(mainw, FALSE);
        }
    }
    wrefresh(mainw);
}

//получить имя и тип выделенного файла
void getSelectedFileInfo(char* name, enum FileType* type){
	if (contentType == C_FTP){
		sprintf(name, "%s", ftpEntries[selectedEntry].name);
		if (selectedEntry == 0)
			*type = FT_PARENT;
		else {
			if (ftpEntries[selectedEntry].perm[0] == 'd')
				*type = FT_DIR;
			else *type = FT_FILE;
		}
	}
	else {
		sprintf(name, "%s", fsEntries[selectedEntry].d_name);
		if (selectedEntry == 0)
			*type = FT_PARENT;
		else if (fsEntries[selectedEntry].d_type == DT_DIR)
			*type = FT_DIR;
		else *type = FT_FILE;
	}
}

//ввод строки пользователем
void inputDialog(char* title, char* inpStr){
	wclear(console);
	mvwprintw(console, 0, 1, "%s: " , title);
	wrefresh(console);
    curs_set(1);
    echo();
    wmove(console, 1, 1);
	int maxLen = getmaxx(console)-1;
	wattron (console, COLOR_PAIR(COLOR_INPUT));
	wgetnstr(console, inpStr, maxLen);
	curs_set(0);
	noecho();
	wrefresh(console);
}

//запрос подтверждения пользователя
int confirmationDialog(char* action){
	char question[BUF_S+BUF_SMALL];
	sprintf(question, "Действительно %s (д/н)?",action);
	char ans[BUF_S];
	inputDialog(question,ans);
	if (strcmp(ans,"д") != 0 && strcmp(ans,"Д") != 0)
		return CF_REJECTED;
	return CF_CONFIRMED;
}

//отображение сообщения в статусной строке
void displayStatus(char* statusStr,  char* additionalStr){
	wclear(status);
	if (additionalStr == NULL)
		mvwprintw(status, 0, 1,"%s", statusStr);
	else 
		mvwprintw(status, 0, 1,"%s (%s)", statusStr,additionalStr);
	wrefresh(status);
}
